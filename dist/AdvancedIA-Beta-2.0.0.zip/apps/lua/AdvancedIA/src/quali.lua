







local U=require('src/util')
local K=require('src/config').K
local Delta=require('src/delta')

local Incidents=require('src/incidents')
local max,min=math.max,math.min
local M={}






local function car() return {seen=false,wasPit=false,out=false,outLap=-1,exitAt=-math.huge,cool=false,coolLap=-1,slow=0,warnAt=-math.huge,
 planned=false,pushLaps=0,lapSeen=-1,wasPush=false,coolAt=-math.huge,coolEnd=-math.huge,why='',outEnd=-math.huge,outLogged=false,outPit=false,
 catchT={},catchG={},catchN=0,catchBin=0,candAt=-math.huge,candOut=0,candLogged=false,



 yellowLap=-1,faultyLap=-1,gapDrop=0,gapLogged=false,jOut=false,jExitAt=-math.huge,jEnd=-math.huge,jLap=-1,jWasPit=false,jCool=false,jCoolAt=-math.huge,jCoolEnd=-math.huge} end
function M.new()
 local t={active=false,push={},cars={},logAt=-math.huge,playerAt={},playerBin=0}
 for i=1,K.maxCars do t.cars[i]=car(); t.push[i]=false end
 return t
end
function M.reset(t)
 t.active=false; t.logAt=-math.huge; t.playerAt={}; t.playerBin=0
 for i=1,K.maxCars do t.cars[i]=car(); t.push[i]=false end
end
function M.rebase(t,amount)
 if U.finite(t.logAt) then t.logAt=t.logAt-amount end
 for b,v in pairs(t.playerAt) do t.playerAt[b]=v-amount end
 for i=1,K.maxCars do
  local c=t.cars[i]
  if U.finite(c.exitAt) then c.exitAt=c.exitAt-amount end
  if U.finite(c.warnAt) then c.warnAt=c.warnAt-amount end
  if U.finite(c.coolAt) then c.coolAt=c.coolAt-amount end
  if U.finite(c.coolEnd) then c.coolEnd=c.coolEnd-amount end
  if U.finite(c.outEnd) then c.outEnd=c.outEnd-amount end
  if U.finite(c.candAt) then c.candAt=c.candAt-amount end
  if U.finite(c.jExitAt) then c.jExitAt=c.jExitAt-amount end
  if U.finite(c.jEnd) then c.jEnd=c.jEnd-amount end
  if U.finite(c.jCoolAt) then c.jCoolAt=c.jCoolAt-amount end
  if U.finite(c.jCoolEnd) then c.jCoolEnd=c.jCoolEnd-amount end
  for k=1,c.catchN do c.catchT[k]=c.catchT[k]-amount end
 end
end
local function name(a) return a and a.name or '?' end



function M.reference(e,s,a,multi)
 local f=e.delta.fleet[multi and s.class or 1]
 if not f or not a.splineValid then return 0 end
 local v=f[Delta.bin(a.spline,e.delta.bins)] or 0
 return v*U.clamp(s.longRatio or 1,K.qualiCoolPaceMin,1)
end

function M.target(seed,i) return K.qualiPushMin+math.floor(U.unit(seed,i,K.qualiCoolSalt)*(K.qualiPushMax-K.qualiPushMin+1)) end

local function timeForCool(frame,a)
 if not (frame.left and frame.left>0) then return true end
 local lap=max(K.qualiCoolLapMin,a.lastLap or 0,a.bestLap or 0)
 return frame.left>K.qualiCoolLate*lap
end

function M.update(t,e,frame,now,dt)
 local p=e.run; local profile=e.profile; local inc=e.incidents
 t.active=(profile=='P' or profile=='Q') and p.qualiTraffic==true and not inc.red and not inc.neutral and not frame.replay and not frame.online


 if profile~='P' and profile~='Q' then
  for i=1,frame.count do
   local a=frame.cars[i]; local c=t.cars[i]

   if profile=='J' then M.trackDayOut(c,e,a,i,p,now) else c.jOut=false end
   c.wasPit=a.pit==true; c.lapSeen=a.lap or 0; c.seen=false; c.cool=false; c.planned=false; c.slow=0; c.pushLaps=0; c.wasPush=false; c.why=''
   t.push[i]=false; e.states[i].qualiNoLearn=false
  end
  for i=frame.count+1,K.maxCars do t.push[i]=false end
  return
 end
 for i=1,frame.count do
  local a=frame.cars[i]; local c=t.cars[i]; local s=e.states[i]
  local lap=a.lap or 0
  if not c.seen then




   c.seen=true; c.wasPit=a.pit==true; c.out=true; c.outLap=a.pit and -1 or lap; c.exitAt=now; c.noDrop=not a.pit
  end
  if a.pit then
   c.out=true; c.outLap=-1; c.cool=false; c.slow=0; c.planned=false; c.pushLaps=0
  elseif c.wasPit or a.teleport then
   c.out=true; c.outLap=lap; c.exitAt=now; c.cool=false; c.slow=0; c.outPit=c.wasPit==true; c.noDrop=false
  end
  c.wasPit=a.pit==true
  if c.out and not a.pit and c.outLap>=0 and lap>c.outLap then

   if now-c.exitAt<K.qualiOutGrace then c.outLap=lap else c.out=false; c.outEnd=now; c.outLogged=false; c.outPit=false end
  end

  if c.wasPush and not a.player and s.yellow then c.yellowLap=lap end

  local prevLap=c.lapSeen
  local crossed=c.lapSeen>=0 and lap>c.lapSeen
  c.lapSeen=lap
  if not c.out and not a.pit then
   if c.cool and lap>c.coolLap then
    if c.planned then c.coolEnd=now end
    c.cool=false; c.slow=0; c.planned=false
   end




   if crossed and not c.wasPush then c.pushLaps=0 end



   local why=crossed and c.wasPush and profile=='Q' and t.active and a.control and not a.player and M.faulty(c,e,i,prevLap) or nil
   if why then
    c.faultyLap=prevLap; e.stats.qualiRedo=(e.stats.qualiRedo or 0)+1
    U.log(e.log,now,'INFO',string.format('tour refait: %s (%s), un autre tour lance',name(a),why),i)
   elseif crossed and c.wasPush then
    c.pushLaps=c.pushLaps+1
    if t.active and profile=='Q' and p.qualiCoolLaps and not p.qualiRuns and p.section_general and a.control and not a.player and c.pushLaps>=M.target(e.runtimeG.seed,i) and timeForCool(frame,a) then
     c.cool=true; c.planned=true; c.coolLap=lap; c.coolAt=now; c.pushLaps=0
     e.stats.qualiCool=(e.stats.qualiCool or 0)+1
     if now>=t.logAt then t.logAt=now+K.qualiLogGap; U.log(e.log,now,'INFO',string.format('tour de refroidissement: %s (niveau -%.0f %%)',name(a),K.qualiCoolLevel*100),i) end
    end
   end
   local ref=M.reference(e,s,a,p.multiClass)


   local row=e.perception.rows[i]
   local held=row and row.front>0 and row.neighbors[row.front].gap<=K.followRange

   local yellow=a.player and (inc.playerYellow or inc.playerZone) or not a.player and s.yellow
   if not c.cool and ref>0 and a.speed<ref*K.qualiCoolRatio and not held and not yellow and not (s.state=='YIELD_IN' or s.state=='YIELD_HOLD') then
    c.slow=c.slow+dt
    if c.slow>=K.qualiCoolTime then c.cool=true; c.coolLap=lap end
   elseif not c.cool then c.slow=0 end
  end
  local cmd=e.commands[i]


  local inLap=not a.player and (cmd.rulePit or cmd.sanCalled or cmd.stratCalled)



  if not t.active and c.planned and c.cool then c.coolEnd=now; c.cool=false; c.planned=false; c.slow=0 end
  local drop=0
  if t.active and c.planned and c.cool then drop=K.qualiCoolLevel*min(1,(now-c.coolAt)/K.qualiCoolRamp)
  elseif now-c.coolEnd<K.qualiCoolRelease then drop=K.qualiCoolLevel*(1-(now-c.coolEnd)/K.qualiCoolRelease) end
  if drop>0 and a.control and not a.player then cmd.levelScale=(cmd.levelScale or 1)*(1-drop) end




  local outNow=t.active and c.out and c.outLap>=0 and not a.pit
  if not outNow and c.outLogged then c.outEnd=now; c.outLogged=false end


  if outNow and not c.outOn and c.outEnd and c.outEnd>c.exitAt then
   local f=now-c.outEnd<K.qualiCoolRelease and 1-(now-c.outEnd)/K.qualiCoolRelease or 0
   c.outFrom=now-f*K.qualiOutRamp
  end
  c.outOn=outNow
  local outDrop=0
  if outNow and c.noDrop then outDrop=0
  elseif outNow then outDrop=K.qualiOutLevel*min(1,(now-max(c.exitAt,c.outFrom or -math.huge))/K.qualiOutRamp)
  elseif now-c.outEnd<K.qualiCoolRelease then outDrop=K.qualiOutLevel*(1-(now-c.outEnd)/K.qualiCoolRelease) end
  if outDrop>0 and a.control and not a.player and p.section_general then
   cmd.levelScale=(cmd.levelScale or 1)*(1-outDrop)
   if outNow and not c.outLogged then
    c.outLogged=true; e.stats.qualiOut=(e.stats.qualiOut or 0)+1


    if c.outPit then U.log(e.log,now,'INFO',string.format('tour de chauffe: %s (niveau -%.0f %%)',name(a),K.qualiOutLevel*100),i) end
   end
  end




  M.exitGap(t,e,a,c,i,cmd,outNow and not c.noDrop and p.section_general,outDrop,now,dt)
  t.push[i]=t.active and a.valid and not a.pit and not a.finished and not a.safetyCar and not c.out and not c.cool and not inLap
   and not s.abnormal and a.kmh>=K.qualiCoolMinKmh or false
  c.wasPush=t.push[i]

  c.why=t.push[i] and '' or a.pit and 'stands' or c.out and 'tour de sortie' or c.cool and 'refroidissement' or inLap and 'tour de rentree'
   or s.abnormal and 'endommagee' or a.kmh<K.qualiCoolMinKmh and 'trop lente' or ''

  s.qualiNoLearn=t.active and not t.push[i] and not a.player
 end
 for i=frame.count+1,K.maxCars do t.push[i]=false end
 if not t.active then return end





 local pl=frame.player
 local me=pl>0 and frame.cars[pl] or nil
 if not (me and me.valid and me.splineValid and not t.push[pl] and not me.pit) then t.playerBin=0; return end
 local bins=e.delta.bins
 local here=Delta.bin(me.spline,bins)
 if here~=t.playerBin then

  local from=t.playerBin
  local step=from>0 and (here-from)%bins or 0

  if from>0 and step>0 and step<=K.qualiCatchFill then for k=1,step do t.playerAt[(from+k-1)%bins+1]=now end end
  t.playerBin=here
 end
 local best,gapTime=nil,math.huge
 for j=1,frame.count do
  local b=frame.cars[j]; local c=t.cars[j]



  if j~=pl and t.push[j] and b.valid and b.splineValid and not b.player and not b.offtrack then
   local here=Delta.bin(b.spline,bins)
   if here~=c.catchBin then
    local fresh=c.catchBin>0
    c.catchBin=here
    local at=t.playerAt[here]
    local g=fresh and at and now-at
    if g and g>=0 and g<=K.qualiCatchWatch then
     if c.catchN>=K.qualiCatchSamples then for k=1,c.catchN-1 do c.catchT[k]=c.catchT[k+1]; c.catchG[k]=c.catchG[k+1] end; c.catchN=c.catchN-1 end
     c.catchN=c.catchN+1; c.catchT[c.catchN]=now; c.catchG[c.catchN]=g
    elseif fresh then c.catchN=0 end
   end
  else c.catchBin=0; c.catchN=0 end
  local seen=c.catchN>0 and now-c.catchT[c.catchN]<=K.qualiCatchForget and c.catchG[c.catchN] or nil
  if not seen then
   if c.catchN>0 or U.finite(c.candAt) then
    c.candOut=c.candOut+dt
    if c.candOut>=K.qualiCatchForget then c.catchN=0; c.candAt=-math.huge; c.candLogged=false end
   end
  else
   c.candOut=0

   local last=c.catchT[c.catchN]
   local rateLong,rateShort=nil,nil
   for k=c.catchN-1,1,-1 do
    local span=last-c.catchT[k]
    if not rateShort and span>=K.qualiCatchSpanShort then rateShort=(c.catchG[k]-seen)/span end
    if not rateLong and span>=K.qualiCatchSpanLong then rateLong=(c.catchG[k]-seen)/span end
   end
   local rate=max(rateLong and rateLong>=K.qualiCatchRateLong and rateLong or 0,rateShort and rateShort>=K.qualiCatchRateShort and rateShort or 0)
   local confirmed=rate>0 and seen/rate<=K.qualiCatchProject
   if seen<=K.qualiWarnTime then
    if not U.finite(c.candAt) then c.candAt=now end
    if confirmed and now-c.candAt<=K.qualiCatchWindow then
     if seen<gapTime then best,gapTime=j,seen end
    elseif now-c.candAt>K.qualiCatchWindow and not c.candLogged then
     c.candLogged=true
     if e.runtimeG.debugLog then U.log(e.log,now,'DEBUG',string.format('tour lance non confirme: %s (ecart %.1f s, rapprochement %.2f s/s)',name(b),seen,max(rateLong or 0,rateShort or 0)),j) end
    end
   end
  end
 end
 if best then
  local c=t.cars[best]
  if now-c.warnAt>=K.qualiWarnRepeat then
   c.warnAt=now; e.stats.qualiWarn=(e.stats.qualiWarn or 0)+1
   local b=frame.cars[best]
   local meters=((me.spline-b.spline)%1)*frame.length
   if p.yellowMessage then Incidents.message(inc,'fastCar',best-1,math.floor(gapTime*10+0.5)/10,name(b)) end
   U.log(e.log,now,'INFO',string.format('tour lance: %s arrive derriere le joueur (%s) a %.1f s (%.0f m, %+.0f km/h)',name(b),t.cars[pl].why~='' and t.cars[pl].why or 'pas lance',gapTime,meters,(b.speed-me.speed)*3.6),best)
  end
 end
end


function M.faulty(c,e,i,lap)
 local sc=e.sanctions and e.sanctions.cars and e.sanctions.cars[i]
 if sc and sc.invalidLap==lap and lap>=0 then return 'tour invalide, limites de piste' end
 if c.yellowLap==lap and lap>=0 then return 'drapeau jaune' end
 return nil
end

local function aheadTime(e,i,a)
 local row=e.perception.rows[i]
 if not row or row.front<=0 then return nil end
 local r=row.neighbors[row.front]
 local b=e.frame.cars[r.index]
 if not b or b.pit or not b.valid or r.gap<0 then return nil end
 return r.gap/max(a.speed,K.qualiGapMinSpeed)
end
function M.exitGap(t,e,a,c,i,cmd,eligible,outDrop,now,dt)
 local want=0
 if eligible and t.active and a.control and not a.player and a.splineValid and (a.spline%1)<K.qualiGapUntil then
  local gap=aheadTime(e,i,a)
  local row=e.perception.rows[i]
  local flying=M.follower(t,e,i,row)
  if gap and gap<K.qualiExitGap and not flying then want=max(0,min(K.qualiGapLevel,K.qualiOutMaxDrop-(outDrop or 0))) end
 end
 local rate=K.qualiGapLevel/K.qualiOutRamp*dt
 if want>c.gapDrop then c.gapDrop=min(want,c.gapDrop+rate) else c.gapDrop=max(want,c.gapDrop-rate) end
 if c.gapDrop>0 then
  cmd.levelScale=(cmd.levelScale or 1)*(1-c.gapDrop)
  if want>0 and not c.gapLogged then
   c.gapLogged=true; e.stats.qualiGap=(e.stats.qualiGap or 0)+1
   U.log(e.log,now,'INFO',string.format('tour de sortie: %s laisse filer la voiture devant (ecart vise %.0f s)',name(a),K.qualiExitGap),i)
  end
 elseif want==0 then c.gapLogged=false end
end



function M.trackDayOut(c,e,a,i,p,now)
 local cmd=e.commands[i]
 if not (p.outLapEnabled and p.section_general and a.control and not a.player) then c.jOut=false; c.jWasPit=a.pit==true; return end
 if a.pit then c.jOut=false
 elseif c.jWasPit then c.jOut=true; c.jExitAt=now; c.jLap=a.lap or 0
  e.stats.trackDayOut=(e.stats.trackDayOut or 0)+1
  U.log(e.log,now,'INFO',string.format('tour de chauffe: %s (niveau -%.0f %%)',name(a),K.qualiOutLevel*100),i)
 elseif c.jOut and (a.lap or 0)>c.jLap then
  if now-c.jExitAt<K.qualiOutGrace then c.jLap=a.lap or 0 else c.jOut=false; c.jEnd=now end
 end
 c.jWasPit=a.pit==true
 local drop=0
 if c.jOut then drop=K.qualiOutLevel*min(1,(now-c.jExitAt)/K.qualiOutRamp)
 elseif now-c.jEnd<K.qualiCoolRelease then drop=K.qualiOutLevel*(1-(now-c.jEnd)/K.qualiCoolRelease) end



 local cooling=not a.pit and not a.finished and (cmd.rulePit or cmd.sanCalled or cmd.stratCalled or a.requestingPit==true)
 if cooling then
  if not c.jCool then
   c.jCool=true; c.jCoolAt=now; e.stats.trackDayCool=(e.stats.trackDayCool or 0)+1
   U.log(e.log,now,'INFO',string.format('tour de refroidissement: %s avant les stands (niveau -%.0f %%)',name(a),K.qualiCoolLevel*100),i)
  end
  drop=max(drop,K.qualiCoolLevel*min(1,(now-c.jCoolAt)/K.qualiCoolRamp))
 elseif c.jCool then c.jCool=false; c.jCoolEnd=now
 end
 if not c.jCool and now-c.jCoolEnd<K.qualiCoolRelease then drop=max(drop,K.qualiCoolLevel*(1-(now-c.jCoolEnd)/K.qualiCoolRelease)) end
 if drop>0 then cmd.levelScale=(cmd.levelScale or 1)*(1-drop) end
end


function M.follower(t,e,i,row)
 if not t.active or t.push[i] or not row then return nil end
 local best,gapTime=nil,math.huge
 for j=1,row.count do
  local r=row.neighbors[j]
  if r.long<0 and r.gap>=0 and t.push[r.index] and math.abs(r.lat)<=K.latYield and (r.sa>=K.qualiYieldSa or r.gap<=K.qualiYieldNear and r.sa>=-K.blueSlack) then
   local b=e.frame.cars[r.index]
   local time=r.gap/max(b.speed,1)


   if time<=math.max(K.qualiYieldTime,K.qualiYieldLead) and time<gapTime then best,gapTime=r,time end
  end
 end
 return best,gapTime
end
return M

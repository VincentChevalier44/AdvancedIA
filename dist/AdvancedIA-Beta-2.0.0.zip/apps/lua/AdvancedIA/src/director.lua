local U=require('src/util')
local C=require('src/config')
local P=require('src/perception')
local Persona=require('src/persona')
local Classes=require('src/classes')
local Zones=require('src/zones')
local Incidents=require('src/incidents')
local Penalties=require('src/penalties')
local Flash=require('src/flash')
local Delta=require('src/delta')
local Strategy=require('src/strategy')
local FirstLap=require('src/firstlap')
local Quali=require('src/quali')
local Rear=require('src/rear')
local Priority=require('src/priority')
local Nuance=require('src/nuance')
local Snapshot=require('src/snapshot') -- Beta 1.64, lot 1 : sens du virage devant (duel au virage)
local K=C.K
local abs,min,max=math.abs,math.min,math.max
local M={}
local yieldStates={YIELD_IN=true,YIELD_HOLD=true,YIELD_OUT=true}
local passStates={OVT_ARM=true,OVT_IN=true,OVT_HOLD=true,OVT_OUT=true}
function M.newState()
 local s={state='IDLE',reason='init',since=0,target=0,targetSide=0,offset=0,velocity=0,filtered=0,base=0,
  persona={},zone={noYield=false,noOvertake=false,maxOffset=1},pace={},paceCount=0,paceMean=0,paceRatio=0,paceRatioCount=0,freePace=0,class=2,classified=false,classCandidate=0,classCycles=0,
  manualClass=false,stint=0,stintStart=0,pitBefore=false,pitExitUntil=0,pitCautionUntil=0,pitGuardUntil=0,
  confirm=0,confirmLost=0,pendingAt=0,pendingUntil=0,pendingTarget=0,pressure=0,pressureLost=0,pressureTarget=0,passConfirm=0,passCandidate=0,passLost=0,targetLost=0,
  holdUntil=0,postPass=false,yieldStart=0,linger=0,ignoreTarget=0,ignoreUntil=0,stuck=0,blocked=0,passBlocked=0,abortSlow=0,clear=0,restUntil=0,
  followers={},followerSlow={},multiLeader=false,yieldDetection=0,yieldMargin=0,blockedYield=0,obstacleSlow=0,obstacleIdentity='',newDirectionLimit=false,
  nextPerception=0,defendUntil=0,defendCooldown=0,defendAttacker=0,defendLap=-1,defendUsed=false,
  calmUntil=0,speedWindow=0,speedWindowStart=0,lastContact=0,
  lapseAt=0,lapseUntil=0,lapseCount=0,radarBrake=0,startCare=0,radarLogAt=-math.huge,blueWait=0,blueYieldLogged=false,blueWaitLogged=false,slipTime=0,errorCount=0,errorUntil=0,excluded=false,
  direction=0,lastDirectionAt=-math.huge,directions={},directionStates={},directionSides={},directionIntended={},limitState='',limitSide=0,directionCount=0,directionHead=0,driveUntil=0,returning=false,trafficLimit=K.unlimitedSpeed,trafficGap=math.huge,trafficTarget=0,
  playerGap=math.huge,playerSa=0,lappedByPlayer=false,bluePending=false,gap=math.huge,sa=0,ttc=math.huge,spinHold=false,trafficReference=0,trafficApplied=false,
  alongside=false,passAlongside=false,aborts=0,previousIdentity='',fatigue=1,yellow=false,aiFlashAt=-math.huge,overtakeArmed=false,overtakeSpline=-1,yieldClass=false,bop=0,
  hazardRel={index=0,long=0,lat=0,gap=0,sa=0,ttc=math.huge,same=false,alongside=false},
  scanRel={index=0,long=0,lat=0,gap=0,sa=0,ttc=math.huge,same=false,alongside=false},avoidClear=0,invited=0,avoidSide=0,passStall=0,holdStall=0,holdLong=math.huge,
  lane=0,laneActive=false,laneLatched=false,laneSeen=-math.huge,laneMeters=0,laneAt=0,laneLogged=false,passedByPlayerAt=-math.huge,playerBehind=false,inviteWait=0,inviteLogged=false,appBrake=0,baseCaution=1,baseAggression=0,maneuverAt=-math.huge,passStartAt=-math.huge,passMinGap=0,passName='',closeFront=0,closeMeters=0,lastPassTarget=0,lastPassAt=-math.huge,frontWas=0}
 for j=1,K.paceBins do s.pace[j]=0 end


 s.abnormal=false; s.abnormalFor=0; s.abnormalCalm=0; s.slowPitSent=false; s.longRatio=1; s.longRatioTime=0
 s.passIgnore=0; s.passIgnoreUntil=0; s.passIgnoreCount=0; s.passReopened=nil; s.followerStall={}; s.yieldPassed=false; s.yieldOrdinary=false; s.yieldStalled=false; s.yieldCap=nil; s.yieldCapNow=nil


 s.yieldIgnore=0; s.yieldIgnoreUntil=0; s.slowPitAsked=false; s.slowPitDone=false

 s.passProgRef=0; s.passProgTime=0; s.noAdvFor=0; s.noAdvAt=0; s.yieldFlashBy=0
 s.flashFailTarget=0; s.flashFailCount=0; s.flashFailAt=0; s.flashMute=0; s.flashMuteUntil=0; s.flashHoldTarget=0; s.flashHoldUntil=0


 s.towing=false; s.towDone=false; s.towWait=0; s.towPair=0; s.towPairWait=0; s.dirty=0; s.dirtyBefore=false; s.dirtyLogWait=0; s.urgency=0
 for j=1,K.directionLimit do s.directions[j]=-math.huge; s.directionStates[j]=''; s.directionSides[j]=0 end
 for j=1,K.maxCars do s.followers[j]=false; s.followerSlow[j]=0; s.followerStall[j]=0 end
 return s
end
function M.reset(s,now,keepOffset,preserveErrors)
 s.state='IDLE'; s.reason='reset'; s.since=now; s.target=0; s.targetSide=0; s.confirm=0; s.confirmLost=0
 s.pendingAt=0; s.pendingUntil=0; s.pendingTarget=0; s.pressure=0; s.pressureLost=0; s.pressureTarget=0
 s.cornerGiveUntil=0; s.cornerEntryAt=0; s.cornerLift=1; s.cornerGiveTo=0; s.cornerPhase=false; s.cornerOut=0; s.passBrakeFree=false; s.yieldQueueFor=0
 s.holdUntil=0; s.linger=0; s.stuck=0; s.blocked=0; s.passBlocked=0; s.invited=0; s.passStall=0; s.abortSlow=0; s.clear=0; s.passAlongside=false
 s.calmUntil=0; s.spinHold=false; s.postPass=false; s.alongside=false; s.velocity=0; s.filtered=keepOffset and s.offset or 0
 for j=1,K.maxCars do s.followers[j]=false; s.followerSlow[j]=0; s.followerStall[j]=0 end
 if not preserveErrors then s.errorUntil=0; s.excluded=false; s.errorCount=0 end
 s.direction=0; s.directionCount=0; s.directionHead=0; s.driveUntil=0; s.returning=keepOffset==true
 s.passConfirm=0; s.passCandidate=0; s.passLost=0; s.targetLost=0; s.holdStall=0; s.holdLong=math.huge
 s.lastDirectionAt=-math.huge; for j=1,K.directionLimit do s.directions[j]=-math.huge end
 s.defendUntil=0; s.defendCooldown=0; s.defendAttacker=0; s.defendLap=-1; s.defendUsed=false

 s.committed=0; s.commitSide=0; s.aidLogged=0; s.rearLeftUntil=nil; s.rearRightUntil=nil; s.defendLate=false
 s.ignoreTarget=0; s.ignoreUntil=0; s.lapseUntil=0; s.bluePending=false; s.yieldBlue=false; s.yieldQuali=false; s.yieldLine=false; s.urgent=false; s.blueFull=false; s.edgeSide=0; s.edgePin=false
 s.passIgnore=0; s.passIgnoreUntil=0; s.passIgnoreCount=0; s.passReopened=nil; s.yieldPassed=false; s.yieldCap=nil; s.yieldCapNow=nil; s.yieldIgnore=0; s.yieldIgnoreUntil=0
 s.passProgRef=0; s.passProgTime=0; s.noAdvFor=0; s.noAdvAt=0; s.yieldFlashBy=0
 s.flashFailTarget=0; s.flashFailCount=0; s.flashFailAt=0; s.flashMute=0; s.flashMuteUntil=0; s.flashHoldTarget=0; s.flashHoldUntil=0
 s.blockedYield=0; s.radarBrake=0; s.speedWindowStart=now; s.speedWindow=0
 s.trafficReference=0; s.trafficApplied=false; s.yellow=false; s.overtakeArmed=false; s.overtakeSpline=-1; s.yieldClass=false
 if not keepOffset then s.offset=0 end
 s.lane=0; s.laneActive=false; s.laneLatched=false; s.laneMeters=0; s.laneLogged=false

 s.qualiHeldFor=nil; s.flPassHeldFor=nil
 s.towing=false; s.towDone=false; s.dirty=0; s.dirtyBefore=false; s.urgency=0
end
function M.configure(s,g,profile,p,now)
 Persona.fill(s.persona,g.seed,s.slot or 0,profile,p,s.stint)
 s.lapseAt=now+s.persona.lapseInterval
end

local passEnd={clear='reussi',chain='reussi, enchaine',abort_slow='cible plus rapide',abort_blocked='cote ferme',abort_stall='sans rapprochement',abort_follower='suiveur rapide',
 target_lost='cible perdue',target_pit='cible aux stands',abort_yellow='drapeau jaune',hold_limit='cote a cote sans progres',direction_limit='plafond anti-zigzag',
 guard='rendue a AC (stands, hors piste ou hors commande)',yield='cede a son suiveur',obstacle='evitement d un obstacle',contact='contact, reprise au calme',spun='tete-a-queue',
 abort_noprogress='sans progres',abort_timeout='tentative trop longue',corner_priority='priorite au virage (nez derriere)'}

local yieldEnd={passed='suiveur passe',lost='suiveur perdu',hold_limit='duree maximale',yellow='drapeau jaune',guard='rendue a AC (stands, hors piste ou hors commande)',
 obstacle='evitement d un obstacle',contact='contact, reprise au calme',spun='tete-a-queue',direction_limit='plafond anti-zigzag'}




local function lapTag(e,i)
 local q=e.quali
 if not (q and q.active and i and i>0) then return '' end
 if q.push[i] then return 'tour lance' end
 local why=q.cars[i].why
 return why~='' and why or 'pas lance'
end
local function flashFailed(e,s,now)
 local f=e.states[s.yieldFlashBy]
 if not f then return end
 if f.flashFailTarget~=s.slot or now>f.flashFailAt+K.flashFailForget then f.flashFailTarget=s.slot; f.flashFailCount=0 end
 f.flashFailCount=f.flashFailCount+1; f.flashFailAt=now
 if f.flashFailCount>=K.flashFailLimit then
  local count=f.flashFailCount
  f.flashMute=s.slot; f.flashMuteUntil=now+K.flashMuteTime; f.flashFailCount=0
  if e.stats then e.stats.flashMuted=(e.stats.flashMuted or 0)+1 end
  local cars=e.frame and e.frame.cars
  U.log(e.log,now,'INFO',string.format('appels de phares suspendus: %s -> %s apres %d cessions sans passage, plus d appel pendant %.0f s',
   cars and cars[f.slot] and cars[f.slot].name or '?',cars and cars[s.slot] and cars[s.slot].name or '?',count,K.flashMuteTime),f.slot)
 end
end





local passCounted={clear=true,chain=true,abort_blocked=true,abort_slow=true,abort_stall=true,abort_follower=true,target_lost=true,target_pit=true,abort_yellow=true,abort_noprogress=true,abort_timeout=true,corner_priority=true,hold_limit=true}
local function passFinished(e,s,reason,now)
 if U.finite(s.passStartAt) then
  if not passCounted[reason] and e.stats then e.stats.pass_other=(e.stats.pass_other or 0)+1 end
  if reason=='clear' or reason=='chain' then e.passDone=s.slot end -- Beta 1.61 : lu puis effacé par le moteur (src/zonelearn.lua)
  local car=e.frame and e.frame.cars[s.slot]





  local detail=s.pWant and string.format(' ; decalage voulu %.2f, atteint %.2f soit %.1f m vers la %s, borne la plus basse %.2f',s.pWant,s.pPeak or 0,s.pPeakM or 0,s.pPeakRight and 'droite' or 'gauche',s.pBound or 0) or ''
  U.log(e.log,now,'INFO',string.format('depassement fini: %s -> %s : %s apres %.1f s (ecart mini %.0f m%s)',car and car.name or '?',s.passName,passEnd[reason] or reason,now-s.passStartAt,s.passMinGap,detail),s.slot)
 end
 s.pWant=nil; s.pPeak=nil; s.pBound=nil; s.pPeakM=nil
 s.frankFor=nil; s.frankAt=nil
 s.passStartAt=-math.huge
end
local function transition(e,s,state,reason,now)
 if s.state==state then return end

 if state~='DRIVE' and state~='OVT_ARM' then s.seekFront=0; s.seekAt=nil end

 if passStates[s.state] and s.state~='OVT_OUT' and not passStates[state] or state=='OVT_OUT' and passStates[s.state] and s.state~='OVT_OUT' then
  passFinished(e,s,reason,now)
 end



 if (s.state=='YIELD_IN' or s.state=='YIELD_HOLD') and state~='YIELD_IN' and state~='YIELD_HOLD' and s.yieldQuali and e.stats then
  local key=s.yieldPassed and 'qualiPassed' or 'qualiLost'; e.stats[key]=(e.stats[key] or 0)+1
 end



 if yieldStates[s.state] and not yieldStates[state] then s.yieldBlue=false; s.yieldQuali=false; s.yieldClass=false end


 if (s.state=='YIELD_IN' or s.state=='YIELD_HOLD') and state~='YIELD_IN' and state~='YIELD_HOLD' then
  if e.stats then local key='yieldEnd_'..reason; e.stats.yieldEnd=(e.stats.yieldEnd or 0)+1; e.stats[key]=(e.stats[key] or 0)+1 end



  if s.yWant then
   local cars=e.frame and e.frame.cars; local car=cars and cars[s.slot]; local other=cars and cars[s.target]

   U.log(e.log,now,'INFO',string.format('cession finie: %s -> %s : %s apres %.1f s (decalage voulu %.2f, atteint %.2f soit %.1f m vers la %s, piste alors %.1f m a gauche, %.1f m a droite ; borne la plus basse %.2f%s)',
    car and car.name or '?',other and other.name or '?',yieldEnd[reason] or reason,now-(s.yieldStart or now),s.yWant,s.yPeak or 0,s.yPeakM or 0,s.yRightSide and 'droite' or 'gauche',s.yLeft or 0,s.yRight or 0,s.yBound or 0,
    s.yieldSwapped and ' ; cote regle sans place, autre cote pris' or ''),s.slot)
   s.yWant=nil; s.yPeak=nil; s.yBound=nil; s.yPeakM=nil

   local tag=lapTag(e,s.slot)
   if tag~='' then U.log(e.log,now,'INFO',string.format('tours de la cession: %s (%s), suiveur %s (%s)',car and car.name or '?',tag,other and other.name or '?',lapTag(e,s.target)),s.slot) end
  end
  if s.yieldFlashBy>0 and not s.yieldPassed and e.profile~='C' then flashFailed(e,s,now) end
  s.yieldFlashBy=0
 end


 if passStates[s.state] and s.state~='OVT_OUT' and (reason=='abort_follower' or reason=='yield') and e.profile~='C' and s.lastPassTarget>0 then
  s.flashHoldTarget=s.lastPassTarget; s.flashHoldUntil=max(s.flashHoldUntil,now+K.flashAfterAbort)
  if e.stats then e.stats.flashHeld=(e.stats.flashHeld or 0)+1 end
 end

 s.prevState=s.state; s.prevReason=s.reason
 s.state=state; s.reason=reason; s.since=now
 local stats=e.stats; if stats then stats[reason]=(stats[reason] or 0)+1


  if state=='OVT_OUT' and passStates[s.prevState] and (reason=='hold_limit' or reason=='corner_priority') then stats['pass_'..reason]=(stats['pass_'..reason] or 0)+1 end
 end
 if e.runtimeG.debugLog then U.log(e.log,now,'DEBUG',state..':'..reason,s.slot) end
end

M.transitionTest=transition -- relecture d'ensemble 1.62 : tests du décompte des fins de dépassement
local function faster(p,a,b) return p.multiClass and a.classified and b.classified and a.class<b.class end
local function sideFree(row,side) return side<0 and not row.left or side>0 and not row.right end


local function freeAt(e,s,b,p)
 local v=s.pace[b] or 0
 if v>0 then return v end
 local fleet=e.delta.fleet[p.multiClass and s.class or 1]
 if fleet and s.paceRatioCount>=K.paceRatioMin and (fleet[b] or 0)>0 then return fleet[b]*s.paceRatio end

 if s.prior and (s.prior[b] or 0)>0 then return s.prior[b]*(s.priorRatio or 1) end
 return 0
end
M.freeAt=freeAt -- Beta 1.61 : allure libre connue à une place (tests, src/pacemap.lua)



local function realAdvantage(e,s,o,a,p)
 local b=Delta.bin(a.spline,e.delta.bins)
 local mine,theirs=freeAt(e,s,b,p),freeAt(e,o,b,p)
 if mine<=0 or theirs<=0 then return nil end
 return mine>=theirs*(1+K.passFreeMargin)
end



local function yieldRefused(e,f,s,a,p,profile)
 if profile=='C' then return realAdvantage(e,f,s,a,p)==false end
 local b=Delta.bin(a.spline,e.delta.bins)
 local mine,theirs=freeAt(e,f,b,p),freeAt(e,s,b,p)
 if mine<=0 or theirs<=0 then return false end




 if f.paceRatioCount>=K.paceRatioMin and s.paceRatioCount>=K.paceRatioMin and f.paceRatio>s.paceRatio*(1+K.yieldOverallMargin) and (theirs-mine)*3.6<=K.yieldRefuseOverallKmh then return false end
 return (theirs-mine)*3.6>K.yieldRefuseKmh
end




local function queueSlow(e,frame,front)
 if not front then return false end
 local index=front.index
 for _=1,K.slowQueueLinks do
  if e.states[index].abnormal==true then return true end
  local r=e.perception.rows[index]; local ahead=r and r.front>0 and r.neighbors[r.front]
  if not ahead or ahead.long<=0 or ahead.gap>=K.slowFollowGap or frame.cars[ahead.index].kmh>frame.cars[index].kmh+K.slowLeadMargin then return false end
  index=ahead.index
 end
 return e.states[index].abnormal==true
end



local function playerSlow(e,s,b,a,p)
 local mine=freeAt(e,s,Delta.bin(a.spline,e.delta.bins),p)
 if mine>0 then return b.speed<mine*K.playerSlowRatio end
 return b.kmh<K.speedMinPass*K.playerCrawlRatio
end


local function qualiGuard(e,i,j) return e.quali and e.quali.active and not e.quali.push[i] and e.quali.push[j] end



local function frankYield(e,frame,i,j,profile,g,rel)
 local ts=e.states[j]
 if not ts or not (ts.state=='YIELD_IN' or ts.state=='YIELD_HOLD') or not (ts.followers and ts.followers[i]) then return false end
 if profile=='C' and not ts.yieldBlue then return false end
 local a,b=frame.cars[i],frame.cars[j]
 if ts.yieldLine then





  local room=max(b.leftWidth or 0,b.rightWidth or 0)
  if room<=0 then return true end
  return room-b.width*0.5-K.reachEdgeMargin>=a.width+K.frankClear+(profile=='J' and K.jPassMargin or 0)
 end
 local w=ts.offset*g.offsetSign>0 and (b.rightWidth or 0) or (b.leftWidth or 0)
 if w>0 then



  local off=abs(ts.offset-(ts.base or 0))*w
  if off<K.frankOffM then return false end
  local mine=ts.offset*g.offsetSign>0 and (a.leftWidth or 0) or (a.rightWidth or 0)
  if mine>0 and off+max(0,mine-a.width*0.5-K.reachEdgeMargin)<(a.width+b.width)*0.5+K.frankClear then return false end
  return true
 end
 return rel~=nil and abs(rel.lat)>=(a.width+b.width)*0.5+K.frankClear
end



function M.cornerness(yaw,speed,ref)
 local y=abs(yaw or 0)
 return U.clamp(min(1-y/ref,1-y*max(speed or 0,0)/K.cornerLatRef),0,1)
end



local function straightRules(profile) return profile=='C' or profile=='J' end
M.frankYieldTest=function(e,frame,i,j,profile,g,rel) return frankYield(e,frame,i,j,profile,g,rel) end -- Beta 1.62 : tests


local function firstLapHeld(_s,a,_other,_otherState,_ownBrake,potential,advantage)


 return a.corner<K.firstLapPassCorner or potential<advantage*K.firstLapPassMargin
end



local function inviteGeometry(profile,a,b,rel)
 if straightRules(profile) then return abs(a.yawRate)<=K.inviteCurve*a.speed and abs(b.yawRate)<=K.inviteCurve*b.speed end
 if abs(a.yawRate)*a.speed>K.inviteLatAccel or abs(b.yawRate)*b.speed>K.inviteLatAccel then return false end
 local k=abs(a.yawRate)/max(a.speed,1)
 return abs(rel.lat)-k*rel.long*rel.long*0.5>=K.inviteLat
end

local function userSide(side,g) return g.offsetSign<0 and -side or side end
local function fixedSide(value,fallback,g) return userSide(value=='left' and -1 or value=='right' and 1 or fallback,g) end




local sideRoom


local function towards(rel,side) return rel~=nil and abs(rel.lat)>=K.sideFollowerLat and side==(rel.lat<0 and 1 or -1) end
local function yieldSide(p,rel,ordinary,row,g,s,a)
 local value=ordinary and p.yieldSide or p.blueFlagSide
 local room=s and a and sideRoom(s,a,p,g,1)~=nil
 if value~='auto' then
  local side=fixedSide(value,1,g)
  if room and sideRoom(s,a,p,g,side)<K.sideMinRoom and sideRoom(s,a,p,g,-side)>=K.sideMinRoom and sideFree(row,-side) and not towards(rel,-side) then return -side,true end
  return side
 end
 local preferred=rel and rel.lat<0 and -1 or 1
 if room and sideFree(row,preferred) and sideFree(row,-preferred) and sideRoom(s,a,p,g,preferred)<K.sideMinRoom and sideRoom(s,a,p,g,-preferred)>=K.sideMinRoom and not towards(rel,-preferred) then return -preferred,true end
 if sideFree(row,preferred) then return preferred end
 return -preferred
end
local function passSide(p,profile,s,front,row,other,g,a)






 if abs(front.lat)>=K.inviteLat then local freed=front.lat>0 and 1 or -1; if sideFree(row,freed) then return freed end end
 if p.overtakeSide=='opposite' and (p.yieldSide=='left' or p.yieldSide=='right') then return -fixedSide(p.yieldSide,1,g) end
 if p.overtakeSide=='left' or p.overtakeSide=='right' then return fixedSide(p.overtakeSide,1,g) end
 local preferred=front.lat>0 and 1 or front.lat<0 and -1 or (other.yawRate~=0 and U.sign(other.yawRate) or s.persona.personalSide)
 if profile~='C' and p.yieldSide=='line' then




  local w1=other and (1*g.offsetSign>0 and other.rightWidth or other.leftWidth) or 0
  local w2=other and (-1*g.offsetSign>0 and other.rightWidth or other.leftWidth) or 0
  if g.offsetSign~=0 and (w1 or 0)>0 and (w2 or 0)>0 then preferred=w1>=w2 and 1 or -1
  else
   local rl,rr=a and sideRoom(s,a,p,g,-1),a and sideRoom(s,a,p,g,1)
   if rl and rr then preferred=rr>=rl and 1 or -1 end
  end
 elseif profile~='C' and (p.yieldSide=='left' or p.yieldSide=='right') then preferred=-fixedSide(p.yieldSide,1,g) end
 if sideFree(row,preferred) then return preferred end
 if sideFree(row,-preferred) then return -preferred end
 return s.persona.assertiveness>K.passSideAssert and 1 or -1
end
M.passSideTest=passSide -- relecture 1.62 (M2) : tests
local function baseModifiers(s,p,now,a)
 local persona=s.persona
 local drift=p.paceDriftPct/100*(math.sin(now/persona.period*math.pi*2+persona.phase)+math.sin(now/persona.period2*math.pi*2-persona.phase))*0.5
 local level=(p.section_general and p.levelPct/100 or a.baseLevel or a.aiLevel)*(1+persona.levelSpread+drift)
 local aggression=(p.section_general and p.aggressionPct/100*K.maxAggression or a.baseAggression or a.aiAggression)*(1+persona.aggrSpread)
 local caution=(p.section_general and p.caution or K.defaultCaution)*(1+persona.cautSpread)

 level=level*(persona.gradeLevel or 1)*(1+(p.bopEnabled and s.bop or 0)); caution=caution*(persona.gradeCaution or 1)
 if p.enduranceOverlay then
  level=level*(1+persona.stintSwing)*(1-p.stintDegradationPct/100*U.clamp((now-s.stintStart)/K.stintDuration,0,1))
  if now<s.pitCautionUntil then caution=caution*K.stintExitCaution end
 end
 if p.weatherAdaptation then level=level*(1-K.wetLevel*a.wet); caution=caution*(1+K.wetCaution*a.wet); aggression=aggression*(1-K.wetAggression*a.wet) end
 return level,aggression,caution
end



local function activeDirections(s,now)
 local active=0
 for j=1,K.directionLimit do if now-s.directions[j]<K.directionWindow then active=active+1 end end
 return active
end
local function directionAllowed(s,desired,now,p,emergency,intended,frozen)




 if frozen and not emergency then return true end

 local line=desired==s.base or s.seekAt~=nil and (intended or desired)==s.seekAt or abs(desired)<=K.sideDeadband
 local direction=line and 0 or desired>0 and 1 or -1
 if direction==s.direction then return true end

 if emergency then s.direction=direction; s.lastDirectionAt=now; return true end
 if now-s.lastDirectionAt<p.lateralCooldown then return false end
 local active=activeDirections(s,now)

 if active>=K.directionLimit then if now>=s.driveUntil then s.newDirectionLimit=true; s.limitState=s.state; s.limitSide=direction end; s.limitIntended=intended or desired; s.driveUntil=now+K.directionRest; return false end
 s.directionHead=s.directionHead%K.directionLimit+1; s.directions[s.directionHead]=now; s.directionStates[s.directionHead]=s.state; s.directionSides[s.directionHead]=direction; s.directionCount=active+1
 s.directionIntended[s.directionHead]=intended or desired
 s.direction=direction; s.lastDirectionAt=now
 return true
end



local function directionRoom(s,now,p,n)
 if now<s.driveUntil or now-s.lastDirectionAt<p.lateralCooldown then return false end
 return activeDirections(s,now)<=K.directionLimit-n
end
local function directionBudget(s,now,p) return directionRoom(s,now,p,1) end




local function wanted(value) return value and string.format(' (voulu %+.2f)',value) or '' end
local function limitText(s,now)
 local parts={}
 for k=1,K.directionLimit do
  local j=(s.directionHead+k-1)%K.directionLimit+1
  if now-s.directions[j]<K.directionWindow then parts[#parts+1]=string.format('%s>%+d -%.0fs',s.directionStates[j],s.directionSides[j],now-s.directions[j])..wanted(s.directionIntended[j]) end
 end
 return string.format('direction_limit: %s ; refuse %s>%+d',table.concat(parts,', '),s.limitState,s.limitSide)..wanted(s.limitIntended)
end
M.limitText=limitText











local function sideBound(left,right,half,toRight)
 local narrow,wide=min(left,right),max(left,right)
 local bound=max(0,narrow-half)/wide
 local width=toRight and right or left



 if width>=wide and wide>narrow then bound=max(bound,min(K.reachWideShare,K.reachWideMeters/width,max(0,min(width-half-K.reachWideEdge,K.reachSideMax-half-K.reachEdgeMargin))/width)) end
 return bound
end
local function widthBound(s,a,p,toRight,free)
 local half=a.width*0.5
 local usable=max(0,min(a.leftWidth,a.rightWidth)-half)
 local bound=usable/max(a.leftWidth,a.rightWidth)



 if not free and a.leftWidth~=a.rightWidth and K.reachWideShare>0 and (a.leftAhead or 0)>0 and (a.rightAhead or 0)>0 and (a.leftAhead2 or 0)>0 and (a.rightAhead2 or 0)>0 then
  local wide=min(sideBound(a.leftWidth,a.rightWidth,half,toRight),sideBound(a.leftAhead,a.rightAhead,half,toRight),sideBound(a.leftAhead2,a.rightAhead2,half,toRight))
  if wide>bound then bound=wide end
 end
 return min(p.maxSideOffset,s.zone.maxOffset,bound)
end




local function weaveBound(a,toRight)
 local half=a.width*0.5
 local function side(l,r) local w=toRight and r or l; return w>0 and max(0,w-half-K.formWeaveEdge)/w or 0 end
 if not ((a.leftAhead or 0)>0 and (a.rightAhead or 0)>0 and (a.leftAhead2 or 0)>0 and (a.rightAhead2 or 0)>0) then return nil end
 return min(K.formWeaveMax,side(a.leftWidth,a.rightWidth),side(a.leftAhead,a.rightAhead),side(a.leftAhead2,a.rightAhead2))
end
M.weaveBound=weaveBound
function M.reachable(s,a,p,g,desired)
 if g.offsetSign==0 or not a.splineValid or not (a.leftWidth>0 and a.rightWidth>0) then return 0 end
 local toRight=desired*g.offsetSign>0
 local bound=widthBound(s,a,p,toRight,(s.state=='DRIVE' or s.state=='IDLE') and not s.edgePin)
 if s.formWeave and (s.state=='DRIVE' or s.state=='IDLE') then local w=weaveBound(a,toRight); if w and w>bound then bound=min(w,p.maxSideOffset,s.zone.maxOffset) end end
 return U.clamp(desired,-bound,bound)
end


function M.room(s,a,p,toRight)
 if not (a.leftWidth>0 and a.rightWidth>0) then return 0 end
 return widthBound(s,a,p,toRight)*(toRight and a.rightWidth or a.leftWidth)
end






function M.roomSoon(s,a,p,toRight)
 if not ((a.leftAhead or 0)>0 and (a.rightAhead or 0)>0 and (a.leftAhead2 or 0)>0 and (a.rightAhead2 or 0)>0) then return 0 end

 local half=a.width*0.5
 local near=sideBound(a.leftAhead,a.rightAhead,half,toRight); local far=sideBound(a.leftAhead2,a.rightAhead2,half,toRight)
 return min(p.maxSideOffset,s.zone.maxOffset,near,far)*(toRight and a.rightAhead2 or a.leftAhead2)
end


local refuseStat={room='refRoom',short='refShort',suspended='refSusp',firstlap='refFirst',zone='refZone',flag='refFlag',start='refStart',corner='refCorner',
 budget='refBudget',side='refSide',corridor='refCorridor',closing='refClosing',advantage='refAdv',other='refOther'}


refuseStat.nuanceHold='nuanceHold'; refuseStat.sideRoom='passSideRoom'
local function refused(e,s,index,key)
 local seen=s.refSeen; if not seen then seen={}; s.refSeen=seen end
 if seen[key]==index then return end
 seen[key]=index
 local stat=refuseStat[key]; e.stats[stat]=(e.stats[stat] or 0)+1
end
M.refused=refused







function M.pullOutTime(e,a,target,frame,s)
 if target.gap<=K.pullOutCloseGap then return true end
 local np=FirstLap.nextPoint(e.fl,a,frame.length)
 if not (np<math.huge) then return true end
 local closing=target.sa/3.6
 if s and K.slingMinGap and K.slingGainKmh and e.profile=='C' and (s.flW or 0)<=0 and target.index~=frame.player and abs(target.lat or 99)<=K.towLat and target.gap<=K.seekRange then closing=max(closing,K.slingGainKmh/3.6) end
 local need=(target.gap+a.length)/max(closing,K.pullOutClosingMin)
 return np/max(a.speed,1)>=need*K.passSoonShare
end

sideRoom=function(s,a,p,g,side)
 if g.offsetSign==0 or not (a.leftWidth>0 and a.rightWidth>0) then return nil end
 return M.room(s,a,p,side*g.offsetSign>0)
end
M.sideRoom=sideRoom





local function laneTarget(s,a,row,g)
 local meters=s.laneMeters+(row.right and not row.left and -K.laneBias or row.left and not row.right and K.laneBias or 0)
 local width=meters*g.offsetSign>0 and a.rightWidth or a.leftWidth
 if width<=0 then return 0 end


 local bound=min(s.zone.maxOffset,K.laneMaxOffset,max(0,width-a.width*0.5)/width)
 return U.clamp(meters/width,-bound,bound)
end
local function laneHold(e,s,a,row,g,frame,now,i)
 if not frame.started then
  if not s.laneLatched and a.splineLatValid then
   s.laneLatched=true; s.laneLogged=false
   s.laneMeters=g.offsetSign~=0 and abs(a.splineLat)>=K.laneMin and a.splineLat or 0
  end
  s.lane=s.laneMeters~=0 and laneTarget(s,a,row,g) or 0; s.laneSeen=now; s.laneActive=s.lane~=0
  if s.laneActive then s.offset=s.lane; s.filtered=s.lane; s.velocity=0 end
  return s.lane
 end
 if s.lane==0 then return 0 end
 s.laneActive=true
 if not s.laneLogged then
  s.laneLogged=true; s.laneAt=now
  U.log(e.log,now,'INFO',string.format('maintien de ligne: %s a %+.1f m de la trajectoire (decalage %+.2f)',a.name,s.laneMeters,s.lane),i)
 end
 if s.alongside then s.laneSeen=now end
 if now-s.laneSeen<K.laneRelease or a.brake>K.ruleBrake then
  local target=laneTarget(s,a,row,g); if target~=0 then s.lane=target end
  return s.lane
 end
 s.laneActive=false
 U.log(e.log,now,'INFO',string.format('maintien de ligne: %s rendu apres %.1f s, ecart mesure %+.1f m',a.name,now-s.laneAt,(a.splineLat or 0)-s.laneMeters),i)
 s.lane=0
 return 0
end
function M.lateral(s,desired,row,a,p,g,dt,now)
 local intended,frozen=desired,desired==s.offset
 if not s.laneActive then desired=M.reachable(s,a,p,g,desired) end
 local delta=desired-s.offset
 local blocked=delta<0 and row.left or delta>0 and row.right
 local factor=1; local emergency=false
 if blocked then
  s.blocked=s.blocked+dt; s.velocity=0; s.filtered=s.offset
  if s.blocked<K.blockedRelease then return s.offset end

  local retreat=s.offset<0 and not row.right or s.offset>0 and not row.left
  if not retreat then return s.offset end
  desired=0; delta=desired-s.offset; factor=p.emergencyReleaseFactor; emergency=true
 else s.blocked=0 end
 if delta==0 then s.velocity=0; return s.offset end

 if s.formWeave and not s.laneActive then factor=K.formWeaveRampMult end

 if s.blueFull and (s.state=='YIELD_IN' or s.state=='YIELD_HOLD') then factor=factor*K.blueRampMult end


 if K.attackRampMult and s.attackRamp and (s.state=='OVT_IN' or s.state=='OVT_HOLD') then factor=factor*K.attackRampMult end


 local maneuver=s.state~='DRIVE' and s.state~='IDLE'





 if maneuver and not directionAllowed(s,emergency and desired or intended,now,p,emergency or s.state=='CALM' or s.state=='AVOID' or s.yieldBlue and yieldStates[s.state],intended,frozen) then s.velocity=0; s.filtered=s.offset; return s.offset end
 local rate=p.rampSpeed*U.clamp(K.lateralSpeedBase/max(a.kmh,K.lateralSpeedFloor),K.lateralRateMin,K.lateralRateMax)*factor
 local velocity=U.sign(delta)*rate
 s.velocity=U.approach(s.velocity,velocity,p.rampAccel*dt)
 s.filtered=U.ema(s.filtered,desired,dt,p.lowPassTau)
 local candidate=U.approach(s.offset,s.filtered,abs(s.velocity)*dt)
 local nextOffset=U.clamp(candidate,min(s.offset,desired),max(s.offset,desired))

 if (nextOffset<s.offset and row.left) or (nextOffset>s.offset and row.right) then return s.offset end
 s.offset=nextOffset
 return s.offset
end


local busyRel={}
local function busy(frame,player,i)
 local a=frame.cars[player]
 for j=1,frame.count do
  local b=frame.cars[j]
  if j~=player and j~=i and b.valid and not b.pit then
   local r=P.relative(a,b,frame.length,busyRel)
   if r.same and (abs(r.long)<=(a.length+b.length)*0.5 or r.long>0 and r.gap<K.inviteClear and abs(r.lat)<=K.latPass and r.sa>=K.inviteSa) then return true end
  end
 end
 return false
end


local function pace(s,a,row,dt,p,fleet,bins)
 local bin=Delta.bin(a.spline,bins)



 if s.state=='DRIVE' and row.free and s.lapseUntil<=0 and a.splineValid and not a.pit and not a.offtrack and not s.qualiNoLearn and not s.yellow and not s.trafficApplied and not s.dangerCapped then
  local old=s.pace[bin]
  if old==0 then s.paceCount=s.paceCount+1; s.paceMean=(s.paceMean*(s.paceCount-1)+a.speed)/s.paceCount; s.pace[bin]=a.speed
  else local v=old+(a.speed-old)*K.paceAlpha; s.pace[bin]=v; s.paceMean=s.paceMean+(v-old)/max(1,s.paceCount) end
  local median=fleet and fleet[bin] or 0
  if median>0 then
   local ratio=a.speed/median
   s.paceRatio=s.paceRatioCount>0 and s.paceRatio+(ratio-s.paceRatio)*K.paceRatioAlpha or ratio; s.paceRatioCount=s.paceRatioCount+1


   ratio=U.clamp(ratio,K.paceRatioLow,K.paceRatioHigh)


   if s.abnormalFor==0 then s.longRatio=s.longRatioTime>0 and U.ema(s.longRatio,ratio,dt,K.longRatioTau) or ratio; s.longRatioTime=s.longRatioTime+dt end
  end
 end
 local free=s.pace[bin]
 if free==0 and fleet and s.paceRatioCount>=K.paceRatioMin and (fleet[bin] or 0)>0 then free=fleet[bin]*s.paceRatio end
 if free==0 and s.prior and (s.prior[bin] or 0)>0 then free=s.prior[bin]*(s.priorRatio or 1) end -- Beta 1.61 : src/pacemap.lua
 s.freePace=free
 if free>0 and a.speed<free*p.stuckPaceRatio then s.stuck=s.stuck+dt else s.stuck=0 end
end
local function lapOrClass(e,s,a,other,rel,p,profile)
 local laps=not C.solo(profile) and p.blueFlagEnabled and Classes.laps(a,other,rel,e.frame.length) or 0
 local upper=faster(p,e.states[other.slot],s)
 return laps,upper
end


local function yieldTrigger(e,s,a,row,p,profile,now,dt,rest)
 local back=row.back>0 and row.neighbors[row.back] or nil

 local approaching
 for j=1,row.count do
  local r=row.neighbors[j]
  if r.long<0 and r.gap>=0 and abs(r.lat)<=K.latYield and not yieldStates[e.states[r.index].state] and r.sa>=p.yieldBehindMargin*K.nearYieldMargin
   and (not approaching or r.gap<approaching.gap) then approaching=r end
 end
 if approaching then back=approaching end



 if profile=='C' and p.blueFlagEnabled and back and back.gap>=0 and yieldStates[e.states[back.index].state] then
  local lapper
  for j=1,row.count do
   local r=row.neighbors[j]
   if r.long<0 and r.gap>back.gap and r.gap<=p.blueFlagRange*K.lapRangeMult and not yieldStates[e.states[r.index].state]
    and r.index~=e.frame.player and (not lapper or r.gap<lapper.gap) and lapOrClass(e,s,a,e.frame.cars[r.index],r,p,profile)>0 then lapper=r end
  end
  if lapper then back=lapper end
 end



 local qualiCar=e.quali and Quali.follower(e.quali,e,a.slot,row) or nil
 if qualiCar then back=qualiCar end
 local flash=e.flash.requests[a.slot]
 local activeFlash=flash.untilTime>now and now>=flash.readyAt
 if activeFlash and a.corner<p.cornerMin and not flash.extended then flash.untilTime=flash.cornerUntil; flash.extended=true end
 if activeFlash then
  local player=P.find(row,e.frame.player)
  if player and player.long<0 and player.gap<=p.flashRange then back=player end
 end
 local ai=e.flash.ai[a.slot]
 local aiFlash=not activeFlash and ai.untilTime>now and now>=ai.readyAt
 if aiFlash then
  local source=P.find(row,ai.source)
  if source and source.long<0 and source.gap>=0 and source.gap<=p.flashRange and (not qualiCar or source.index==qualiCar.index) then back=source else aiFlash=false end
 end
 if not back or back.gap<0 then s.confirm=0; s.pendingAt=0; s.pendingTarget=0; s.bluePending=false; return nil end
 local other=e.frame.cars[back.index]
 local laps,upper=lapOrClass(e,s,a,other,back,p,profile)
 local quali=qualiCar~=nil and back.index==qualiCar.index
 if yieldStates[e.states[other.slot].state] then s.pendingAt=0; return nil end
 if faster(p,s,e.states[other.slot]) and laps==0 and not quali then s.pendingAt=0; return nil end
 local blueRange=p.blueFlagRange*((laps>=2 or upper) and K.lapRangeMult or 1)


 local blue=laps>0 and back.gap<=blueRange and (back.sa>=K.lapSpeed or profile=='C' and back.gap<=K.blueCloseGap and back.sa>=-K.blueSlack)




 local vetoed=false
 if p.classNuance and blue and profile=='C' and not Nuance.catch(back.gap,back.sa) then blue=false; vetoed=true; s.blueVetoAt=now end





 if not blue and not vetoed and (s.bluePending or s.yieldBlue or back.sa>=-K.blueHoldSlack*0.5) and profile=='C' and laps>0 and back.gap<=blueRange and back.gap<=max(K.blueCloseGap,a.speed*K.blueHoldTime) and back.sa>=-K.blueHoldSlack then blue=true end


 local slowSelf=not blue and s.abnormal==true and back.gap<=p.blueFlagRange and back.sa>=K.lapSpeed


 if not blue and not slowSelf and s.abnormal==true and back.gap<=K.slowGlueGap and back.sa>=-K.blueSlack then slowSelf=true end
 if slowSelf then blue=true end
 local classYield=upper and back.sa>=p.classYieldMargin and (back.sa>=K.classFightSpeed or row.front==0 or row.neighbors[row.front].gap>K.followRange)


 if p.classNuance and classYield and not blue and Nuance.classHold(back.lat) then
  classYield=false
  if now>=(s.classHoldLogAt or -math.huge) or (s.classHoldLogAt or 0)-now>K.nuanceLogGap then
   s.classHoldLogAt=now+K.nuanceLogGap; e.stats.classHold=(e.stats.classHold or 0)+1
   U.log(e.log,now,'INFO',string.format('classe: %s tient sa ligne, %s deja decale',a.name,other.name),a.slot)
  end
 end


 if rest and not blue and not classYield and not quali then s.bluePending=false; return nil end


 local currentAdvantage=Flash.advantage(p,back.gap,back.sa)
 local acceptedFlash=activeFlash and back.index==e.frame.player and currentAdvantage
 local permittedFlash=acceptedFlash and not rest and (profile~='C' or p.flashMode=='always' or blue or classYield)





 local clear=row.front==0 or row.neighbors[row.front].gap>K.followRange or back.sa>=K.classFightSpeed


 local aiAccepted=aiFlash and not rest and back.index==ai.source and (profile~='C' and clear or laps>0 or upper)
  and not qualiGuard(e,back.index,a.slot)
 if profile=='C' and not blue and not classYield and not permittedFlash and not aiAccepted then s.confirm=0; s.pendingAt=0; s.pendingTarget=0; s.bluePending=false; return nil end

 local ordinary=p.yieldEnabled and profile~='C' and clear and not (e.quali and e.quali.active and e.quali.push[a.slot] and not e.quali.push[back.index]) and not rest
 if not ordinary and not blue and not classYield and not permittedFlash and not aiAccepted and not quali then return nil end
 if s.ignoreTarget==back.index and now<s.ignoreUntil then return nil end
 if s.yieldIgnore==back.index and now<s.yieldIgnoreUntil and not blue and not classYield and not quali then return nil end
 local margin=p.yieldBehindMargin*U.lerp(K.courtesyMin,K.courtesyMax,s.persona.courtesy)*U.lerp(K.gapMarginMin,1,back.gap/K.yieldMarginRange)
 local horizon=p.yieldHorizon
 if acceptedFlash then margin=margin*K.flashMargin; horizon=horizon*K.flashHorizon end
 local detection=max(p.yieldDetectBehind,min(K.detectMax,max(0,back.sa/3.6)*horizon))*(1+(p.weatherAdaptation and K.wetDetect*(s.wxWet or e.frame.wet) or 0))
 if acceptedFlash then detection=max(detection,p.flashRange) end
 local c1=ordinary and back.gap<=detection and back.sa>=margin and back.ttc<=horizon
 local c2=ordinary and back.gap<=K.nearYield and back.sa>=K.nearYieldMargin*margin



 local early=false
 if p.rearAwareness and profile~='C' and ordinary and back.sa>=K.rearFastSa then
  if back.gap/(back.sa/3.6)<=Rear.horizon(s,p) then
   if not (blue or classYield or quali or permittedFlash or aiAccepted) then s.confirm=0; s.pendingAt=0; s.pendingTarget=0; return nil end
  elseif back.ttc<=K.rearYieldTtc and back.gap<=K.rearFastRange then early=true; c1=true end
 end
 if p.pressureEnabled and back.gap<=p.pressureGap and abs(back.sa)<=K.pressureSa then
  if s.pressureTarget~=back.index then s.pressure=0; s.pressureTarget=back.index end
  s.pressure=s.pressure+dt; s.pressureLost=0
 elseif back.gap>p.pressureGap*K.pressureResetRange then
  s.pressureLost=s.pressureLost+dt; if s.pressureLost>K.pressureResetTime then s.pressure=0 end
 end



 local c3=ordinary and p.pressureEnabled and s.pressure>=p.pressureTime and (back.index==e.frame.player or not yieldRefused(e,e.states[back.index],s,a,p,profile))
 local c4=permittedFlash
 local c5=aiAccepted




 if (c1 or c2) and K.yieldNeedAdvantage and not (c4 or c5 or blue or classYield or quali) and back.index~=e.frame.player
  and yieldRefused(e,e.states[back.index],s,a,p,profile) then
  c1=false; c2=false
  if s.noAdvFor~=back.index or now>s.noAdvAt+K.yieldNoAdvForget then
   s.noAdvFor=back.index; e.stats.yieldNoAdv=(e.stats.yieldNoAdv or 0)+1
   U.log(e.log,now,'INFO',string.format('cession refusee: %s ne cede pas a %s (pas plus rapide ici)',a.name,other.name),a.slot)
   local tag=lapTag(e,a.slot)
   if tag~='' then U.log(e.log,now,'INFO',string.format('tours de la cession: %s (%s), suiveur %s (%s)',a.name,tag,other.name,lapTag(e,back.index)),a.slot) end
  end
  s.noAdvAt=now
 end




 if profile~='C' and passStates[s.state] and s.state~='OVT_OUT' then c1=false; c2=false; c3=false; c5=false end



 if profile=='P' and (c1 or c2 or c3) and not (c4 or c5 or blue or classYield or quali) and back.index~=e.frame.player
  and not (e.quali and e.quali.active and (e.quali.push[back.index] or e.quali.push[a.slot])) then
  local fs=e.states[back.index]
  if fs.paceRatioCount>=K.paceRatioMin and s.paceRatioCount>=K.paceRatioMin and fs.paceRatio<s.paceRatio*(1+K.practiceLapMargin) then c1=false; c2=false; c3=false end
 end
 local trigger=c1 or c2 or c3 or c4 or c5 or blue or classYield or quali
 local needed=(blue or quali) and K.lapConfirm or classYield and p.confirmTime*K.classConfirm or (c4 or c5) and K.flashConfirm or p.confirmTime
 if activeFlash and not c4 then needed=needed*K.flashMargin end
 if early and c1 and not (blue or quali or classYield or c4 or c5) then needed=needed*K.rearFastConfirm end
 if trigger then
  s.confirmLost=0
  if s.pendingTarget~=back.index then s.confirm=0; s.pendingAt=0; s.pendingTarget=back.index end
  s.confirm=s.confirm+dt
  if s.confirm>=needed and s.pendingAt==0 then
   local reaction=s.persona.reaction+s.persona.awareness*U.unit(e.runtimeG.seed,a.slot,other.index+e.eventSalt)
   if c4 or c5 then reaction=U.clamp(s.persona.reaction*K.flashReact,K.flashReactionMin,K.flashReactionMax) elseif blue or quali then reaction=reaction*K.lapReaction elseif classYield then reaction=reaction*K.classReaction end
   s.pendingAt=now+reaction; s.pendingUntil=now+K.pendingTTL
  end
 else
  s.confirmLost=s.confirmLost+dt
  if s.confirmLost>K.confirmReset then s.confirm=0; s.pendingAt=0; s.pendingTarget=0; s.bluePending=false end
 end
 if now>s.pendingUntil and s.pendingAt>0 then s.pendingAt=0; s.confirm=0 end
 if not trigger or s.pendingAt==0 or now<s.pendingAt then return nil end
 local corner=(blue or quali) and K.lapCorner or classYield and K.classCorner or p.cornerMin


 if quali and profile=='Q' and back.gap<=max(other.speed,1)*K.qualiSacrificeTime then corner=min(corner,p.cornerMin) end
 if a.corner<corner then s.bluePending=blue; if blue then s.blueReason='virage'; s.blueVetoAt=now end; return nil end



 if p.classNuance and not quali and (blue and not slowSelf and profile=='C' or classYield) then
  local soon,d=Nuance.brakeSoon(e,a,e.frame.length,K.blueBrakeTime)
  if soon then
   s.bluePending=blue; if blue then s.blueReason='freinage proche'; s.blueVetoAt=now end
   if s.brakeWaitFor~=back.index or now>(s.brakeWaitAt or -math.huge)+K.nuanceLogGap then
    s.brakeWaitFor=back.index; s.brakeWaitAt=now; e.stats.blueBrakeWait=(e.stats.blueBrakeWait or 0)+1
    U.log(e.log,now,'INFO',string.format('drapeau bleu: %s attend la sortie pour %s (freinage proche, %.0f m)',a.name,other.name,d),a.slot)
   end
   return nil
  end
  local zone=blue and back.gap>K.blueCloseGap and not s.zone.passMargin and Zones.nextAttack and a.splineValid and Zones.nextAttack(e.zones,a.spline) or nil
  if zone and ((zone-a.spline)%1)*e.frame.length<=max(a.speed,K.firstLapSpeedMin)*K.blueZoneTime then s.bluePending=true; s.blueReason='zone d attaque proche'; s.blueVetoAt=now; return nil end
 end
 local side,swapped=yieldSide(p,back,profile~='C' and not blue,row,e.runtimeG,s,a) -- Beta 1.62 : voiture lancée : côté réglé (yieldSide)
 s.yieldSwapped=swapped==true



 if K.blueFullSide and profile=='C' and (blue or classYield) then
  if s.abnormal==true and (s.edgeSide or 0)~=0 and sideFree(row,s.edgeSide) then side=s.edgeSide
  elseif p.blueFlagSide=='auto' then
   local rl,rr=sideRoom(s,a,p,e.runtimeG,-1),sideRoom(s,a,p,e.runtimeG,1)
   if rl and rr then local wide=rr>=rl and 1 or -1; if wide~=side and sideFree(row,wide) and abs((rr>=rl and rr or rl)-(rr>=rl and rl or rr))>=K.sideMinRoom then side=wide end end
  end
 end
 local line=p.yieldSide=='line' and not (blue or classYield)
 if not sideFree(row,side) and not line then s.blockedYield=s.blockedYield+dt else s.blockedYield=0 end


 local blocked=s.zone.noYield and 'zone sans cession' or a.kmh<K.speedMinYield and 'trop lent' or not line and not sideFree(row,side) and 'cote occupe' or not blue and not classYield and not quali and not directionBudget(s,now,p) and 'trop de changements de trajectoire' or nil
 if blocked then if blue then s.blueReason=blocked; s.blueVetoAt=now end; return nil end
 s.target=back.index; s.targetSide=side; s.gap=back.gap; s.sa=back.sa; s.ttc=back.ttc
 s.yieldDetection=max(detection,blue and blueRange or 0,quali and other.speed*max(K.qualiYieldTime,K.qualiYieldLead)*K.qualiYieldRange or 0); s.yieldMargin=margin
 for j=1,K.maxCars do s.followers[j]=false; s.followerSlow[j]=0; s.followerStall[j]=0 end
 s.followers[back.index]=true; s.multiLeader=false; s.bluePassedBy=nil; s.blueCornerHold=false; s.yieldPassed=false
 s.confirm=0; s.pendingAt=0; s.pendingTarget=0; s.bluePending=false; s.holdUntil=now+p.yieldHoldMin; s.brakeWaitFor=0
 s.linger=0; s.postPass=false; s.yieldStart=now; s.yieldBlue=blue or classYield or quali; s.urgent=c4 and flash.urgent
 s.yieldOrdinary=not (blue or classYield or c4 or c5 or quali); s.yieldStalled=false


 s.yieldLine=line

 s.yieldFlashBy=c5 and back.index or 0

 s.yieldQuali=quali and not blue and not classYield and not c4 and not c5
 if s.yieldQuali then
  e.stats.qualiYield=(e.stats.qualiYield or 0)+1

  if now>=(s.qualiLogAt or -math.huge) then s.qualiLogAt=now+K.qualiLogGap; U.log(e.log,now,'INFO',string.format('cede a %s en tour lance (%s, %.0f m, %+.0f km/h)',other.name,e.quali.cars[a.slot].why~='' and e.quali.cars[a.slot].why or 'pas lance',back.gap,back.sa),a.slot) end
 end
 s.yieldClass=(classYield or c5 and upper) and not blue
 if slowSelf then
  e.stats.slowYield=(e.stats.slowYield or 0)+1
  U.log(e.log,now,'INFO',string.format('IA lente: %s s ecarte pour %s (%.0f m, %+.0f km/h)',a.name,other.name,back.gap,back.sa),a.slot)
 end
 if early and s.yieldOrdinary then
  e.stats.rearYield=(e.stats.rearYield or 0)+1
  U.log(e.log,now,'INFO',string.format('cession anticipee: %s -> %s (%.0f m, %+.0f km/h)',a.name,other.name,back.gap,back.sa),a.slot)
 end
 if c5 then U.log(e.log,now,'INFO','cede sur appel de phares de '..other.name,a.slot) end
 if c4 then U.log(e.log,now,'INFO',string.format('cede sur appel de phares du joueur (%.0f m, %+.0f km/h)',back.gap,back.sa),a.slot) end
 return back
end


function M.trafficCap(cmd,s,a,p,profile,dt)

 if s.dangerLowered then cmd.speedLimit=s.dangerSaved; s.dangerLowered=false end
 local applied=profile=='J' and p.section_traffic and s.state=='DRIVE'
 local limit=applied and not s.alongside and a.corner>=p.cornerMin and s.trafficLimit or K.unlimitedSpeed
 if limit<K.unlimitedSpeed then
  local start=cmd.speedLimit<K.unlimitedSpeed and cmd.speedLimit or a.kmh
  cmd.speedLimit=U.approach(max(start,limit),limit,K.trafficDecelKmh*dt)
 elseif applied and cmd.speedLimit<a.kmh then cmd.speedLimit=U.approach(cmd.speedLimit,a.kmh,K.trafficAccelKmh*dt)
 else cmd.speedLimit=K.unlimitedSpeed end
 s.trafficApplied=cmd.speedLimit<K.unlimitedSpeed
end



local function aeroMap(e,frame)
 local m=e.aero; local bins=e.delta.bins
 if not m or m.bins~=bins or m.length~=frame.length then
  m={bins=bins,length=frame.length,st={},seen={},run={},len={},at=-math.huge,session=m and m.session,finalLogged=m and m.finalLogged or false}
  for b=1,bins do m.st[b]=0; m.seen[b]=0; m.run[b]=0; m.len[b]=0 end
  e.aero=m
 end
 if m.session~=frame.session then
  m.session=frame.session; m.finalLogged=false

  for b=1,m.bins do m.st[b]=0; m.seen[b]=0; m.run[b]=0; m.len[b]=0 end
  m.at=-math.huge
 end
 return m
end
local function straightBin(m,b) return m.seen[b]>=K.towMapSeen and m.st[b]>=K.towStraightShare end
local function aeroRuns(m,now)
 if now<m.at and now>=m.at-K.towMapPeriod then return end
 m.at=now+K.towMapPeriod
 local bins=m.bins; local run,len=m.run,m.len
 local z=0
 for b=1,bins do if not straightBin(m,b) then z=b; break end end
 if z==0 then for b=1,bins do run[b]=bins; len[b]=bins end; return end
 run[z]=0
 for k=1,bins-1 do local b=(z-1-k)%bins+1; run[b]=straightBin(m,b) and run[b%bins+1]+1 or 0 end
 local current,previous=0,false
 for k=1,bins do
  local b=(z-1+k)%bins+1; local straight=run[b]>0
  if straight and not previous then current=run[b] end
  len[b]=straight and current or 0; previous=straight
 end
end

local function lapsAhead(a,b,rel,length)
 if length<=0 or not a.lapValid or not b.lapValid or not a.splineValid or not b.splineValid or a.lap<1 then return 0 end
 return max(0,math.floor((a.lap+a.spline)-(b.lap+b.spline)+rel.long/length+K.lapTolerance))
end

local function leadLaps(a,b)
 if not a or not b or not a.lapValid or not b.lapValid or not a.splineValid or not b.splineValid or a.lap<1 then return 0 end
 return max(0,math.floor((a.lap+a.spline)-(b.lap+b.spline)+K.lapTolerance))
end


local function rival(e,s,a,n,p,frame)
 local other=frame.cars[n.index]; local os=e.states[n.index]
 if other.safetyCar or other.pit then return false end
 if Classes.laps(a,other,n,frame.length)>0 or lapsAhead(a,other,n,frame.length)>0 then return false end
 return not faster(p,s,os) and not faster(p,os,s)
end



function M.nuanceTruce(e,s,a,row,p,frame,now,i)
 local n=row.front>0 and row.neighbors[row.front] or nil
 if not n or n.gap<0 or n.index==frame.player or n.gap>K.nuanceBattleTime*max(a.speed,1) or not rival(e,s,a,n,p,frame) then return end
 if Nuance.truce(e.nuance,i,n.index,s.target,now,p.yieldMaxHold) then
  e.stats.blueTruce=(e.stats.blueTruce or 0)+1
  U.log(e.log,now,'INFO',string.format('drapeau bleu: treve %s / %s, %s passe d abord',a.name,frame.cars[n.index].name,frame.cars[s.target].name),i)
 end
end




function M.nuanceGate(e,s,a,front,p,profile,frame,now,i)
 if Nuance.truced(e.nuance,i,front.index,now) then return 'treve' end
 local other=frame.cars[front.index]
 if profile=='C' and not C.solo(profile) then
  if Nuance.relapHeld(s,front.index,front.sa,now) then return 'tour tout juste pris' end
  if a.corner<K.lapCorner and Classes.laps(a,other,front,frame.length)>0 then return 'dedoublement hors ligne droite' end
 end
 if faster(p,s,e.states[front.index]) and front.gap>0 and Nuance.brakeSoon(e,a,frame.length,K.classNoDiveTime) then
  if s.classWaitFor~=front.index or now>(s.classWaitAt or -math.huge)+K.nuanceLogGap then
   s.classWaitFor=front.index; s.classWaitAt=now; e.stats.classWait=(e.stats.classWait or 0)+1
   U.log(e.log,now,'INFO',string.format('classe: %s attend la sortie pour passer %s (classe lente au freinage)',a.name,other.name),i)
  end
  return 'classe lente au freinage'
 end
 return nil
end


local function dirtyAir(e,s,a,front,p,startPhase)
 if not p.dirtyAirEnabled or startPhase or s.yellow or e.incidents.neutral or e.incidents.red or s.alongside or not front or front.long<=0 or front.gap<0
  or front.gap>p.dirtyAirGap or abs(front.lat)>K.dirtyAirLat or a.kmh<K.dirtyAirSpeed or a.corner>=p.cornerMin
  or s.state=='AVOID' or s.state=='CALM' or s.state=='IDLE' then return 0 end
 return U.clamp(1-(front.gap-K.dirtyAirFull)/max(1,p.dirtyAirGap-K.dirtyAirFull),0,1)
end


local function finalLapsFor(p,frame,race)
 local total=frame.sessionLaps>0 and not frame.timedRace and frame.sessionLaps or race and race.known and (frame.leaderLaps or 0)+race.lapsLeft or 0
 if total>0 then return min(p.finalLaps,max(1,math.floor(K.finalLapsShare*total+0.5))) end
 return p.finalLaps
end
M.finalLapsFor=finalLapsFor


local function urgency(e,s,a,row,p,profile,frame,startPhase)
 if profile~='C' or not p.finalLapsEnabled or not frame.started or a.finished or startPhase or s.yellow
  or e.incidents.neutral or e.incidents.red or s.bluePending or s.yieldBlue then return 0 end


 local left=Strategy.lapsLeft(e,frame,a)
 local laps=finalLapsFor(p,frame,e.race)
 if left<1 or left>laps then return 0 end
 for j=1,row.count do
  local n=row.neighbors[j]
  if n.gap>=0 and n.gap<=K.finalRange and n.index~=frame.player and rival(e,s,a,n,p,frame) then return (laps-left+1)/laps end
 end
 return 0
end






local function towStart(e,s,a,back,row,p,profile,frame,now,startPhase,braking,m,i,g)
 if profile~='C' or not p.towBreakEnabled or s.towDone or s.towWait>0 or not back or m.bins<=0 or s.returning or startPhase or s.yellow or e.incidents.neutral
  or e.incidents.red or braking or a.brake>K.ruleBrake or s.alongside or s.bluePending or s.yieldBlue or s.lapseUntil>now or a.corner<K.towCorner
  or a.kmh<K.towSpeed or back.long>=0 or back.gap>p.towBreakRange or abs(back.lat)>K.towLat or back.sa<K.towSaMin
  or e.flash.requests[i].untilTime>now or not directionRoom(s,now,p,2) then return false end



 if s.defendUsed or (a.lap or 0)<1 or back.index==frame.player or back.sa>K.towSaMax or passStates[e.states[back.index].state] then return false end
 if a.pitDistance and a.pitDistance<K.pitZone then return false end
 local junction=e.merge and e.merge.spline or -1
 if junction>=0 and frame.length>0 then
  local after=U.spline(a.spline-junction)*frame.length
  if after>=-K.towMergeBefore and after<=K.towMergeAfter then return false end
 end
 if s.towPair==back.index and s.towPairWait>0 then return false end
 if not rival(e,s,a,back,p,frame) then return false end
 local b=Delta.bin(a.spline,m.bins); local binLength=frame.length/m.bins
 local straight=m.len[b]*binLength
 if straight<p.towBreakStraight or m.run[b]*binLength<K.towMinAheadTime*a.speed then return false end
 s.towDone=true
 if U.unit(g.seed,i,(a.lap+back.index)*3+K.towSalt)>=K.towChance+K.towAssert*s.persona.assertiveness then return false end



 local away=back.lat>0 and 1 or -1
 local forced=(p.overtakeSide=='left' or p.overtakeSide=='right') and fixedSide(p.overtakeSide,1,g) or p.overtakeSide=='opposite' and (p.yieldSide=='left' or p.yieldSide=='right') and -fixedSide(p.yieldSide,1,g) or 0 -- Beta 1.62 (relecture 162v, point 6) : même garde que passSide
 local side=forced~=0 and -forced or away
 if side~=away and abs(back.lat)>K.towLatSide or not sideFree(row,side) then return false end
 s.targetSide=side; s.towing=true; s.defendUntil=now+K.towHoldMax; s.towPair=back.index; s.towPairWait=K.towPairCooldown; s.towWait=K.towCooldown

 s.defendUsed=true; s.defendAttacker=back.index; s.defendLap=a.lap
 transition(e,s,'DEFEND','tow',now)
 U.log(e.log,now,'INFO',string.format('aspiration: %s casse l aspiration de %s (%.0f m, ligne droite %.0f m)',a.name,frame.cars[back.index].name,back.gap,straight),i)
 return true
end



local function straightHoldCount(e,s,now,push)
 if now>=(s.straightHoldAt or -math.huge) or s.straightHoldAt-now>1 then
  s.straightHoldAt=now+1; e.startHold=(e.startHold or 0)+1; e.stats.flHold=(e.stats.flHold or 0)+1
  if push then e.stats.flPushed=(e.stats.flPushed or 0)+1 end
 end
end
local function capText(v) return v and v<K.unlimitedSpeed and string.format('%.0f',v) or 'aucune' end



local function passFreeOf(s,row,front)
 if s.state~='OVT_IN' and s.state~='OVT_HOLD' then return false end
 local r=P.find(row,s.target)
 if not r or abs(r.lat)<K.passFreeLat then return false end
 return not (front and front.index~=s.target and front.long>0 and front.gap<K.followRange)
end



local function bogging(e,j,now)
 local t=e.antics
 if not t or not t.poor or not t.poor[j] or (t.kind~='ac' and t.kind~='grid') then return false end
 local since=now-t.at
 return since>=0 and since<(t.react[j] or 0)+(t.bog[j] or 0)+K.anticBogGrace
end
M.passFreeTest=passFreeOf; M.boggingTest=bogging -- affinage 1.62 : tests











local function slipSeek(e,s,a,row,p,profile,frame,now,rel,braking,ownBrake,early,i,g,m)
 local ok=rel~=nil and p.slipstreamEnabled and (profile=='C' or profile=='P' or profile=='Q') and g.offsetSign~=0 and frame.length>0 and a.splineValid
  and a.leftWidth>0 and a.rightWidth>0 and not early and not braking and ownBrake<K.passBrakeMax and a.brake<=K.ruleBrake
  and (a.cornerYaw or a.corner)>=K.slipCorner and a.corner>=K.slipCorner and a.kmh>K.slipSpeed
  and not s.yellow and not e.incidents.neutral and not e.incidents.red and not s.alongside and not s.bluePending and not s.yieldBlue
  and s.lapseUntil<=now and not s.returning and not s.zone.noOvertake and not s.hotspot
  and rel.long>0 and not rel.alongside and rel.gap<=min(K.seekRange,a.speed*K.seekTime) and abs(rel.lat)<=K.seekLatMax
  and rel.sa<=K.seekSaMax and rel.ttc>=K.seekTTC
 local seeking=(s.seekFront or 0)~=0
 if ok and seeking and s.seekFront~=rel.index then ok=false end


 if ok and not seeking and abs(rel.lat)<(profile=='C' and K.wakeAlignLat or K.seekLat) then ok=false end
 if ok then
  local o=e.states[rel.index]; local ic=e.incidents.cars[rel.index]
  if yieldStates[o.state] or o.abnormal==true or ic and (ic.incident or ic.trouble) then ok=false end
 end
 if ok and profile=='Q' then
  local q=e.quali
  ok=q~=nil and q.active and q.push[i] and not (q.cars[i] and q.cars[i].cool)
  if ok then for j=1,row.count do local r=row.neighbors[j]; if r.long<0 and r.gap<=a.speed*K.seekTime and q.push[r.index] then ok=false; break end end end
 end
 if ok then
  local ahead=FirstLap.nextPoint(e.fl,a,frame.length)

  if not (ahead<math.huge) and m.bins>0 and m.at>-math.huge then local b=Delta.bin(a.spline,m.bins); if m.seen[b]>=K.towMapSeen then ahead=m.run[b]*frame.length/m.bins end end
  if not (ahead<math.huge) or ahead<a.speed*(seeking and K.seekReturnTime or K.seekAheadTime) then ok=false end
 end
 if ok and abs(rel.lat)>=K.seekSettleLat then
  local side=rel.lat>0 and -1 or 1
  if not sideFree(row,side) or not P.corridor(frame.cars,frame.count,i,side,K.corridorMin,rel.index,g.occLatMax) then ok=false end
 end
 if not ok then s.seekFront=0; s.seekAt=nil; return nil end
 if not seeking then
  local cur=s.offset
  s.seekFront=rel.index; s.seekM=cur*(cur*g.offsetSign>0 and a.rightWidth or a.leftWidth)-rel.lat; s.seekLatch=now


  if not (s.seekLogFront==rel.index and s.seekLogAt and now>=s.seekLogAt and now-s.seekLogAt<K.seekLogGap) then
   s.seekLogFront=rel.index; s.seekLogAt=now
   e.stats.slipSeek=(e.stats.slipSeek or 0)+1
   U.log(e.log,now,'INFO',string.format('aspiration recherchee: %s derriere %s (%.0f m, ecart lateral %.1f m)',a.name,frame.cars[rel.index].name,rel.gap,abs(rel.lat)),i)
  end
 elseif abs(rel.lat)>=K.seekSettleLat and now-s.seekLatch>=K.seekSettle then
  s.seekM=s.seekM-rel.lat; s.seekLatch=now
 end
 local d=U.clamp(s.seekM/(s.seekM*g.offsetSign>0 and a.rightWidth or a.leftWidth),-p.maxSideOffset,p.maxSideOffset)
 s.seekAt=d
 return d
end






local function seekLate(e,s,a,target,frame)

 local tow=target.index~=frame.player and abs(target.lat)<=K.towLat and target.gap<=K.seekRange






 local late=K.lastPullEnabled and e.profile=='C' and (s.flW or 0)<=0 and target.index~=frame.player and (target.long or 1)>0
  and target.gap<=K.seekRange and abs(target.lat)<=K.lastPullLat and (a.corner or 1)>=K.passCornerC
 if late then
  local npL=FirstLap.nextPoint(e.fl,a,frame.length)
  if npL<math.huge then
   s.wakeStallAt=nil




   local fc=frame.cars and frame.cars[target.index]
   local decel=0
   if fc then
    if s.lpFront==target.index and s.lpT and e.time>s.lpT then decel=(s.lpV-fc.speed)/(e.time-s.lpT) end
    s.lpFront=target.index; s.lpV=fc.speed; s.lpT=e.time
   end
   if target.gap<=K.wakePullGap and (decel>K.closeInFrontDecel or fc and (fc.brake or 0)>K.ruleBrake) then s.lastPullWhy='lift'; return true end
   if target.gap<=K.lastPullGap then s.lastPullWhy='gap'; return true end
   if target.sa>0 and target.gap/(target.sa/3.6)<=K.lastPullTTC then s.lastPullWhy='ttc'; return true end
   local closing=max(target.sa/3.6,K.slingGainKmh/3.6)
   local need=(target.gap+a.length)/max(closing,K.pullOutClosingMin)

   local go=npL/max(a.speed,1)<=need*K.passSoonShare+K.seekPullMargin

   if go and K.slingMaxGap and target.gap>K.slingMaxGap then go=false end
   s.slingNp=go and closing>target.sa/3.6 and npL or nil
   if go then s.lastPullWhy='sling' end
   return go
  end
 end
 if (s.seekFront or 0)~=target.index and not tow then s.wakeStallAt=nil; return true end
 if target.gap<=(tow and K.wakePullGap or K.pullOutCloseGap) then return true end

 if s.wakeSeen==nil or e.time<s.wakeSeen or e.time-s.wakeSeen>0.25 then s.wakeStallAt=nil end
 s.wakeSeen=e.time
 if target.sa<K.wakeStallSa and target.gap<=K.wakeStallGap then
  s.wakeStallAt=s.wakeStallAt or e.time






  local sling=tow and K.slingGainKmh and e.profile=='C' and (s.flW or 0)<=0 and target.gap>(K.slingMinGap or K.wakeStallGapRace)
  local np=FirstLap.nextPoint(e.fl,a,frame.length)
  if not (sling and np<math.huge) and e.time-s.wakeStallAt>=K.wakeStallTime then return true end
 else s.wakeStallAt=nil end
 local np=FirstLap.nextPoint(e.fl,a,frame.length)
 if not (np<math.huge) then return true end


 local closing=target.sa/3.6
 if tow and K.slingGainKmh and e.profile=='C' and (s.flW or 0)<=0 then closing=max(closing,K.slingGainKmh/3.6) end
 local need=(target.gap+a.length)/max(closing,K.pullOutClosingMin)
 local go=np/max(a.speed,1)<=need*K.passSoonShare+K.seekPullMargin


 if go and tow and K.slingMaxGap and e.profile=='C' and (s.flW or 0)<=0 and target.gap>K.slingMaxGap then go=false end

 s.slingNp=go and closing>target.sa/3.6 and np or nil
 return go
end
M.slipSeekTest=slipSeek; M.seekLateTest=seekLate




local function exitHold(e,s,row,now,profile)
 if not K.exitRearGap or profile~='C' then return false end
 local diag=false
 for j=1,row.count do local r=row.neighbors[j]; if r.long<0 and r.gap<K.exitRearGap and abs(r.lat)>=K.exitRearLatMin and abs(r.lat)<=K.exitRearLatMax then diag=true; break end end
 if diag and now-(s.since or now)<K.exitHoldMax then
  if not s.exitHoldLogged then s.exitHoldLogged=true; e.stats.exitHold=(e.stats.exitHold or 0)+1 end
  return true
 end
 s.exitHoldLogged=nil
 return false
end
M.exitHoldTest=exitHold








local function closeInOf(e,s,a,front,frame,p,profile,firstLap,ownBrake,starting)
 if not K.closeInEnabled or profile~='C' or firstLap or starting or not frame.started or not front or front.long<=0 or front.index==frame.player then return false end
 if s.yellow or s.bluePending or s.yieldBlue or e.incidents.neutral or e.incidents.red or s.state=='AVOID' or s.state=='CALM' or yieldStates[s.state] then return false end
 if front.gap<K.closeInMin or front.gap>K.closeInGap or abs(front.lat)>K.towLat or (front.sa or 0)>K.closeInMaxSa then return false end
 if a.kmh<K.closeInKmh or a.corner<p.cornerMin or (a.cornerYaw or a.corner)<K.slipCorner or ownBrake>K.ruleBrake then return false end
 local fc=frame.cars[front.index]
 if not fc or not fc.valid or fc.pit then return false end





 local now=e.time
 local decel=0
 if s.ciFront==front.index and s.ciT and now>s.ciT then decel=(s.ciV-fc.speed)/(now-s.ciT) end
 s.ciFront=front.index; s.ciV=fc.speed; s.ciT=now
 local np=FirstLap.nextPoint(e.fl,a,frame.length)
 local stop=(fc.brake or 0)>K.ruleBrake or decel>K.closeInFrontDecel or front.gap<K.closeInNearGap and (front.sa or 0)>K.closeInNearSa
  or not (np<math.huge) or np<a.speed*K.closeInBrakeLead
 if stop then if s.closeIn then s.closeInBlockUntil=now+K.closeInHoldOff end; return false end
 if now<(s.closeInBlockUntil or -math.huge) then return false end
 if (front.ttc or math.huge)<K.closeInTTC then return false end
 return true
end
M.closeInTest=closeInOf







local function overlapYieldOf(e,s,a,row,frame,p,profile,firstLap,ownBrake,starting,i)
 if not K.overlapYieldEnabled or profile~='C' or firstLap or starting or not frame.started or not row then return nil end
 if s.yellow or s.bluePending or s.yieldBlue or s.abnormal or e.incidents.neutral or e.incidents.red or s.state=='AVOID' or s.state=='CALM' or yieldStates[s.state] then return nil end
 if a.kmh<K.overlapYieldKmh or a.corner<p.cornerMin or ownBrake>K.ruleBrake then return nil end
 local now=e.time
 if now<(s.ovyBlockUntil or -math.huge) then return nil end
 local np=FirstLap.nextPoint(e.fl,a,frame.length)
 if not (np<math.huge) or np<a.speed*K.overlapYieldBrakeLead then return nil end
 local half=(a.length or K.length)*K.overlapYieldShare
 for j=1,row.count do
  local r=row.neighbors[j]; local os=e.states[r.index]
  if os and os.target==i and os.state=='OVT_HOLD' and r.index~=frame.player and r.long<=0 and r.long>=-half and abs(r.lat)>=K.passFreeLat then
   return r.index
  end
 end
 return nil
end
M.overlapYieldTest=overlapYieldOf



local function unlapCap(e,frame,i,a,cap,p)
 local inc=e.incidents; local best,bj=K.scWatch,0
 for j=1,frame.count do
  local b=frame.cars[j]
  if j~=i and b.valid and not b.pit and b.splineValid and (j==inc.safety or inc.cars[j] and inc.cars[j].inTrain) then
   local both=(a.length or K.length)+(b.length or K.length)
   local d=U.spline(b.spline-a.spline)*frame.length-both*0.5
   if d>-both and d<best then best=d; bj=j end
  end
 end
 if bj==0 then return cap end
 local vt=(frame.cars[bj].kmh+Incidents.SK.rel)/3.6
 return min(cap,max(K.trafficMinSpeed,math.sqrt(vt*vt+2*p.yellowDecel*max(0,best-K.queueKeep))*3.6))
end
local H={closeInOf=closeInOf,overlapYieldOf=overlapYieldOf,capText=capText,limitText=limitText,aeroMap=aeroMap,aeroRuns=aeroRuns,finalLapsFor=finalLapsFor,urgency=urgency,towStart=towStart,playerSlow=playerSlow,straightHoldCount=straightHoldCount,laneHold=laneHold,passFinished=passFinished,passEnd=passEnd,lapsAhead=lapsAhead,yieldRefused=yieldRefused,firstLapHeld=firstLapHeld,inviteGeometry=inviteGeometry,passFreeOf=passFreeOf,bogging=bogging,slipSeek=slipSeek,seekLate=seekLate,exitHold=exitHold}
function M.step(e,i,dt,now)
 local frame=e.frame; local a=frame.cars[i]; local s=e.states[i]; local cmd=e.commands[i]
 local p,g,profile=e.run,e.runtimeG,e.profile; local row=e.perception.rows[i]
 cmd.active=false; a.wet=s.wxWet or frame.wet -- Beta 1.61 : s.wxWet (src/wx.lua), champ absent : humidité de la piste
 if a.player then return end -- État du joueur tenu par le moteur pour sa carte d'allure.
 if not a.valid or not a.control or a.pit or a.offtrack or a.finished or a.safetyCar or s.excluded or s.disqualified or s.retired or now<s.errorUntil then
  if a.pit then s.pitBefore=true end
  cmd.yellowLimit=K.unlimitedSpeed; s.yellow=false; s.bluePending=false
  local gone=e.incidents.cars[i]; if gone then gone.trouble=false end; s.troubleFor=0
  transition(e,s,'IDLE','guard',now); return
 end
 local identity=a.identity or a.id
 if a.teleport or s.previousIdentity~=identity then


  if s.previousIdentity~=identity then s.longRatio=1; s.longRatioTime=0 end
  M.reset(s,now,false); s.previousIdentity=identity; s.bop=0
  for j=1,#s.pace do s.pace[j]=0 end
  s.paceCount=0; s.paceMean=0; s.paceRatio=0; s.paceRatioCount=0; s.freePace=0
 end
 if s.pitBefore then
  s.pitBefore=false; s.stint=s.stint+1; s.stintStart=now
  Persona.fill(s.persona,g.seed,i,profile,p,s.stint)
  s.pitExitUntil=now+(p.enduranceOverlay and K.stintExitDelay or K.pitExitDelay)

  s.pitCautionUntil=now+K.stintExitCautionTime; s.pitGuardUntil=now+K.pitGuardTime; M.reset(s,now,false)
 end
 a.corner=M.cornerness(a.yawRate,a.speed,p.cornerYawRef)


 a.cornerYaw=U.clamp(1-abs(a.yawRate or 0)/p.cornerYawRef,0,1)

 s.towWait=max(0,s.towWait-dt); s.towPairWait=max(0,s.towPairWait-dt); s.dirtyLogWait=max(0,s.dirtyLogWait-dt)
 local m=H.aeroMap(e,frame)

 if (p.towBreakEnabled or p.slipstreamEnabled and (profile=='C' or profile=='P' or profile=='Q')) and m.bins>0 then
  if a.splineValid and a.kmh>=K.towMapSpeed then

   local b=Delta.bin(a.spline,m.bins); m.st[b]=m.st[b]+((a.corner>=K.towCorner and a.brake<=K.ruleBrake and 1 or 0)-m.st[b])*K.towMapAlpha
   if m.seen[b]<K.towMapSeen then m.seen[b]=m.seen[b]+1 end
  end
  H.aeroRuns(m,now)
 end
 if s.returning and abs(s.offset-M.reachable(s,a,p,g,s.base))<K.centerEpsilon then s.returning=false end
 Zones.at(e.zones,a.spline,s.zone)

 s.hotspot=Incidents.nearHotspot(e.incidents,a.spline,frame.length,now)
 if s.zone.caution then s.hotspot=true end -- Beta 1.61 : point difficile gardé par circuit (src/zones.lua), champ absent : neutre
 if a.pitDistance and a.pitDistance<K.pitZone then s.zone.maxOffset=min(s.zone.maxOffset,K.pitOffsetMax) end
 if now>=s.nextPerception then P.refresh(e.perception,frame.cars,frame.count,i,frame.length,e.frames); s.nextPerception=now+K.perceptionPeriod; Rear.scan(e,i,row,p,g,now) end
 P.occupancy(frame.cars,frame.count,i,g,row)


 local rearLeft,rearRight=false,false
 if p.rearAwareness then
  rearLeft=not row.left and Rear.side(s,-1,now); rearRight=not row.right and Rear.side(s,1,now)
  if rearLeft then row.left=true end
  if rearRight then row.right=true end
 end



 local heldBy=0
 if p.passAid then
  local pr=P.find(row,frame.player); local ps=e.states[frame.player]
  if ps then
   local pc=frame.cars[frame.player]
   local engaged=pr~=nil and a.corner>=K.passCornerC and pr.same and abs(pr.lat)>=K.commitLat and abs(pr.lat)<=g.occLatMax and (pr.alongside and pr.long<=0 or pr.long<0 and pr.gap<=K.commitGap and pr.sa>0)




   if engaged then
    local other=ps.committed or 0
    if other==i or other==0 or now-(ps.commitSeen or -math.huge)>K.perceptionPeriod*2 then
     Priority.commit(e,frame.player,i,pr.lat>0 and -1 or 1,now); ps.commitSeen=now
    end
    Priority.hold(e,i,frame.player,now+K.holdLineTime)
    if not s.aidPlayer then
     s.aidPlayer=true; e.stats.passCommit=(e.stats.passCommit or 0)+1
     U.log(e.log,now,'INFO',string.format('aide au depassement: %s engage sur %s (cote %s, %.0f m), %s tient sa ligne',pc.name,a.name,pr.lat*g.offsetSign>0 and 'gauche' or 'droit',max(0,pr.gap),a.name),i)
    end
   else
    if s.aidPlayer and not (pr and pr.alongside) then s.aidPlayer=false end
    if ps.committed==i and not (pr and pr.alongside) then Priority.release(e,frame.player); ps.aidLogged=0 end
   end
  end
  heldBy=Priority.held(s,now)
  if heldBy>0 then
   local side=e.states[heldBy].commitSide or 0
   if side<0 then row.left=true elseif side>0 then row.right=true end
   if s.heldCounted~=heldBy then s.heldCounted=heldBy; e.stats.lineHeld=(e.stats.lineHeld or 0)+1 end
  else s.heldCounted=0 end
 end

 local cap,yellow=Incidents.cap(e.incidents,frame,i,p,e.delta,e.states,s.persona.deltaMargin)
 s.yellow=yellow
 local regimeCap=cap



 if (yellow or e.incidents.neutral or e.incidents.red) and row.front>0 and row.neighbors[row.front].gap<K.scQueueGap then
  local front=row.neighbors[row.front]; local j=front.index


  local owes=Penalties.mayPass(e.penalties,i,j,now,frame.player,e.incidents.neutral and not e.incidents.red)
  if not owes and not Penalties.passable(frame.cars[j],e.incidents.cars[j],p,now) then
   cap=min(cap,max(K.trafficMinSpeed,frame.cars[j].kmh+max(0,front.gap-K.queueKeep)*K.queueClose))
  end
 end






 local hardQueue=false
 if e.incidents.neutral and not e.incidents.red and a.splineValid and frame.length>0 and not a.pit then
  local best,bj=K.scWatch,0
  for j=1,frame.count do
   local b=frame.cars[j]
   if j~=i and b.valid and not b.pit and b.splineValid and not (e.incidents.cars[j] and e.incidents.cars[j].incident) then
    local d=U.spline(b.spline-a.spline)*frame.length-((a.length or K.length)+(b.length or K.length))*0.5



    local jc=e.incidents.cars[j]


    if d>-((a.length or K.length)+(b.length or K.length))*0.5 and d<best and not (jc and jc.trouble) and not Penalties.mayPass(e.penalties,i,j,now,frame.player,true) and not (d<=0 and Incidents.unlapping(e.incidents,j))


     and not (j==e.incidents.safety and jc and jc.scFree) then best=d; bj=j end
   end
  end



  if bj>0 and best>=K.scQueueGap then
   local vt=frame.cars[bj].kmh/3.6
   cap=min(cap,max(K.trafficMinSpeed,math.sqrt(vt*vt+2*p.yellowDecel*max(0,best-K.queueKeep))*3.6))
   bj=0
  end
  if bj>0 then
   cap=min(cap,max(K.trafficMinSpeed,frame.cars[bj].kmh+max(0,best-K.queueKeep)*K.queueClose))

   if best<0 then cap=min(cap,max(K.trafficMinSpeed,frame.cars[bj].kmh-K.scOverlapDrop)) end
   hardQueue=best<2*K.queueKeep; s.neutralQueue=bj
  else s.neutralQueue=0 end
 else s.neutralQueue=0 end

 if Incidents.unlapping(e.incidents,i) then cap=unlapCap(e,frame,i,a,regimeCap,p); hardQueue=false; s.neutralQueue=0 end
 if cap<K.unlimitedSpeed then
  local start=cmd.yellowLimit<K.unlimitedSpeed and cmd.yellowLimit or a.kmh
  cmd.yellowLimit=U.approach(max(start,cap),cap,p.yellowDecel*3.6*dt)
  if hardQueue then cmd.yellowLimit=min(cmd.yellowLimit,cap) end
 else cmd.yellowLimit=K.unlimitedSpeed end








 local ic=e.incidents.cars[i]
 if ic then
  local trouble=false
  if (yellow or e.incidents.neutral) and not e.incidents.red and not e.incidents.relaunch and a.splineValid then
   local own=(s.freePace or 0)*3.6
   local ref=own>0 and regimeCap<K.unlimitedSpeed and min(regimeCap,own) or 0


   if ref>0 and cap>=regimeCap and a.kmh<ref*K.troubleRatio and not (row.front>0 and row.neighbors[row.front].gap<K.troubleAheadGap) then s.troubleFor=(s.troubleFor or 0)+dt else s.troubleFor=0 end
   trouble=s.troubleFor>=K.troubleTime or s.abnormal==true
   if trouble and not ic.trouble then
    e.stats.troubleCar=(e.stats.troubleCar or 0)+1
    U.log(e.log,now,'INFO',string.format('voiture en difficulte: %s (%.0f km/h, %.0f km/h permis), depassement permis sous drapeau',a.name,a.kmh,ref>0 and ref or regimeCap),i)
   end
  else s.troubleFor=0 end
  ic.trouble=trouble
 end
 local front=row.front>0 and row.neighbors[row.front] or nil
 local back=row.back>0 and row.neighbors[row.back] or nil
 local target=P.find(row,s.target)

 if not target and s.state=='AVOID' and s.target>0 and s.target<=frame.count and e.incidents.cars[s.target].incident then
  target=P.relative(a,frame.cars[s.target],frame.length,s.hazardRel)
 end
 local player=P.find(row,frame.player)
 local request=e.flash.requests[i]
 if request.untilTime>now and (not player or player.long>(a.length+frame.cars[frame.player].length)*0.5+K.passBuffer or player.gap>p.flashRange*K.lostRange) then request.untilTime=0 end
 local ai=e.flash.ai[i]
 if ai.untilTime>now then
  local source=P.find(row,ai.source)
  if not source or source.long>(a.length+frame.cars[ai.source].length)*0.5+K.passBuffer or source.gap>p.flashRange*K.lostRange then ai.untilTime=0 end
 end
 s.playerGap=player and player.gap or math.huge; s.playerSa=player and player.sa or 0



 if player and player.long>0 and s.playerBehind and player.gap<=K.courtesyRange then s.passedByPlayerAt=now end
 s.playerBehind=player~=nil and player.long<=0
 local passedByPlayer=profile~='C' and player~=nil and player.long>0 and now-s.passedByPlayerAt<K.courtesyTime
 local courtesy=profile~='C' and player~=nil and player.gap<=K.courtesyRange and (player.long<=0 or passedByPlayer)
 s.lappedByPlayer=player and Classes.laps(a,frame.cars[frame.player],player,frame.length)>0 or false
 s.alongside=false
 for j=1,row.count do local r=row.neighbors[j]; if r.alongside and abs(r.lat)>=K.nearLine and abs(r.lat)<=g.occLatMax then s.alongside=true; break end end
 local level,aggression,caution=baseModifiers(s,p,now,a)
 s.baseCaution=caution; s.baseAggression=aggression


 aggression=aggression*(s.moodAggr or 1); caution=caution*(s.moodCaution or 1)
 if courtesy then aggression=aggression*K.courtesyAggression end
 local desired=0; local elapsed=now-math.max(e.startedAt,e.launchAt or -math.huge)

 local yieldEvaluated=false
 cmd.active=true; cmd.brake=0


 local startWin=p.startDelay+min(p.startRelax,K.startWindowMax)
 local startPhase=profile=='C' and elapsed<startWin



 local firstLap=(s.flW or 0)>0

 if not firstLap then s.flPassHeldFor=nil end
 s.dirty=dirtyAir(e,s,a,front,p,startPhase or firstLap)
 s.urgency=H.urgency(e,s,a,row,p,profile,frame,startPhase or firstLap)
 if s.urgency>0 then

  local blocked=front and front.long>0 and front.gap<=K.finalRange and (front.index==frame.player or not rival(e,s,a,front,p,frame))
  if not blocked then aggression=aggression*(1+p.finalAggressionPct/100*s.urgency) end
  if not m.finalLogged then
   m.finalLogged=true
   U.log(e.log,now,'INFO',string.format('fin de course: %d derniers tours, agressivite +%.0f %%, defense +%.0f %%',H.finalLapsFor(p,frame,e.race),p.finalAggressionPct,p.finalDefensePct),-1)
  end
 end






 local ownBrake=a.brake>s.appBrake+K.brakeEcho and a.brake or 0
 local braking=p.noMoveBraking and ownBrake>K.ruleBrake
 if s.spinHold and a.kmh>=K.calmExitSpeed then s.spinHold=false end
 if profile=='C' and (not frame.started or elapsed<p.startDelay) or now<s.pitExitUntil or s.spinHold then
  transition(e,s,'IDLE','start',now); s.confirm=0; s.pendingAt=0
 else
  if s.state=='IDLE' then transition(e,s,'DRIVE','ready',now) end
  if now-s.speedWindowStart>=K.contactWindow then
   local drop=s.speedWindow-a.kmh
   if p.contactRecovery and drop>=K.contactDrop and row.nearest<K.contactRange then
    s.calmUntil=now+K.calmTime; s.lastContact=now; transition(e,s,'CALM','contact',now)
   end
   s.speedWindow=a.kmh; s.speedWindowStart=now
  end
  if s.state=='CALM' then
   if now>=s.calmUntil then
    if a.kmh>=K.calmExitSpeed then transition(e,s,'DRIVE','calm_end',now) else transition(e,s,'IDLE','spun',now); s.spinHold=true end
   end
   level=level*K.calmLevel; aggression=aggression*K.calmAggression; caution=caution*K.calmCaution
  else
   local obstacle
   if p.obstacleEnabled and (profile~='C' or elapsed>=p.startDelay) then
    local jam=false



    local slowRef=firstLap and max(p.obstacleSpeedKmh,K.firstLapAvoidPct*a.kmh) or math.huge
    local refused=false
    for j=1,row.count do
     local r=row.neighbors[j]; local other=frame.cars[r.index]
     if firstLap and other.kmh>=slowRef and r.long>0 and r.gap<p.obstacleDetect and abs(r.lat)<=K.latPass then refused=refused or other.slip>K.slipDegrees or e.incidents.cars[r.index].incident==true
     elseif r.long>0 and r.gap<p.obstacleDetect and abs(r.lat)<=K.latPass and (not other.player or other.kmh<=p.obstacleSpeedKmh) then



      local abnormal=e.states[r.index].abnormal==true
      local slow=other.kmh<p.obstacleSpeedKmh and other.stopped>=K.obstacleTime or other.stopped>=K.stoppedTime or abnormal


      local approach=r.sa>=K.obstacleClosing or e.incidents.cars[r.index].incident or abnormal


      local sliding=e.incidents.cars[r.index].spin>=K.spinTime
      if slow and not approach and not sliding then jam=true end
      if (sliding or slow and approach) and (not obstacle or r.gap<obstacle.gap) then obstacle=r end
     end
    end

    if jam and not obstacle and not s.jamNoted then s.jamNoted=true; e.stats.jam=(e.stats.jam or 0)+1 elseif not jam then s.jamNoted=false end
    if not obstacle then
     local nearest,distance=0,math.huge
     for j=1,frame.count do
      local c=e.incidents.cars[j]
      if j~=i and c.incident and c.onTrack then
       local r=P.relative(a,frame.cars[j],frame.length,s.scanRel)
       if r.coherent and r.long>0 and r.gap<p.obstacleDetect and abs(r.lat)<=K.latPass and r.gap<distance then
        if frame.cars[j].kmh>=slowRef then refused=true else nearest=j; distance=r.gap end
       end
      end
     end
     if nearest>0 then obstacle=P.relative(a,frame.cars[nearest],frame.length,s.hazardRel) end
    end
    if refused and not obstacle then
     if not s.flAvoidNoted then s.flAvoidNoted=true; e.stats.flAvoid=(e.stats.flAvoid or 0)+1 end
    else s.flAvoidNoted=false
    end
   end
   if obstacle then
    if s.state~='AVOID' or s.target~=obstacle.index then s.avoidClear=0; s.avoidSide=0; s.avoidShareFor=nil end
    s.target=obstacle.index; target=obstacle; transition(e,s,'AVOID','obstacle',now)
   end
   if s.state=='AVOID' then
    s.blueVetoAt=now -- Beta 1.62 : évitement d un obstacle, excuse pour un drapeau bleu

    local share=1
    if target then
     local ob=frame.cars[target.index]
     local overlap=((a.width or 2)+(ob.width or 2))*0.5+K.avoidLatMargin-abs(target.lat)
     share=overlap<=0 and 0 or U.clamp(overlap/max(a.width or 2,1),K.avoidShareMin,1)

     if e.incidents.cars[target.index].spin>=K.spinTime then share=1 end


     if s.avoidShareFor~=target.index then s.avoidShareFor=target.index; s.avoidShare=share
     else share=max(share,s.avoidShare or 0); s.avoidShare=share end
    end
    level=level*(1-share*p.obstacleLevelDrop/100); aggression=aggression*K.avoidAggression; caution=caution*(share>0 and p.obstacleCautionMult or U.lerp(1,p.obstacleCautionMult,0.5))
    if target then
     local side=s.avoidSide~=0 and s.avoidSide or target.lat>0 and 1 or target.lat<0 and -1 or (a.leftWidth>a.rightWidth and userSide(-1,g) or a.rightWidth>a.leftWidth and userSide(1,g) or fixedSide(p.yieldSide,1,g))

     if s.avoidSide~=0 and target.lat*side<-K.nearLine then side=-side; s.avoidSide=0 end

     if s.avoidSide==0 and not sideFree(row,side) and abs(target.lat)<K.nearLine then side=-side end
     if sideFree(row,side) then s.avoidSide=side end
     if sideFree(row,side) and not s.zone.noOvertake and P.corridor(frame.cars,frame.count,i,side,target.gap,target.index,g.occLatMax) then desired=side*min(p.avoidOffset*share,p.maxSideOffset)
     else level=level*K.obstacleBlockedLevel; desired=s.offset end

     if share==0 then desired=s.base end

     local other=frame.cars[target.index]
     local moving=not e.incidents.cars[target.index].incident and not e.states[target.index].abnormal and other.kmh>=p.obstacleSpeedKmh+K.avoidClearMargin and other.slip<=K.slipDegrees and other.stopped<K.obstacleTime
     s.avoidClear=moving and s.avoidClear+dt or 0
     if target.long<-K.obstacleClear or s.avoidClear>=K.avoidRecheck then transition(e,s,'DRIVE','obstacle_clear',now) end
    else transition(e,s,'DRIVE','obstacle_lost',now) end
   else



    local rest=now<s.driveUntil
    if rest and not (s.yieldBlue and yieldStates[s.state]) then transition(e,s,'DRIVE','direction_limit',now) end
    local canYield=not s.returning and not startPhase and not s.yellow and not braking and s.lapseUntil<=now and not s.alongside and (not yieldStates[s.state] or s.state=='YIELD_OUT')
    if canYield then yieldEvaluated=true


    else s.blueVetoAt=now end
    if canYield and yieldTrigger(e,s,a,row,p,profile,now,dt,rest) then
     transition(e,s,'YIELD_IN','yield',now)
     if p.classNuance and s.yieldBlue and not s.yieldQuali and not s.abnormal then M.nuanceTruce(e,s,a,row,p,frame,now,i) end


    elseif s.alongside and passStates[s.state] and s.state~='OVT_OUT' and s.state~='OVT_ARM' then transition(e,s,'OVT_HOLD','alongside',now) end
    s.blueFull=false
    if yieldStates[s.state] then

     if s.yellow and s.state~='YIELD_OUT' then transition(e,s,'YIELD_OUT','yellow',now) end


     local amp=(s.yieldQuali and profile=='Q') and 1 or K.cornerAmpMin+(1-K.cornerAmpMin)*a.corner
     desired=s.targetSide*min(p.maxSideOffset,p.yieldOffset*amp*(s.urgent and K.urgentAmp or 1))


     s.blueFull=K.blueFullSide and profile=='C' and s.yieldBlue==true and not s.yieldQuali and not s.yieldLine
     if s.blueFull then desired=s.targetSide*p.maxSideOffset*amp end
     if p.predictableSlowClass and s.yieldClass or s.yieldLine then desired=s.base end



     local liftOk=profile=='C' or a.corner>=p.cornerMin and ownBrake<=K.ruleBrake
     if s.state=='YIELD_IN' and abs(s.offset-M.reachable(s,a,p,g,desired))<K.yieldReachedEpsilon then transition(e,s,'YIELD_HOLD','yield_position',now) end
     if s.state~='YIELD_OUT' then



      if not s.abnormal and liftOk then level=level*(1-(s.yieldBlue and K.blueSlowdown or p.yieldSlowdownPct/100)) end; aggression=aggression*K.yieldAggression
      if p.classNuance and profile=='C' and s.yieldBlue and not s.abnormal and not s.yieldQuali and not s.yieldClass then level=level*(1-Nuance.slowdown(target and target.long<0 and target.sa or K.blueFastSa))/(1-K.blueSlowdown) end


      if s.frankLift and not s.abnormal and liftOk then level=level*(1-K.frankYieldLevel) end



      if s.blueFull and not s.abnormal and a.corner>=p.cornerMin and ownBrake<=K.ruleBrake and target and target.long<0 and target.gap<=K.blueHoldGap and desired~=0 and abs(s.offset)>=0.5*abs(desired) then level=level*(1-K.blueHoldLift); s.blueLifted=true end
      if s.state=='YIELD_HOLD' then caution=caution*K.yieldHoldCaution end




      s.blueCornerHold=false
      if s.blueFull and not s.abnormal and profile=='C' and (a.corner<p.cornerMin or ownBrake>K.ruleBrake) then
       local lapper=s.bluePassedBy or s.target
       local r=lapper and lapper>0 and P.find(row,lapper)
       if r and r.long>-(a.length or K.length) and r.long<=K.blueCornerClear then
        level=level*(1-K.blueHoldLift); caution=caution*K.blueCornerCaution; s.blueCornerHold=true; e.stats.blueCornerHold=(e.stats.blueCornerHold or 0)+dt
       end
      end
     end
     if target and target.long<0 and target.gap<K.invitationGap then
      s.linger=s.linger+dt
      if (s.linger>K.invitationTime or s.urgent) and not s.abnormal and liftOk then level=level*(1-p.inviteSlowdownPct/100*U.clamp((s.linger-K.invitationTime)/K.invitationRamp+(s.urgent and 1 or 0),0,1)) end
     end
     local remaining=0
     for j=1,row.count do
      local r=row.neighbors[j]; local other=frame.cars[r.index]
      if r.long<0 and r.gap>=0 and r.gap<=s.yieldDetection and abs(r.lat)<=K.latYield and not yieldStates[e.states[r.index].state] then
       local laps,upper=lapOrClass(e,s,a,other,r,p,profile)
       local qualifies=profile~='C' and p.yieldEnabled and r.sa>=p.yieldBehindMargin or laps>0 and r.sa>=K.lapSpeed or upper and r.sa>=p.classYieldMargin
        or s.yieldQuali and e.quali.push[r.index] and r.sa>=-K.blueSlack
        or p.classNuance and upper and r.sa>=-K.blueSlack and Nuance.train(row,r,s.followers,frame) -- Beta 1.61 : groupe de la classe rapide
       if qualifies and not s.followers[r.index] then s.followers[r.index]=true; s.holdUntil=max(s.holdUntil,now+p.yieldHoldMin); s.postPass=false end
      end
     end
     for j=1,frame.count do
      if s.followers[j] then
       local r=P.find(row,j)
       if r and r.long<0 and r.sa<K.lostSaRatio*s.yieldMargin and r.gap>K.slowLostGap then s.followerSlow[j]=s.followerSlow[j]+dt else s.followerSlow[j]=0 end




       if j==frame.player or not (r and r.long<0 and r.sa<K.followerStallSa and r.gap>K.followerStallGap) or not s.yieldOrdinary then s.followerStall[j]=0
       elseif a.corner>=p.cornerMin then s.followerStall[j]=s.followerStall[j]+dt end
       local passed=r and r.long>(a.length+frame.cars[j].length)*0.5+K.passBuffer

       local stalled=s.followerStall[j]>(profile=='C' and K.followerStallTime or K.followerStallTimeOff)
       local lost=not r or r.gap>s.yieldDetection*K.lostRange or s.followerSlow[j]>K.slowLostTime or stalled
       if passed then s.yieldPassed=true elseif stalled and j==s.target then s.yieldStalled=true end

       if passed and s.yieldBlue and profile=='C' and K.blueCornerClear then s.bluePassedBy=j; s.passIgnore=j; s.passIgnoreUntil=max(s.passIgnoreUntil or 0,now+K.blueNoAttack) end


       if passed and p.classNuance and s.yieldBlue and not s.yieldQuali then
        Nuance.passed(e.nuance,i,j,now)
        if profile=='C' and leadLaps(frame.cars[j],a)>0 then s.relapBy=j; s.relapUntil=now+K.relapHold end
       end
       if passed or lost then s.followers[j]=false else remaining=remaining+1 end
      end
     end
     if remaining>=2 and s.yieldBlue then s.multiLeader=true end
     if remaining==0 and s.state~='YIELD_OUT' and not s.blueCornerHold then
      if not s.postPass then s.holdUntil=max(s.holdUntil,now+s.persona.holdAfter+(s.multiLeader and K.blueTrainHold or 0)); s.postPass=true end
      if now-s.yieldStart>=max(K.holdFloor,p.yieldHoldMin) and now>=s.holdUntil then



       if s.yieldPassed then transition(e,s,'YIELD_OUT','passed',now)
       else
        if s.yieldStalled then s.yieldIgnore=s.target; s.yieldIgnoreUntil=max(s.yieldIgnoreUntil,now+K.passIgnore) end
        transition(e,s,'YIELD_OUT','lost',now)
       end
      end
     end




     local blueKeep=false
     if profile=='C' and s.yieldBlue and now-s.yieldStart<=2*p.yieldMaxHold then local r=P.find(row,s.target); blueKeep=r~=nil and r.long<0 and r.gap>=0 and r.gap<=max(a.speed,1)*K.blueHoldTime end
     if not blueKeep and now-s.yieldStart>p.yieldMaxHold+(s.frankLift and K.frankYieldExtra or 0) and s.state~='YIELD_OUT' then s.ignoreTarget=s.target; s.ignoreUntil=now+K.ignoreFollower; transition(e,s,'YIELD_OUT','hold_limit',now) end
     if s.state=='YIELD_OUT' then desired=s.base; if abs(s.offset-M.reachable(s,a,p,g,s.base))<K.centerEpsilon then transition(e,s,'DRIVE','yield_end',now); s.target=0 end end
    elseif passStates[s.state] then
     if s.yellow and not s.alongside and s.state~='OVT_OUT' then transition(e,s,'OVT_OUT','abort_yellow',now) end
     desired=s.targetSide*p.overtakeOffset*(K.cornerAmpMin+(1-K.cornerAmpMin)*a.corner)


     if target and s.state~='OVT_OUT' and frame.cars[s.target] and frame.cars[s.target].pit then transition(e,s,'OVT_OUT','target_pit',now) end
     if not target then


      s.targetLost=s.targetLost+dt
      local arm=s.state=='OVT_ARM'
      local grace=arm and K.abortSlowTime or s.state~='OVT_OUT' and K.targetLostGrace or 0
      if s.targetLost>=grace then transition(e,s,'OVT_OUT','target_lost',now) else desired=arm and s.base or s.offset end
     else
      s.targetLost=0; s.passMinGap=min(s.passMinGap,target.gap)
      local alongside=target.alongside and s.state~='OVT_ARM'





      if p.passAid and (s.state=='OVT_IN' or s.state=='OVT_HOLD') then
       if s.committed~=s.target and a.corner>=K.passCornerC and target.lat*s.targetSide>=K.commitLat and target.long>-(a.length+frame.cars[s.target].length)*0.5
        and (target.alongside or target.gap<=K.commitGap) and P.corridor(frame.cars,frame.count,i,s.targetSide,K.corridorMin,s.target,g.occLatMax) then
        Priority.commit(e,i,s.target,s.targetSide,now); e.stats.passCommit=(e.stats.passCommit or 0)+1
        s.aidBonus=s.target~=frame.player and not (s.aidPair==s.target and now<(s.aidPairUntil or 0) and s.aidPairUntil-now<=K.passAidPairCooldown)
        if s.aidLogged~=s.target then
         s.aidLogged=s.target
         U.log(e.log,now,'INFO',string.format('aide au depassement: %s engage sur %s (cote %s, %.0f m), %s tient sa ligne',a.name,frame.cars[s.target].name,s.targetSide*g.offsetSign<0 and 'gauche' or 'droit',max(0,target.gap),frame.cars[s.target].name),i)
        end
       end
       if s.committed==s.target and not Priority.cornerContext(a,p,ownBrake) then
        Priority.hold(e,s.target,i,now+K.holdLineTime)
        if s.aidBonus and now-s.commitAt<=K.passAidMax then
         level=level*(1+K.passAidLevel); s.dirty=0
         s.aidPair=s.target; s.aidPairUntil=now+K.passAidPairCooldown
        end
       end
      end






      if profile=='C' and s.target~=frame.player and target.long>0 and not s.yellow and not firstLap and a.corner>=K.passCornerC
       and s.state~='OVT_OUT' and (a.wet or 0)<K.pushWetMax
       and target.gap<=max(K.pushGapMin,a.speed*K.pushTime) then
       if s.pushFor~=s.passStartAt and not (s.pushPair==s.target and now<(s.pushPairUntil or 0)) then
        s.pushFor=s.passStartAt; s.pushAt=now; s.pushPair=s.target; s.pushPairUntil=now+K.pushPairCooldown; e.stats.attackPush=(e.stats.attackPush or 0)+1

        U.log(e.log,now,'INFO',string.format('attaque poussee: %s -> %s (%.0f m, %+.0f km/h)',a.name,frame.cars[s.target].name,target.gap,target.sa),i)
       end

       local pushFor=K.pushMax
       if K.pushMaxRace and (s.passAlongside or abs(target.lat)<=K.towLat and target.gap<=(K.pushTowGap or 0)) then pushFor=K.pushMaxRace end
       if s.pushFor==s.passStartAt and now-s.pushAt<=pushFor then
        if ownBrake<=K.ruleBrake then level=level*(1+K.pushLevel) end
        caution=min(caution,K.pushCaution); s.dirty=0
       end
      end


      if profile=='C' and not firstLap and K.diveCautionRace and K.diveGapRace and (s.state=='OVT_IN' or s.state=='OVT_HOLD') and s.target~=frame.player and not s.yellow
       and ownBrake>K.ruleBrake and a.corner>=K.diveCorner and target.long>0 and (target.gap<=K.diveGapRace or s.passAlongside) then
       caution=min(caution,K.diveCautionRace); s.diveNow=now; e.stats.diveBrake=(e.stats.diveBrake or 0)+1
      end





      if (s.state=='OVT_IN' or s.state=='OVT_HOLD') and frankYield(e,frame,i,s.target,profile,g,target) then
       if s.frankFor~=s.target then
        s.frankFor=s.target; s.frankAt=now; e.stats.frankPass=(e.stats.frankPass or 0)+1
        U.log(e.log,now,'INFO',string.format('passage franc: %s -> %s (%.0f m, cible ecartee)',a.name,frame.cars[s.target].name,max(0,target.gap)),i)
       end
       if now-s.frankAt<=K.frankMax then level=level*(1+K.frankLevel); s.dirty=0 end
       caution=min(caution,s.baseCaution); aggression=max(aggression,s.baseAggression)
      end



      local yts=e.states[s.target]
      if s.state~='OVT_OUT' and yts and yts.followers and yts.followers[i] and (yts.state=='YIELD_IN' or yts.state=='YIELD_HOLD') and target.gap<K.frankTraceGap
       and (now>=(s.frankTraceAt or -math.huge) or s.frankTraceAt-now>K.frankTracePeriod) then
       s.frankTraceAt=now+K.frankTracePeriod
       local tc=e.commands[s.target]; local b=frame.cars[s.target]
       U.log(e.log,now,'INFO',string.format('suivi du depassement: %s -> %s | ecart %.0f m, lateral %.1f m, %s | lui %.0f km/h, niveau %.2f, prudence %.2f, limite %s, gaz %.2f, frein %.2f | cible %.0f km/h, niveau %.2f, limite %s, gaz %.2f',
        a.name,b.name,target.gap,abs(target.lat),s.state=='OVT_HOLD' and 'cote a cote ou en position' or 'en deboitement',a.kmh,cmd.level or 0,cmd.caution or 0,H.capText(cmd.speedLimit),cmd.throttleLimit or 1,s.appBrake or 0,
        b.kmh,tc.level or 0,H.capText(tc.speedLimit),tc.throttleLimit or 1),i)
      end
      if alongside then s.passAlongside=true; s.holdStall=0; s.holdLong=math.huge; if s.state~='OVT_OUT' then transition(e,s,'OVT_HOLD','alongside',now) end; desired=s.offset end
      if s.state=='OVT_IN' and abs(s.offset-M.reachable(s,a,p,g,desired))<K.yieldReachedEpsilon then transition(e,s,'OVT_HOLD','pass_position',now) end
      if not alongside and s.state~='OVT_OUT' then





       local race=profile=='C'
       local straight=a.corner>=K.passCornerC and ownBrake<K.passBrakeMax and not braking

       if a.corner<K.passCornerC then s.exitCornerAt=now end
       local clear=P.corridor(frame.cars,frame.count,i,s.targetSide,K.corridorMin,s.target,g.occLatMax,a.speed-K.corridorLeadMargin)
       if race and s.state=='OVT_ARM' and not straight then clear=true end
       s.attackRamp=race and not firstLap and straight and clear and (s.state=='OVT_IN' or s.state=='OVT_HOLD')








       local v=max(a.kmh/3.6,K.abortTgSpeed)
       local dv=s.passPrevV and v-s.passPrevV or 0; s.passPrevV=v
       s.passTg=(s.passTg or 0)-dt*target.sa/3.6/v-target.gap*dv/(v*v)
       if s.passMinTg==nil or s.passTg<s.passMinTg then s.passMinTg=s.passTg end
       s.abortSlow=target.long>0 and target.sa<0 and target.gap>K.abortGap and s.abortSlow+dt or 0



       if race and not straight then s.abortSlow=min(s.abortSlow,K.abortSlowTime) end
       if s.passTg-s.passMinTg<(race and K.abortTgGrowRace or K.abortTgGrow) then s.abortSlow=min(s.abortSlow,K.abortSlowTime) end
       s.passStall=s.state~='OVT_ARM' and target.long>0 and not s.passAlongside and target.sa<K.passStallSa and s.passStall+dt or 0


       if race and target.gap<(s.passMinGap or target.gap)+K.raceStallGrow then s.passStall=min(s.passStall,K.passStallTime) end
       if s.state=='OVT_ARM' and now-s.since>K.passArmMax then s.passStall=K.passStallTime+dt end
       s.passBlocked=not clear and not s.passAlongside and s.passBlocked+dt or 0


       if p.passAid and s.committed==s.target and target.sa>=-K.passAidSaMax and now-s.commitAt<=K.passAidHold then s.abortSlow=0; s.passStall=0 end





       local wakeHold=K.wakeHoldEnabled and race and not firstLap and straight and not s.passAlongside and target.long>0
        and s.target~=frame.player and target.gap<=K.wakeHoldGap and abs(target.lat)<=K.lastPullLat
        and FirstLap.nextPoint(e.fl,a,frame.length)<math.huge and not (now<(s.exitPassUntil or -math.huge))
       if wakeHold then
        s.abortSlow=min(s.abortSlow,K.abortSlowTime*0.5); s.passStall=min(s.passStall,K.passStallTime*0.5)
        e.stats.wakeHold=(e.stats.wakeHold or 0)+dt
        if now-(s.wakeHoldLog or -math.huge)>=K.wakeHoldLogPeriod then
         s.wakeHoldLog=now
         U.log(e.log,now,'INFO',string.format('attente aspiration: %s attend dans l aspiration de %s (%.0f m)',a.name,frame.cars[s.target].name,target.gap),i)
        end
       end




       local judged=profile~='C' and s.target~=frame.player and target.long>0 and not s.passAlongside
       if judged and target.gap<=s.passProgRef-K.passProgressGain then s.passProgRef=target.gap; s.passProgTime=0
       elseif judged then s.passProgTime=s.passProgTime+dt else s.passProgRef=target.gap; s.passProgTime=0 end
       local noProgress=judged and s.passProgTime>K.passProgressTime
       local tooLong=judged and U.finite(s.passStartAt) and now-s.passStartAt>K.passAttemptMax and s.passProgTime>K.passCapGrace
        or race and s.state~='OVT_ARM' and not s.passAlongside and U.finite(s.passStartAt) and now-s.passStartAt>K.raceAttemptMax
       if wakeHold then tooLong=false end


       if s.passAlongside then
        if target.long<s.holdLong-K.holdProgress then s.holdLong=target.long; s.holdStall=0 else s.holdStall=s.holdStall+dt end
       else s.holdStall=0; s.holdLong=math.huge end


       local fastBack=not s.passAlongside and back and back.sa>=K.abortFollowerSpeed and back.gap<K.abortFollowerGap
        and (profile~='C' or Classes.laps(a,frame.cars[back.index],back,frame.length)>0 or faster(p,e.states[back.index],s))




       local ts=e.states[s.target]



       local yielded=ts and ts.followers and ts.followers[i] and (ts.state=='YIELD_IN' or ts.state=='YIELD_HOLD') and (profile~='C' or ts.yieldBlue==true) or false
       if yielded then
        s.abortSlow=0; s.passStall=0; noProgress=false; tooLong=false




        if not ts.yieldLine and ts.targetSide==s.targetSide and target.long>0 and sideFree(row,-ts.targetSide) and frankYield(e,frame,i,s.target,profile,g,target)
         and directionAllowed(s,-ts.targetSide*0.5,now,p,false,-ts.targetSide*0.5) then
         s.targetSide=-ts.targetSide; e.stats.passAwaySide=(e.stats.passAwaySide or 0)+1
        end
        if profile=='C' then fastBack=false end
       end


       if p.passAid and s.committed==s.target and now-s.commitAt<=K.passAidMax then noProgress=false; tooLong=false end





       if profile~='C' then
        local aside=s.target==frame.player and abs(target.lat)>=K.inviteLat
        local slow=ts and ts.abnormal==true or queueSlow(e,frame,target)
        if yielded or aside or slow then fastBack=false end
        if aside and s.freePace>0 and frame.cars[s.target].speed<s.freePace then s.abortSlow=0; s.passStall=0 end
       end
       if s.passBlocked>K.abortBlocked or s.abortSlow>K.abortSlowTime or s.passStall>K.passStallTime or fastBack or s.holdStall>K.passHoldMax or noProgress or tooLong then
        s.aborts=s.aborts+1
        local why=s.passBlocked>K.abortBlocked and 'abort_blocked' or s.abortSlow>K.abortSlowTime and 'abort_slow' or s.passStall>K.passStallTime and 'abort_stall' or fastBack and 'abort_follower'
         or s.holdStall>K.passHoldMax and 'hold_limit' or noProgress and 'abort_noprogress' or tooLong and 'abort_timeout' or 'hold_limit'
        transition(e,s,'OVT_OUT',why,now)










        if (why=='abort_slow' or why=='abort_noprogress' or why=='abort_timeout') and profile=='C' and leadLaps(a,frame.cars[s.target])>0 then
         s.lappedHold=s.target; s.lappedHoldUntil=now+K.passLappedHold
        end
        if (why=='abort_slow' or why=='abort_noprogress' or why=='abort_timeout') and (profile=='C' or s.target~=frame.player) and not (profile=='C' and leadLaps(a,frame.cars[s.target])>0) then
         if s.passIgnore~=s.target or now>s.passIgnoreUntil+K.passIgnoreForget then s.passIgnore=s.target; s.passIgnoreCount=0; s.passReopened=nil end
         s.passIgnoreCount=s.passIgnoreCount+1




         if why=='abort_slow' and (s.passGap0 or 0)-s.passMinGap>=K.passProgressGain then s.passIgnoreCount=min(s.passIgnoreCount,K.passIgnoreStrict-1) end
         s.passIgnoreAt=now

         local hold=min(profile=='C' and K.passIgnoreMaxRace or K.passIgnoreMax,K.passIgnore*K.passIgnoreGrowth^(s.passIgnoreCount-1))
         s.passIgnoreUntil=now+hold

         if s.passIgnoreCount>=K.passIgnoreStrict then
          U.log(e.log,now,'INFO',string.format('depassement suspendu: %s -> %s apres %d echecs (%s), plus de tentative pendant %.0f s',a.name,s.passName,s.passIgnoreCount,H.passEnd[why],hold),i)
         end
         local o=e.states[s.target]
         if profile~='C' and not o.yieldBlue then o.yieldIgnore=i; o.yieldIgnoreUntil=max(o.yieldIgnoreUntil,now+hold) end
        end
       end
      end
      if s.state=='OVT_ARM' then
       desired=s.base



       if abs(target.lat)>=K.inviteLat and target.long>0 and target.sa>=0 and a.corner>=K.passCornerC and not s.alongside and ownBrake<K.passBrakeMax and not braking then
        local side=target.lat>0 and 1 or -1
        if sideFree(row,side) and P.corridor(frame.cars,frame.count,i,side,K.corridorMin,s.target,g.occLatMax) then
         s.targetSide=side; e.stats.armOpen=(e.stats.armOpen or 0)+1; transition(e,s,'OVT_IN','opened',now)
        end
       end











       local mistakeAhead=false
       if s.state=='OVT_ARM' and K.mistakePassEnabled and profile=='C' and s.target~=frame.player and target.long>0 then
        local tc=frame.cars[s.target]; local ts=e.states[s.target]
        mistakeAhead=(tc and ((tc.wheelsOut or 0)>=K.mistakeWheels or (tc.slip or 0)>=K.mistakeSlip) or ts and (ts.lapseUntil or 0)>now) and target.sa>=K.mistakePassSa and target.gap<=K.exitPassGap
       end
       if s.state=='OVT_ARM' and K.exitPassEnabled and profile=='C' and (not firstLap or mistakeAhead) and s.target~=frame.player and not s.yellow
        and target.long>0 and target.gap<=K.exitPassGap and (target.sa>=K.exitPassSa or mistakeAhead) and not s.alongside and ownBrake<K.ruleBrake and not braking
        and (mistakeAhead or now-(s.exitCornerAt or -math.huge)<=K.exitPassWindow) then
        local first=abs(target.lat)>=K.exitPassLatMin and (target.lat>0 and -1 or 1) or s.targetSide
        for _,side in ipairs({first,-first}) do
         if s.state=='OVT_ARM' and -target.lat*side<K.pullOutTargetLat and sideFree(row,side) and P.corridor(frame.cars,frame.count,i,side,K.corridorMin,s.target,g.occLatMax) then
          s.targetSide=side; s.exitPassUntil=now+K.exitPassHold; transition(e,s,'OVT_IN','pull_out',now)
          e.stats.exitPass=(e.stats.exitPass or 0)+1
          if now-(s.exitPassLog or -math.huge)>=K.exitPassLogPeriod then
           s.exitPassLog=now
           if mistakeAhead then U.log(e.log,now,'INFO',string.format('erreur devant: %s passe %s (sortie large)',a.name,frame.cars[s.target].name),i); e.stats.mistakePass=(e.stats.mistakePass or 0)+1
           else U.log(e.log,now,'INFO',string.format('sortie de virage: %s deboite pour doubler %s (+%.0f km/h)',a.name,frame.cars[s.target].name,target.sa),i) end
          end
         end
        end
       end

       if s.state=='OVT_ARM' and target.gap<=U.clamp(p.pullOutGapBase+p.pullOutGapPerMps*a.speed,p.pullOutGapBase,K.pullOutMax) and a.corner>=K.passCornerC and not s.alongside and ownBrake<K.passBrakeMax and not braking
        and -target.lat*s.targetSide<K.pullOutTargetLat and M.pullOutTime(e,a,target,frame,s) and H.seekLate(e,s,a,target,frame) then
        transition(e,s,'OVT_IN','pull_out',now)
        if s.slingNp then e.stats.slingPull=(e.stats.slingPull or 0)+1; U.log(e.log,now,'INFO',string.format('fronde: %s deboite derriere %s a %.0f m, %.0f m avant le freinage',a.name,frame.cars[s.target].name,target.gap,s.slingNp),i) end

        e.stats.pullGapN=(e.stats.pullGapN or 0)+1; e.stats.pullGapSum=(e.stats.pullGapSum or 0)+target.gap
        if s.lastPullWhy and now-(s.lastPullLog or -math.huge)>=K.lastPullLogPeriod then s.lastPullLog=now; U.log(e.log,now,'INFO',string.format('deboitement: %s deboite a %.1f m de %s (%s)',a.name,target.gap,frame.cars[s.target].name,s.lastPullWhy),i) end
        s.lastPullWhy=nil
       end



       if s.state=='OVT_ARM' and profile=='C' and not firstLap and K.diveGapRace and (braking or ownBrake>K.ruleBrake) and s.target~=frame.player and not s.yellow
        and target.long>0 and target.gap<=K.diveGapRace and target.sa>=K.diveSaRace and a.corner>=K.diveCorner and not s.alongside
        and sideFree(row,s.targetSide) and P.corridor(frame.cars,frame.count,i,s.targetSide,K.corridorMin,s.target,g.occLatMax) then
        transition(e,s,'OVT_IN','pull_out',now); e.stats.divePull=(e.stats.divePull or 0)+1
       end

       if s.state=='OVT_ARM' then local sd=H.slipSeek(e,s,a,row,p,profile,frame,now,target,braking,ownBrake,startPhase or firstLap,i,g,m); if sd then desired=sd end end
      end
      if target.long<-(a.length+frame.cars[target.index].length)*0.5-p.overtakeClearMargin then s.clear=s.clear+dt else s.clear=0 end
      if s.clear>=K.clearConfirm and s.state~='OVT_OUT' then



       local chained=p.overtakeChain and front and front.index~=s.target and front.gap<p.overtakeDetectAhead
       if chained then
        local nextCar=frame.cars[front.index]; local nextState=e.states[front.index]
        local slowNext=nextState.abnormal==true
        local potential=max(front.sa,slowNext and (s.freePace-a.speed)*3.6 or 0)
        local advantage=profile=='C' and K.passAdvantageC or K.passAdvantageJ
        local ignoredNext=front.index==s.passIgnore and now<s.passIgnoreUntil and not slowNext


        if now<s.driveUntil or activeDirections(s,now)>=K.directionLimit or s.lapseUntil>now
         or yieldStates[nextState.state] and nextState.targetSide==s.targetSide
         or ignoredNext and realAdvantage(e,s,nextState,a,p)~=true then chained=false
        elseif qualiGuard(e,i,front.index) and not slowNext then
         chained=false
         if potential>=advantage and s.qualiHeldFor~=front.index then s.qualiHeldFor=front.index; e.stats.qualiNoPass=(e.stats.qualiNoPass or 0)+1 end
        elseif firstLap and H.firstLapHeld(s,a,nextCar,nextState,ownBrake,potential,advantage) then
         chained=false
         if s.flPassHeldFor~=front.index then s.flPassHeldFor=front.index; e.stats.flPass=(e.stats.flPass or 0)+1 end
        end
        chained=chained and P.corridor(frame.cars,frame.count,i,s.targetSide,K.corridorMin,front.index,g.occLatMax)
        if chained then
         H.passFinished(e,s,'chain',now)
         s.target=front.index; s.clear=0; s.passStall=0; s.passAlongside=false
         U.log(e.log,now,'INFO',string.format('depassement: %s -> %s (enchainement, %.0f m, %+.0f km/h)',a.name,nextCar.name,front.gap,front.sa),i)
         s.passStartAt=now; s.passGap0=front.gap; s.passMinGap=front.gap; s.passMinTg=nil; s.passTg=0; s.passPrevV=nil; s.passName=nextCar.name; s.lastPassTarget=front.index; s.lastPassAt=now
         s.passProgRef=front.gap; s.passProgTime=0


         transition(e,s,K.lastPullEnabled and profile=='C' and not firstLap and abs(front.lat)<=K.lastPullLat and front.gap>K.wakePullGap and a.corner>=K.passCornerC and 'OVT_ARM' or 'OVT_IN','chain',now)
        end
       end


       local tc=e.commands[s.target]; local tcar=frame.cars[s.target]
       local toPit=tcar~=nil and (tcar.pit or tc~=nil and (tc.rulePit or tc.stratCalled or tc.slowCalled or tc.sanCalled) and (a.kmh-(tcar.kmh or a.kmh))>=K.pitPassSa)
       if not chained then transition(e,s,'OVT_OUT',toPit and 'target_pit' or 'clear',now) end
      end
     end




     local exitHeld=s.state=='OVT_OUT' and H.exitHold(e,s,row,now,profile)
     if exitHeld then desired=s.offset end
     if s.state=='OVT_OUT' and not exitHeld then desired=s.base; if abs(s.offset-M.reachable(s,a,p,g,s.base))<K.centerEpsilon then s.restUntil=now+p.overtakeRestTime; s.target=0; transition(e,s,'DRIVE','pass_end',now) end end
     if s.state=='OVT_IN' or s.state=='OVT_HOLD' then aggression=aggression*K.passAggression; caution=min(caution,max(K.slipCautionMin,caution*K.passCaution)) end
    elseif s.state=='DEFEND' and s.towing then


     desired=s.targetSide*min(K.towOffset,p.maxSideOffset)
     local ahead=m.bins>0 and m.run[Delta.bin(a.spline,m.bins)]*frame.length/m.bins or 0
     local req=e.flash.requests[i]
     if now>=s.defendUntil or s.alongside or s.yellow or e.incidents.neutral or e.incidents.red or a.brake>K.ruleBrake or req.untilTime>now or not back
      or not sideFree(row,s.targetSide) or a.corner<p.cornerMin or ahead<K.towReturnTime*a.speed
      or s.towPair>0 and (e.states[s.towPair].state=='OVT_IN' or e.states[s.towPair].state=='OVT_HOLD') then s.towing=false; transition(e,s,'DRIVE','tow_end',now) end
    elseif s.state=='DEFEND' then
     desired=s.targetSide*min(p.defenseMaxOffset,p.maxSideOffset); aggression=aggression*K.defenseAggression; caution=caution*K.defenseCaution

     if heldBy>0 then transition(e,s,'DRIVE','held_line',now); desired=s.offset end
     local req=e.flash.requests[i]
     if now>=s.defendUntil or s.alongside or s.yellow or a.brake>K.ruleBrake or req.untilTime>now or not back or not sideFree(row,s.targetSide) then transition(e,s,'DRIVE','defense_end',now) end
    else
     s.base=userSide(s.persona.laneBias,g)
     if row.nearest>K.jitterRange and heldBy==0 then s.base=s.base+(math.sin(now/s.persona.jitterPeriod*math.pi*2+s.persona.phase)+0.5*math.sin(now/s.persona.jitterPeriod2*math.pi*2-s.persona.phase))/1.5*p.personalLineJitter end


     if s.dirty>0 and not row.left and not row.right then
      local t=now*K.dirtyJitterRate
      s.base=s.base+(math.sin(t/s.persona.jitterPeriod*math.pi*2+s.persona.phase)+0.5*math.sin(t/s.persona.jitterPeriod2*math.pi*2-s.persona.phase))/1.5*s.dirty*max(K.dirtyJitterAmp,p.personalLineJitter*K.dirtyJitterGain)
     end
     s.base=s.base+(s.zone.lineOffset or 0)+(s.formOffset or 0) -- Beta 1.61 : ligne de la zone (src/zones.lua), file du tour de formation (src/antics.lua)
     local baseMax=s.formWeave and K.formWeaveMax or K.baseMax -- Correctif 1.61 : zigzag du tour de formation
     s.base=U.clamp(s.base,-baseMax,baseMax); desired=s.base
     local defend=false

     local boost=s.urgency>0 and back and back.index~=frame.player and rival(e,s,a,back,p,frame) and 1+p.finalDefensePct/100*s.urgency or 1






     local defendOk=heldBy==0 and profile=='C' and p.defenseEnabled and not firstLap and back~=nil and abs(back.lat)>=K.defenseLatMin and (back.sa<=K.defenseSaMax or back.ttc>=K.defenseTTCMin) and a.corner>=K.defenseCorner
      and not back.alongside and now>=(s.pitGuardUntil or 0) and not (e.strategy and e.strategy.cars[i] and e.strategy.cars[i].outLap)
      and not (a.pitDistance and a.pitDistance<K.pitZone)



     local coverOk=K.coverEnabled and heldBy==0 and profile=='C' and p.defenseEnabled and not firstLap and back~=nil and abs(back.lat)<=K.coverLatMax
      and back.gap<=K.coverGap and back.sa>=K.coverSaMin and a.corner>=K.defenseCorner and not back.alongside and now>=(s.pitGuardUntil or 0)
      and not (e.strategy and e.strategy.cars[i] and e.strategy.cars[i].outLap) and not (a.pitDistance and a.pitDistance<K.pitZone)
     if defendOk and m.bins>0 and a.splineValid and frame.length>0 then

      local b=Delta.bin(a.spline,m.bins); local nb=b%m.bins+1
      if p.towBreakEnabled and m.at>-math.huge and m.seen[nb]>=K.towMapSeen and m.run[b]*frame.length/m.bins<K.defenseRunTime*a.speed then defendOk=false end
     end
     local junction=e.merge and e.merge.spline or -1
     if defendOk and junction>=0 and frame.length>0 then local after=U.spline(a.spline-junction)*frame.length; if after>=-K.towMergeBefore and after<=K.towMergeAfter then defendOk=false; coverOk=false end end


     if defendOk and (s.abnormal==true or e.incidents.cars[i] and e.incidents.cars[i].trouble or (s.freePace or 0)>0 and a.speed<s.freePace*K.troubleRatio) then defendOk=false; coverOk=false end
     if defendOk and not s.returning and not startPhase and not s.yellow and a.brake<=K.ruleBrake and s.lapseUntil<=now and profile=='C' and p.defenseEnabled and back and back.gap<p.defenseTriggerGap*boost and back.sa>0 and a.corner>=K.passCornerC and not s.alongside and now>=s.defendCooldown and directionBudget(s,now,p) and not s.defendUsed and e.flash.requests[i].untilTime<=now then
      local laps,upper=lapOrClass(e,s,a,frame.cars[back.index],back,p,profile)



      local late=false
      if p.rearAwareness then
       local os=e.states[back.index]
       late=max(0,back.gap)/(back.sa/3.6)<=Rear.horizon(s,p) or abs(back.lat)>=K.defensePulledLat or back.index~=frame.player and (os.state=='OVT_IN' or os.state=='OVT_HOLD')
       if late and laps==0 and not upper and not s.defendLate then
        s.defendLate=true; e.stats.defenceLate=(e.stats.defenceLate or 0)+1
        U.log(e.log,now,'INFO',string.format('defense non lancee: %s, %s deja decale ou trop pres',a.name,frame.cars[back.index].name),i)
       end
      end


      local unlap=p.classNuance and laps==0 and H.lapsAhead(a,frame.cars[back.index],back,frame.length)>0
      if unlap and (now>=(s.unlapLogAt or -math.huge) or (s.unlapLogAt or 0)-now>K.nuanceLogGap) then
       s.unlapLogAt=now+K.nuanceLogGap; e.stats.unlap=(e.stats.unlap or 0)+1
       U.log(e.log,now,'INFO',string.format('retardataire: %s se dedouble de %s (%+.0f km/h), sans defense',frame.cars[back.index].name,a.name,back.sa),i)
      end
      if not late and not unlap and laps==0 and not upper and (s.defendAttacker~=back.index or s.defendLap~=a.lap) then
       s.defendAttacker=back.index; s.defendLap=a.lap
       local probability=min(1,(K.defenseChance+K.defenseAssert*s.persona.assertiveness)*boost)
       local side=back.lat>0 and -1 or 1
       if U.unit(g.seed,i,a.lap+back.index)<probability and sideFree(row,side) then
        s.targetSide=side; s.defendUntil=now+K.defenseTime; s.defendCooldown=now+p.defenseCooldown/boost; s.defendUsed=true; s.towing=false
        transition(e,s,'DEFEND','attacker',now); defend=true
        if now>=(s.defendLogAt or -math.huge) or (s.defendLogAt or 0)-now>K.defenseLogGap then
         s.defendLogAt=now+K.defenseLogGap
         U.log(e.log,now,'INFO',string.format('defense: %s couvre %s cote %s (%.0f m, ecart lateral %.1f m, %+.0f km/h, lacet %.3f rad/s)',a.name,frame.cars[back.index].name,side<0 and 'gauche' or 'droit',back.gap,abs(back.lat),back.sa,abs(a.yawRate or 0)),i)
        end
       end
      end
     end




     if not defend and coverOk and not s.returning and not startPhase and not s.yellow and not e.incidents.neutral and not e.incidents.red
      and a.brake<=K.ruleBrake and s.lapseUntil<=now and a.corner>=K.passCornerC and not s.alongside and now>=s.defendCooldown and directionBudget(s,now,p)
      and not s.defendUsed and e.flash.requests[i].untilTime<=now and (s.coverAttacker~=back.index or s.coverLap~=a.lap)
      and m.bins>0 and m.at>-math.huge and a.splineValid and frame.length>0 then
      local b=Delta.bin(a.spline,m.bins)
      local ahead=m.seen[b]>=K.towMapSeen and m.run[b]*frame.length/m.bins or -1
      if ahead>=K.coverAheadMin and ahead<=K.coverAheadMax then
       local laps,upper=lapOrClass(e,s,a,frame.cars[back.index],back,p,profile)
       local turn=laps==0 and not upper and H.lapsAhead(a,frame.cars[back.index],back,frame.length)<=0 and Snapshot.turnAhead((a.spline+ahead/frame.length)%1,frame.length) or 0
       if turn~=0 then
        s.coverAttacker=back.index; s.coverLap=a.lap
        local side=turn>0 and -1 or 1
        local probability=min(1,(K.coverChance+K.coverAssert*s.persona.assertiveness)*boost)
        if U.unit(g.seed,i,a.lap*K.coverSeed+back.index)<probability and sideFree(row,side) then
         s.targetSide=side; s.defendUntil=now+min(K.coverTimeMax,ahead/max(a.speed,1)); s.defendCooldown=now+p.defenseCooldown/boost; s.defendUsed=true; s.towing=false
         transition(e,s,'DEFEND','cover',now); defend=true
         e.stats.defenceCover=(e.stats.defenceCover or 0)+1
         if now>=(s.coverLogAt or -math.huge) or (s.coverLogAt or 0)-now>K.coverLogGap then
          s.coverLogAt=now+K.coverLogGap
          U.log(e.log,now,'INFO',string.format('defense anticipee: %s couvre l interieur devant %s (%.0f m avant le freinage)',a.name,frame.cars[back.index].name,ahead),i)
         end
        end
       end
      end
     end
     if not defend and H.towStart(e,s,a,back,row,p,profile,frame,now,startPhase or firstLap,braking,m,i,g) then defend=true end

     if not defend and s.state=='DRIVE' then local sd=H.slipSeek(e,s,a,row,p,profile,frame,now,front,braking,ownBrake,startPhase or firstLap,i,g,m); if sd then desired=sd end
     elseif (s.seekFront or 0)~=0 then s.seekFront=0; s.seekAt=nil end

     local front=front
     if frame.player>0 and (not front or front.index~=frame.player) then
      local invitee=P.find(row,frame.player)
      if invitee and invitee.long>0 and invitee.gap<=K.inviteGap and abs(invitee.lat)>=K.inviteLat and abs(invitee.lat)<=K.inviteLatMax
       and (not front or invitee.gap<front.gap) then front=invitee end
     end


     if front and front.index==s.closeFront then s.closeMeters=s.closeMeters+(front.sa/3.6-s.closeMeters/K.closeMemory)*dt
     else s.closeFront=front and front.index or 0; s.closeMeters=0 end




     local slowPlayer=front~=nil and profile~='C' and front.index==frame.player and H.playerSlow(e,s,frame.cars[front.index],a,p)


     local slowAhead=front and (e.states[front.index].abnormal==true or slowPlayer or profile~='C' and queueSlow(e,frame,front))



     local playerAside=profile~='C' and front~=nil and front.index==frame.player and front.gap>=0 and front.gap<=K.inviteGap
      and abs(front.lat)>=K.inviteLat and H.inviteGeometry(profile,a,frame.cars[front.index],front)


     local passCorner=straightRules(profile) and K.passCornerC or p.cornerMin




     if now-(s.exitCAt or -1e9)>=K.passExitWindow or now<(s.exitCAt or 0) then s.exitRise=s.exitC~=nil and a.corner>s.exitC+K.passExitRise; s.exitC=a.corner; s.exitCAt=now end
     if profile=='C' and (s.flW or 0)==0 and not braking and ownBrake<=K.ruleBrake and (a.gas or 0)>=K.passExitGas and a.corner>=K.passCornerExitC and s.exitRise then passCorner=min(passCorner,K.passCornerExitC) end
     local slowFree=(slowAhead or playerAside) and profile~='C' and a.corner>=passCorner and front.gap<K.followRange and front.sa>=0
      and FirstLap.nextPoint(e.fl,a,frame.length)>max(a.speed,K.firstLapSpeedMin)*K.firstLapAnticipate






     local raceAttack=profile=='C' and front~=nil and front.index~=frame.player and front.gap>=0 and not s.yellow



     local dive=raceAttack and front.gap<=K.diveGap and a.corner>=K.diveCorner and front.sa>=K.diveSa
      or raceAttack and not firstLap and K.diveGapRace~=nil and (braking or ownBrake>K.ruleBrake) and front.gap<=K.diveGapRace and a.corner>=K.diveCorner and front.sa>=K.diveSaRace
     local raceSlow=raceAttack and front.gap<=K.raceSlowGap and front.sa>=K.raceSlowSa and a.corner>=passCorner
     if dive or raceSlow then slowFree=true end
     local minPass=slowAhead and min(K.speedMinPass,K.slowPassRatio*frame.cars[front.index].kmh) or K.speedMinPass
     local canPass=not s.returning and not startPhase and not s.yellow and (not braking or slowFree) and now>=(s.cornerGiveUntil or 0) and s.lapseUntil<=now and p.overtakeEnabled and front and front.gap>=0 and now>=s.restUntil and directionBudget(s,now,p) and not s.zone.noOvertake and not s.zone.passWait and not s.hotspot and not s.alongside
      and a.kmh>=minPass and (a.corner>=passCorner or dive) and (ownBrake<K.passBrakeMax or dive or raceSlow)




     local qc=e.quali and e.quali.cars
     local lapEnd=canPass and profile=='Q' and e.quali and e.quali.active and not e.quali.push[i] and not e.quali.push[front.index]
      and qc and qc[i] and qc[i].out and qc[front.index] and qc[front.index].out and not qc[front.index].cool and not slowAhead
      and a.splineValid and (1-a.spline)*frame.length<K.lapEndMeters
     if lapEnd then canPass=false; if not s.lapEndHeld then s.lapEndHeld=true; e.stats.lapEndHold=(e.stats.lapEndHold or 0)+1 end else s.lapEndHeld=false end

     if canPass and p.classNuance and not passStates[s.state] and M.nuanceGate(e,s,a,front,p,profile,frame,now,i) then canPass=false; refused(e,s,front.index,'nuanceHold') end

     if not canPass and p.overtakeEnabled and front and front.gap>=0 and front.gap<=p.overtakeDetectAhead and front.sa>=p.overtakeAheadMargin and not passStates[s.state] and not defend and not s.returning then
      refused(e,s,front.index,s.yellow and 'flag' or startPhase and 'start' or (s.zone.noOvertake or s.hotspot) and 'zone' or not directionBudget(s,now,p) and 'budget'
       or (braking and not slowFree or ownBrake>=K.passBrakeMax or a.corner<passCorner) and 'corner' or 'other')
     end


     local inviting=front and front.index==frame.player and front.long>0 and front.gap<=K.inviteGap and abs(front.lat)>=K.inviteLat and abs(front.lat)<=K.inviteLatMax
     if inviting and not passStates[s.state] and not defend then
      s.inviteWait=s.inviteWait+dt
      if s.inviteWait>=K.inviteReport and not s.inviteLogged then
       s.inviteLogged=true
       local why=s.yellow and 'drapeau jaune' or startPhase and 'depart' or s.returning and 'retour a la ligne' or (braking or ownBrake>=K.passBrakeMax) and 'freinage'
        or a.corner<passCorner and 'virage' or now<s.restUntil and 'repos apres manoeuvre' or not directionBudget(s,now,p) and 'plafond anti-zigzag'
        or s.alongside and 'voiture a cote' or a.kmh<minPass and 'trop lent' or not p.overtakeEnabled and 'depassements coupes' or s.zone.noOvertake and 'zone sans depassement' or s.zone.passWait and 'zone d attaque attendue' or s.hotspot and 'point difficile'
        or s.lapseUntil>now and 'inattention' or front.sa<=-K.inviteSa and 'joueur plus rapide'
        or not straightRules(profile) and abs(a.yawRate)*a.speed>K.inviteLatAccel and 'virage' or 'conditions de passage'
       U.log(e.log,now,'INFO',string.format('invitation du joueur non suivie: %s derriere a %.0f m (ecart lateral %.1f m, %+.0f km/h, lacet IA %.3f, joueur %.3f rad/s) : %s',
        a.name,front.gap,abs(front.lat),front.sa,abs(a.yawRate),abs(frame.cars[front.index].yawRate),why),i)
      end
     else s.inviteWait=0; s.inviteLogged=false end

     if canPass and (dive or raceSlow) and s.viaFor~=front.index then s.viaFor=front.index; local key=dive and 'diveOpen' or 'slowOpen'; e.stats[key]=(e.stats[key] or 0)+1 end
     if canPass and not defend then
      local other=frame.cars[front.index]; local margin=p.overtakeAheadMargin*U.lerp(K.assertMin,K.assertMax,s.persona.assertiveness)*U.lerp(K.gapMarginMin,1,front.gap/K.passMarginRange)
      if faster(p,s,e.states[front.index]) then margin=margin*K.classMargin end
      margin=margin*(s.zone.passMargin or 1) -- Beta 1.61 : zone d'attaque (src/zones.lua), champ absent : neutre
      local slowClass=faster(p,e.states[front.index],s)
      local lapped=not C.solo(profile) and Classes.laps(a,other,front,frame.length)>0
      if p.classNuance and lapped and profile=='C' then margin=margin*K.unlapMargin end -- Beta 1.61 : dédoublement, marge plus large
      local leaderRow=e.perception.rows[front.index]; local ahead=leaderRow and leaderRow.front>0 and leaderRow.neighbors[leaderRow.front]
      local fight=lapped and ahead and other.speed>0 and ahead.gap/other.speed<K.fightTime and abs(ahead.sa)<K.fightSpeed or false
      local advantage=profile=='C' and K.passAdvantageC or K.passAdvantageJ
      local closing=front.gap<=p.overtakeDetectAhead and front.sa>=margin and front.ttc<=p.overtakeHorizon
      local trigger=closing
      local stuck=s.stuck>=p.stuckTime*s.persona.patience
      local otherState=e.states[front.index]


      local slowTarget=(otherState.abnormal==true or profile~='C' and queueSlow(e,frame,front)) and front.gap<=p.overtakeDetectAhead

      local ignored=front.index==s.passIgnore and now<s.passIgnoreUntil and not slowTarget and not (profile=='C' and leadLaps(a,other)>0)
       or front.index==s.lappedHold and now<(s.lappedHoldUntil or 0) and not slowTarget








      if ignored and s.passIgnoreAt~=nil and now-s.passIgnoreAt>=(profile=='C' and K.passReopenWaitRace or K.passReopenWait)
       and (s.passReopened==nil and front.sa>=K.passReopenSa or s.passReopened~=nil and now-s.passReopened<=K.passReopenHold) then
       ignored=false
       if s.passReopened==nil then
        s.passReopened=now; e.stats.passReopen=(e.stats.passReopen or 0)+1
        if otherState.yieldIgnore==i then otherState.yieldIgnore=0; otherState.yieldIgnoreUntil=0 end
        U.log(e.log,now,'INFO',string.format('depassement rejuge: %s -> %s (cible de nouveau rattrapee, %.0f m, %+.0f km/h)',a.name,frame.cars[front.index].name,front.gap,front.sa),i)
       end
      end
      local adv=realAdvantage(e,s,otherState,a,p)


      local stuckTrigger=front.gap<=max(K.stuckGapMin,K.stuckGapTime*a.speed) and stuck and not ignored and front.sa>=-K.cessionSaMin
       and s.closeMeters>-K.retainLossMax and adv~=false
      trigger=trigger or stuckTrigger
      local free=s.freePace
      trigger=trigger or slowTarget


      local diveGo=dive and profile=='C' and not firstLap and K.diveGapRace~=nil and front.gap<=K.diveGapRace and front.sa>=K.diveSaRace and not ignored or false
      trigger=trigger or diveGo
      local potential=max(front.sa,(stuck or slowTarget) and (free-a.speed)*3.6 or 0)










      local yieldingToMe=(otherState.state=='YIELD_IN' or otherState.state=='YIELD_HOLD') and otherState.target==i and (not ignored or otherState.yieldBlue and not otherState.yieldClass) and front.sa>=-K.cessionSaMin
       and (otherState.yieldBlue or profile~='C' and not H.yieldRefused(e,s,otherState,a,p,profile) or adv==true or adv==nil and front.sa>=advantage)
      local invited=yieldingToMe or front.index==frame.player and abs(front.lat)>=K.inviteLat and front.gap<=K.inviteGap and front.sa>-K.inviteSa
       and H.inviteGeometry(profile,a,other,front) and not busy(frame,front.index,i)
      s.invited=invited and s.invited+dt or 0

      local frank=yieldingToMe and frankYield(e,frame,i,front.index,profile,g,front)
      if frank then s.invited=max(s.invited,K.inviteTime) end
      invited=s.invited>=K.inviteTime
      trigger=trigger or invited



      if ignored and (adv~=true or s.passIgnoreCount>=K.passIgnoreStrict) and not (stuckTrigger or slowTarget or invited) then if trigger then refused(e,s,front.index,'suspended') end; trigger=false end




      local qualiHold=qualiGuard(e,i,front.index) and not slowTarget and not invited
      if not qualiHold then s.qualiHeldFor=nil end
      if trigger and qualiHold then
       trigger=false
       if potential>=advantage and not slowClass and not fight and s.qualiHeldFor~=front.index then s.qualiHeldFor=front.index; e.stats.qualiNoPass=(e.stats.qualiNoPass or 0)+1 end
      end

      if passedByPlayer and front.index==frame.player and not invited and front.sa<K.courtesyPassSa and not slowPlayer then trigger=false end
      if trigger and not (potential>=advantage or invited or diveGo) then refused(e,s,front.index,'advantage') end
      if trigger and (potential>=advantage or invited or diveGo) and not slowClass and not fight then
       if s.passCandidate~=front.index then s.passCandidate=front.index; s.passConfirm=0 end



       local closingOnly=closing and not stuckTrigger and not invited and not slowTarget
       s.passConfirm=s.passConfirm+dt; s.passLost=0


       local lineTarget=yieldingToMe and otherState.yieldLine==true
       local side=invited and not lineTarget and (front.lat>0 and 1 or -1) or passSide(p,profile,s,front,row,other,g,a)



       local closingSpeed=max(a.speed-other.speed,slowTarget and free-other.speed or 0,K.corridorSpeedMin)
       local req=U.clamp((front.gap+a.length+other.length+2*p.overtakeClearMargin)*a.speed/closingSpeed,K.corridorMin,K.corridorMax)

       if p.classNuance and faster(p,s,otherState) and (otherState.persona.style or 0)>=K.classAmStyle then req=min(K.corridorMax*K.classAmCorridor,req*K.classAmCorridor) end
       if p.overtakeSide=='auto' and yieldStates[otherState.state] and not otherState.yieldLine and sideFree(row,-otherState.targetSide) then side=-otherState.targetSide end



       if (frank or yieldingToMe) and not otherState.yieldLine and sideFree(row,-otherState.targetSide) then side=-otherState.targetSide end




       local roomOk=true
       if not invited or lineTarget then
        local here,there=sideRoom(s,a,p,g,side),sideRoom(s,a,p,g,-side)
        if here~=nil then
         local need=K.passMinRoom/(yieldingToMe and 2 or 1)



         if here<need and there<need then
          local sh,st=M.roomSoon(s,a,p,side*g.offsetSign>0),M.roomSoon(s,a,p,-side*g.offsetSign>0)
          local pick=sh>=need and side or st>=need and sideFree(row,-side) and not (yieldStates[otherState.state] and otherState.targetSide==-side) and -side or 0


          local np=FirstLap.nextPoint(e.fl,a,frame.length)
          if pick~=0 and np<math.huge then
           if np/max(a.speed,1)>=(front.gap+a.length)/closingSpeed*K.passSoonShare then
            side=pick; here=need; there=0
            if s.soonRoomFor~=front.index then s.soonRoomFor=front.index; e.stats.passSoonRoom=(e.stats.passSoonRoom or 0)+1 end
           else refused(e,s,front.index,'short') end
          end
         end
         if here<need and there>=need and sideFree(row,-side) and not (yieldStates[otherState.state] and otherState.targetSide==-side) then side=-side; here=there; refused(e,s,front.index,'sideRoom') end
         if here<need and not slowTarget then
          roomOk=false; refused(e,s,front.index,'room')
          if s.noRoomFor~=front.index then s.noRoomFor=front.index; e.stats.passNoRoom=(e.stats.passNoRoom or 0)+1 end
         end
        end
       end

       if not lineTarget and (frank or yieldingToMe and side==-otherState.targetSide) then roomOk=true end
       local yieldingSame=yieldStates[otherState.state] and otherState.targetSide==side


       local flHeld=firstLap and not invited and H.firstLapHeld(s,a,other,otherState,ownBrake,potential,advantage)
       if firstLap then req=req*K.firstLapCorridor end
       if flHeld and s.passConfirm>=p.confirmTime then refused(e,s,front.index,'firstlap') end
       if flHeld and s.passConfirm>=p.confirmTime and s.flPassHeldFor~=front.index then s.flPassHeldFor=front.index; e.stats.flPass=(e.stats.flPass or 0)+1 end



       local eager=profile=='C' and front.index~=frame.player and front.gap<=max(a.speed,K.firstLapSpeedMin)*K.pushTime
       s.passGo=not flHeld and (frank or s.passConfirm>=(eager and min(p.confirmTime,K.raceConfirmTime) or p.confirmTime)) and roomOk
       if s.passGo and not (not closingOnly or s.closeMeters>=(ignored and K.passCloseMin*K.passIgnoreCloseMult or K.passCloseMin)*(eager and not ignored and K.raceCloseShare or 1)) then s.passGo=false; refused(e,s,front.index,'closing') end
       if s.passGo and not (sideFree(row,side) and not yieldingSame) then s.passGo=false; refused(e,s,front.index,'side') end
       if s.passGo and not P.corridor(frame.cars,frame.count,i,side,req,front.index,g.occLatMax,profile~='C' and (invited or slowTarget or playerAside) and a.speed-K.corridorLeadMargin or nil) then s.passGo=false; refused(e,s,front.index,'corridor') end
       if s.passGo then
        if s.refSeen then for key in pairs(s.refSeen) do s.refSeen[key]=nil end end
        s.target=front.index; s.targetSide=side; s.clear=0; s.abortSlow=0; s.passBlocked=0; s.passStall=0; s.passAlongside=false
        s.passConfirm=0; s.passCandidate=0
        if invited then s.ignoreTarget=front.index; s.ignoreUntil=now+K.inviteRespite end

        U.log(e.log,now,'INFO',string.format('depassement: %s -> %s (%s, %.0f m, %+.0f km/h)',a.name,other.name,yieldingToMe and 'cession' or invited and 'invitation' or slowTarget and 'cible lente' or closingOnly and 'rapprochement' or 'retenue',front.gap,front.sa),i)
        s.passStartAt=now; s.passGap0=front.gap; s.passMinGap=front.gap; s.passMinTg=nil; s.passTg=0; s.passPrevV=nil; s.passName=other.name; s.lastPassTarget=front.index; s.lastPassAt=now
        s.passProgRef=front.gap; s.passProgTime=0
        s.passBrakeFree=slowFree
        if slowTarget then e.stats.slowPass=(e.stats.slowPass or 0)+1; if not otherState.abnormal then e.stats.queuePass=(e.stats.queuePass or 0)+1 end end
        transition(e,s,profile=='C' and (not invited or a.corner<K.passCornerC) and 'OVT_ARM' or 'OVT_IN',yieldingToMe and 'yielded' or invited and 'invited' or 'pass',now)
       end
      else
       s.passLost=s.passLost+dt; if s.passLost>K.confirmReset then s.passConfirm=0; s.passCandidate=0 end
      end
     elseif not canPass then s.invited=0; s.passLost=s.passLost+dt; if s.passLost>K.confirmReset then s.passConfirm=0; s.passCandidate=0 end
     end
    end
   end
  end
 end



 if not yieldEvaluated then s.bluePending=false end
 if a.corner<K.passCornerC then s.defendUsed=false; s.defendLate=false end
 if a.corner<p.cornerMin then s.towDone=false end



 local starting=profile=='C' and frame.started and elapsed<startWin
 if starting then





  if abs(a.yawRate or 0)>K.startYaw then s.startYawTime=(s.startYawTime or 0)+dt else s.startYawTime=0 end
  local key=e.startedAt+(e.launchAt or 0)




  local freeAhead=not front or front.long<=0 or FirstLap.headway(front.gap,a.speed)>=K.firstLapPointFree
  local freeBrake=ownBrake>K.ruleBrake and freeAhead
  if freeBrake and a.kmh>=K.startBrakeKmh then
   s.startBraked=true
   if e.startPackKey~=key and a.splineValid then e.startPackKey=key; e.startPackSpline=a.spline end
  end
  local ahead=e.startPackKey==key and e.startPackSpline~=nil and a.splineValid and frame.length>0
   and ((e.startPackSpline-a.spline)%1)*frame.length<=a.speed*K.startAnticipate
  if ahead then s.startBraked=true end
  s.startAhead=ahead
  local wanted=(s.startBraked or freeBrake or s.startYawTime>=K.startYawHold) and 1 or 0
  s.startCare=U.approach(s.startCare,wanted,(wanted>s.startCare and K.startCareRise or K.startCareFall)*dt)
 else s.startCare=0; s.startYawTime=0; s.startBraked=false; s.startAhead=false end
 local launch=starting and s.startCare<K.launchCare








 local npNear=firstLap and FirstLap.nextPoint(e.fl,a,frame.length)<=max(a.speed,K.firstLapSpeedMin)*K.firstLapAnticipate
 local straightGeom=(starting or firstLap) and a.corner>=K.slipCorner and not (starting and s.startAhead) and not npNear
 local straightRun=straightGeom
 local following=front and front.gap<K.followRange and not s.alongside and (p.section_general or p.section_overtake or s.state~='DRIVE')
 if not following or not p.slipstreamEnabled or (a.cornerYaw or a.corner)<K.slipCorner or a.kmh<=K.slipSpeed then s.slipTime=0 end





 local passFree=H.passFreeOf(s,row,front)
 if passFree then e.stats.passFree=(e.stats.passFree or 0)+dt end
 if following then

  if not launch and not straightRun and not passFree then
   caution=caution*U.lerp(K.followCaution,1,(front.gap-K.followMinGap)/K.followGapRange)*s.persona.brakeMargin
   if front.ttc<K.followTTC then caution=caution*K.followTTCMult end
  end
  if p.slipstreamEnabled and (a.cornerYaw or a.corner)>=K.slipCorner and a.kmh>K.slipSpeed then s.slipTime=s.slipTime+dt; if s.slipTime>K.slipTime then caution=min(caution,max(K.slipCautionMin,caution*K.slipCaution)) end else s.slipTime=0 end
  if profile=='C' and front.index==frame.player and front.gap<K.playerFollowGap then caution=caution*K.playerCaution end
 end



 if passFree then caution=min(caution,K.passFreeCaution); s.dirty=0 end
 local closeIn=H.closeInOf(e,s,a,front,frame,p,profile,firstLap,ownBrake,starting)
 if closeIn and not s.closeIn then
  e.stats.closeIn=(e.stats.closeIn or 0)+1
  if (s.closeInLogPair~=front.index or now-(s.closeInLogAt or -math.huge)>=K.closeInLogPeriod) then
   s.closeInLogPair=front.index; s.closeInLogAt=now
   U.log(e.log,now,'INFO',string.format('sillage: %s se rapproche de %s (%.0f m, %.0f km/h)',a.name,frame.cars[front.index].name,front.gap,a.kmh),i)
  end
 end
 if s.closeIn and not closeIn then s.closeInOffAt=now end
 s.closeIn=closeIn






 s.flFree=not front or front.long<=0 or front.gap<0 or FirstLap.headway(front.gap,a.speed)>=K.firstLapPointFree
 if firstLap then
  local close=front~=nil and front.long>0 and front.gap>=0 and FirstLap.headway(front.gap,a.speed)<K.firstLapGapTime
  local approach=false
  if close then
   local fb=frame.cars[front.index].brake; local fs=e.states[front.index]
   approach=FirstLap.nextPoint(e.fl,a,frame.length)<=max(a.speed,K.firstLapSpeedMin)*K.firstLapAnticipate or fs.flFree~=false and fb>(fs.appBrake or 0)+K.brakeEcho and fb>K.ruleBrake
  end
  if approach and not s.flApproach then e.stats.flCare=(e.stats.flCare or 0)+1 end
  s.flApproach=approach
  s.flCare=U.approach(s.flCare or 0,approach and 1 or 0,(approach and K.firstLapCareRise or K.firstLapCareFall)*dt)

  local timeFactor=1
  if close and not launch and not straightRun then timeFactor=U.lerp(K.firstLapFollowCaution,1,U.clamp((FirstLap.headway(front.gap,a.speed)-K.firstLapGapMin)/(K.firstLapGapTime-K.firstLapGapMin),0,1)) end
  local wantedFactor=max(timeFactor,U.lerp(1,K.firstLapBrakeCaution,s.flCare))
  s.flFactor=U.approach(s.flFactor or 1,wantedFactor,(wantedFactor>(s.flFactor or 1) and K.firstLapCareRise or K.firstLapCareFall)*dt)
  caution=caution*U.lerp(1,s.flFactor,s.flW)
 end





 local radarTarget=0


 s.radarTTC=math.huge; s.radarSa=0; s.radarIndex=0
 if g.useBrakeAssist then
  local close,closeTTC=nil,math.huge






  local latPrev,latAt,latRate,latOpen=s.radarLatPrev,s.radarLatAt,s.radarLatRate,s.radarLatOpen
  if not latPrev then latPrev={}; latAt={}; latRate={}; latOpen={}; s.radarLatPrev=latPrev; s.radarLatAt=latAt; s.radarLatRate=latRate; s.radarLatOpen=latOpen end


  local trackLat=profile~='C' -- Beta 1.61 : une seule garde (hors course) pour le suivi latéral et l'exemption.
  local latK=trackLat and dt>0 and 1-math.exp(-dt/max(0.001,K.radarLatTau)) or 0
  for j=1,row.count do
   local r=row.neighbors[j]; local other=frame.cars[r.index]



   local lat,before,rate,held=0,nil,0,0
   if trackLat then
    lat=abs((other.x-a.x)*(-a.lz)+(other.z-a.z)*a.lx); before=latAt[r.index]==s.radarLatFrame and latPrev[r.index] or nil
    if before~=nil and dt>0 then local was=latRate[r.index] or 0; rate=was+((lat-before)/dt-was)*latK end

    held=rate>=K.radarOpenRate and (latOpen[r.index] or 0)+dt or 0
    latPrev[r.index]=lat; latAt[r.index]=now; latRate[r.index]=rate; latOpen[r.index]=held
   end
   local reach=(a.width+other.width)*0.5+K.radarLatMargin


   if r.long>0 and (r.sa/3.6>K.brakeClosing or firstLap and not straightGeom and r.gap<K.flTouchGap and r.sa/3.6>K.flTouchClosing) and abs(r.lat)<=reach then
    local ttc=max(0,r.gap)/(r.sa/3.6)
    local oi=e.incidents.cars[r.index]
    local opening=before~=nil and r.same and a.corner>=p.cornerMin and held>=K.radarOpenHold
     and abs(other.yawRate or 0)*other.speed<=K.inviteLatAccel and not (oi and oi.incident) and lat+rate*ttc>reach+K.radarClearMargin
    if not opening and ttc<closeTTC then close=r; closeTTC=ttc end
   end
  end
  s.radarLatFrame=now
  if close then s.radarTTC=closeTTC; s.radarSa=close.sa; s.radarIndex=close.index end
  if close then




   if closeTTC<K.radarWarnTTC and not launch and not straightRun and not starting and not firstLap and not (passFree and close.index==s.target) and not (s.closeIn and front and close.index==front.index) and not (now<(s.exitPassUntil or -math.huge) and close.index==s.target) then caution=caution*U.lerp(K.radarCaution,1,closeTTC/K.radarWarnTTC) end





   local radarThr=launch and not H.bogging(e,close.index,now) and K.radarLaunchTTC or K.radarTTC





   local flTail=firstLap and not starting and not straightGeom and close.sa>=K.flTailSa and close.sa<K.radarStraightObstacleKmh
    and (ownBrake>K.ruleBrake or (frame.cars[close.index].brake or 0)>K.ruleBrake)
   if flTail and closeTTC<K.radarTTC and closeTTC>=K.flGuardTTC and s.radarBrake==0 then e.stats.flTail=(e.stats.flTail or 0)+1 end
   if (starting or firstLap) and not flTail and close.gap>=K.flZoneGap and close.sa<K.radarStraightObstacleKmh and not (starting and H.bogging(e,close.index,now)) then radarThr=min(radarThr,K.flGuardTTC) end
   if s.closeIn and front and close.index==front.index then radarThr=min(radarThr,K.closeInRadarTTC) end

   if now<(s.exitPassUntil or -math.huge) and close.index==s.target then radarThr=min(radarThr,K.exitPassRadarTTC) end
   if closeTTC<radarThr then
    radarTarget=U.clamp(close.sa/3.6/K.brakeGain,K.radarMinBrake,K.radarBrakeMax)



    local lift=false

    local followed=back~=nil and back.long<0 and back.gap<max(K.radarStartFollowMin,frame.cars[back.index].speed*K.radarStartFollowTime)





    local straightHold=false

    local pushed=back~=nil and back.long<0 and back.ttc<closeTTC and not (starting and H.bogging(e,close.index,now))
    if straightGeom and pushed and close.sa<K.radarStraightObstacleKmh then straightHold=true; radarTarget=0; H.straightHoldCount(e,s,now,true)
    elseif straightRun and close.sa<K.radarStraightObstacleKmh and closeTTC>=K.firstLapLastTTC and not (starting and H.bogging(e,close.index,now)) then
     local lane=(not row.left or not row.right) and (a.leftWidth or 0)+(a.rightWidth or 0)>=K.radarLaneWidth
     if closeTTC>=K.radarStraightTTC or lane then straightHold=true; radarTarget=0; H.straightHoldCount(e,s,now,false)
     else
      radarTarget=0; lift=true; cmd.throttleLimit=min(cmd.throttleLimit or 1,U.lerp(K.radarStartLift,1,closeTTC/K.radarStraightTTC))
     end
    end
    if not straightHold and not lift and starting and not s.startBraked then
     radarTarget=min(radarTarget,K.radarStartBrakeMax)
     if followed then radarTarget=0; lift=true; cmd.throttleLimit=min(cmd.throttleLimit or 1,K.radarStartLift) end
    end




    if firstLap and not lift and not straightHold then



     local liftTo=close.sa<K.radarStraightObstacleKmh and U.lerp(K.radarStartLift,1,U.clamp(closeTTC/K.radarTTC,0,1)) or K.radarStartLift



     if not straightGeom and ownBrake>K.ruleBrake and closeTTC<K.radarTTC and close.gap<K.flZoneGap then radarTarget=min(radarTarget,K.flZoneBrakeMax); e.stats.flZoneBrake=(e.stats.flZoneBrake or 0)+(s.radarBrake==0 and 1 or 0)
     elseif closeTTC>=K.firstLapBrakeTTC or (followed or ownBrake<=K.ruleBrake) and closeTTC>=K.firstLapLastTTC then radarTarget=0; lift=true; cmd.throttleLimit=min(cmd.throttleLimit or 1,liftTo)
     elseif closeTTC>=K.firstLapLastTTC then radarTarget=min(radarTarget,K.radarStartBrakeMax) end
     if not lift and s.radarBrake==0 then e.stats.flBrake=(e.stats.flBrake or 0)+1 end
    end
    if launch and s.radarBrake==0 and not lift and not straightHold then e.startRadar=(e.startRadar or 0)+1 end

    if lift and (now>=(s.startLiftAt or -math.huge) or s.startLiftAt-now>1) then s.startLiftAt=now+1; e.startLift=(e.startLift or 0)+1; if firstLap then e.stats.flLift=(e.stats.flLift or 0)+1 end end
    if not straightHold and s.radarBrake==0 and (now>=s.radarLogAt or s.radarLogAt-now>K.radarLogPeriod) then
     s.radarLogAt=now+K.radarLogPeriod


     local why150=not (starting or firstLap) and '' or not straightGeom and ((starting and s.startAhead or npNear) and 'anticipation du freinage' or 'courbe')
      or close.sa>=K.radarStraightObstacleKmh and 'approche rapide' or closeTTC<K.firstLapLastTTC and string.format('contact %.1f s, dernier recours',closeTTC)
      or string.format('contact %.1f s, aucun couloir libre',closeTTC)
     U.log(e.log,now,'INFO',string.format('radar avant: %s %s derriere %s (%.0f m, %.0f km/h plus vite)%s',a.name,lift and 'leve le pied' or 'freine',frame.cars[close.index].name,close.gap,close.sa,
      (back and back.long<0 and string.format(', suiveur a %.0f m',back.gap) or '')..(why150~='' and ' ('..why150..')' or '')),i)
    end
   end
  end
 end
 s.radarBrake=U.approach(s.radarBrake,radarTarget,(radarTarget>s.radarBrake and K.radarApply or K.radarRelease)*dt)
 if s.radarBrake>0 then cmd.brake=max(cmd.brake,s.radarBrake) end

 s.appBrake=cmd.brake


 if profile=='C' and (not frame.started or elapsed<startWin) then
  local relax=frame.started and (elapsed-p.startDelay)/max(0.1,startWin-p.startDelay) or 0
  local care=frame.started and s.startCare or 1
  caution=caution*U.lerp(U.lerp(1,p.startCautionMult,care),1,relax); aggression=aggression*U.lerp(U.lerp(1,p.startAggrMult,care),1,relax)
  s.laneActive=false
  if s.state~='AVOID' then desired=p.startLaneHold and H.laneHold(e,s,a,row,g,frame,now,i) or 0 end
 elseif s.lane~=0 or s.laneActive then s.lane=0; s.laneActive=false
 end

 if firstLap then aggression=min(aggression,U.lerp(aggression,s.baseAggression*K.firstLapAggr,s.flW)) end
 local allowLapse=p.lapseEnabled and not s.alongside and s.state~='DEFEND' and s.state~='YIELD_IN' and s.state~='IDLE' and s.state~='CALM'
 s.fatigue=p.enduranceOverlay and now-s.lastContact>K.fatigueTime and K.fatigueGain or 1

 s.fatigue=max(s.fatigue,s.moodFatigue or 1)






 if now>=s.lapseAt and allowLapse and not s.rearClose and a.corner>=p.cornerMin and ownBrake<=K.ruleBrake
  and not (back~=nil and e.quali and e.quali.active and e.quali.push[back.index] and back.long<0 and back.gap<=max(frame.cars[back.index].speed,1)*K.qualiYieldLead)
  and not (FirstLap.nextPoint(e.fl,a,frame.length)<=max(a.speed,K.firstLapSpeedMin)*K.lapseBrakeTime)
  and not (back~=nil and back.long<0 and back.sa>=K.lapseFastKmh and back.gap<=max(frame.cars[back.index].speed,1)*K.lapseRearTime) then
  s.lapseCount=(s.lapseCount+1)%K.counterMax; Persona.nextLapse(s.persona,g.seed,i,s.lapseCount,p)
  s.lapseUntil=now+s.persona.lapseDuration; s.lapseAt=now+s.persona.lapseInterval/min(K.fatigueMax,s.fatigue)
 end
 if s.lapseUntil>now and allowLapse then
  local ramp=min((s.persona.lapseDuration-(s.lapseUntil-now))/K.lapseRamp,(s.lapseUntil-now)/K.lapseRamp,1)
  if a.corner>=p.cornerMin and ownBrake<=K.ruleBrake then level=level*(1-s.persona.lapseDrop*max(0,ramp)) end -- Beta 1.62 : jamais en virage ni au freinage
 elseif s.lapseUntil<=now then s.lapseUntil=0 end


 if s.bluePending and a.corner>=p.cornerMin and ownBrake<=K.ruleBrake then level=level*K.lapCornerLevel end
 if s.alongside and s.state~='AVOID' then aggression=p.section_general and p.aggressionPct/100*K.maxAggression or a.baseAggression or a.aiAggression; desired=s.offset; if passStates[s.state] then caution=caution*K.alongsideCaution end end


 if profile=='J' and front and front.long>0 and front.gap>=0 and not passStates[s.state] and front.gap<max(a.speed,1)*K.jFollowTime then caution=caution*K.jFollowCaution end

 local pitGuard=now<s.pitGuardUntil and front and front.gap<K.pitGuardGap
 if pitGuard then caution=caution*K.pitGuardCaution end
 if a.brake>K.brakeEmulationPedal or not passFree and front and front.gap<K.brakeEmulationRange and front.sa/3.6>K.brakeEmulationClosing then

  caution=caution*(1+K.brakeEmulationGain*(p.brakeZonePct-100)/100)*s.persona.brakeMargin*(s.wearBrake or 1)
 end


 if p.rearAwareness and front and not firstLap and a.corner>=p.cornerMin and front.gap<K.followRange then
  local fr=e.perception.rows[front.index]; local second=fr.front>0 and fr.neighbors[fr.front] or nil
  local c2=second and second.gap<K.followRange and frame.cars[second.index] or nil
  if c2 and c2.valid and (c2.brake or 0)>K.ruleBrake and c2.speed<a.speed then caution=caution*K.intentCaution end
 end


 if (s.committed or 0)>0 and not ((s.state=='OVT_IN' or s.state=='OVT_HOLD') and s.committed==s.target) then Priority.release(e,i); s.aidLogged=0 end
 if heldBy>0 then aggression=min(aggression,s.baseAggression) end
 if s.state~='DRIVE' then s.blockedYield=0 end
 if s.blockedYield>K.blockedYieldTime and back and back.gap<K.blockedYieldGap and not s.abnormal then level=level*(1-p.yieldSlowdownPct/100) end


 if p.aiFlashEnabled and front and front.gap>=0 and not s.yellow and not startPhase and now-s.aiFlashAt>=K.aiFlashCooldown
  and a.kmh>K.flashSpeed and a.corner>=p.cornerMin and s.state~='IDLE' and s.state~='CALM' and s.state~='AVOID' then
  local other=frame.cars[front.index]; local otherState=e.states[front.index]
  local free=s.freePace
  local held=front.gap<K.aiFlashGap and s.stuck>=p.stuckTime and (free-other.speed)*3.6>=p.flashMinAdvantage
  local allowed=held and profile~='C'
  if held and profile=='C' then
   allowed=faster(p,s,otherState) or Classes.laps(other,a,P.relative(other,a,frame.length,s.scanRel),frame.length)>0
  end

  if allowed and qualiGuard(e,i,front.index) then allowed=false end


  if allowed and profile~='C' and front.index==s.passIgnore and now<s.passIgnoreUntil then allowed=false end


  if allowed and profile~='C' and (front.index==s.flashMute and now<s.flashMuteUntil or front.index==s.flashHoldTarget and now<s.flashHoldUntil) then allowed=false end
  if allowed and other.control and not other.player and not yieldStates[otherState.state] then
   local request=e.flash.ai[front.index]
   s.aiFlashAt=now; cmd.flashEvent=(cmd.flashEvent%K.counterMax)+1; e.stats.flash=(e.stats.flash or 0)+1
   U.log(e.log,now,'INFO',string.format('appel de phares: %s -> %s',a.name,other.name),i)
   request.source=i; request.untilTime=now+p.flashRequestTTL
   request.readyAt=now+U.clamp(otherState.persona.reaction or K.neutralReaction,K.flashReactionMin,K.flashReactionMax)
  end
 end



 if profile=='C' and p.overtakeMode and not s.yellow and not startPhase and not e.weather.wet and e.drsRule.leader>=K.overtakeDetect then
  if s.overtakeSpline>=0 and s.overtakeSpline<K.overtakeDetect and a.spline>=K.overtakeDetect and a.spline-s.overtakeSpline<0.5 then
   s.overtakeArmed=front~=nil and a.speed>0 and front.gap/a.speed<=p.overtakeModeGap
  end
  if s.overtakeArmed and a.corner>=p.cornerMin then level=level*(1+p.overtakeModeBoostPct/100) end
 else s.overtakeArmed=false end
 s.overtakeSpline=a.splineValid and a.spline or -1

 do
  local by=H.overlapYieldOf(e,s,a,row,frame,p,profile,firstLap,ownBrake,starting,i)
  if by then
   s.ovyStart=s.ovyStart or now
   if now-s.ovyStart>K.overlapYieldMax then s.ovyBlockUntil=now+K.overlapYieldHoldOff; s.ovyStart=nil
   else
    cmd.throttleLimit=min(cmd.throttleLimit or 1,1-K.overlapYieldThrottle)
    if not s.ovyOn then
     e.stats.overlapYield=(e.stats.overlapYield or 0)+1
     if now-(s.ovyLogAt or -math.huge)>=K.overlapYieldLogPeriod then
      s.ovyLogAt=now
      U.log(e.log,now,'INFO',string.format('chevauchement: %s laisse passer %s en ligne droite (%.0f km/h)',a.name,frame.cars[by].name,a.kmh),i)
     end
    end
   end
  else s.ovyStart=nil end
  s.ovyOn=by~=nil and s.ovyStart~=nil
 end












 local entering=not launch and s.state~='CALM' and not s.yellow and not e.incidents.neutral and not e.incidents.red and (a.corner<p.cornerMin or ownBrake>=K.passBrakeMax)
 s.cornerOut=entering and 0 or (s.cornerOut or 0)+dt

 if entering and not s.cornerPhase then
  s.cornerPhase=true; s.cornerCounted=false; s.cornerEntryAt=now; s.cornerPair=s.cornerPair or {}
  for k in pairs(s.cornerPair) do s.cornerPair[k]=nil end
  for j=1,row.count do local r=row.neighbors[j]; if r.alongside then s.cornerPair[r.index]=true end end
 elseif not entering and s.cornerOut>K.cornerPhaseGap then s.cornerPhase=false end
 local giveTo=0
 if entering then




  local duel=s.duelOut; if not duel then duel={mode='nez',inside=0,a='incertain',b='incertain'}; s.duelOut=duel end
  local window=now-s.cornerEntryAt<=K.cornerEntryWindow
  for j=1,row.count do
   local r=row.neighbors[j]; local other=frame.cars[r.index]
   local held=s.cornerGiveTo==r.index or s.cornerPair[r.index] and now-s.cornerEntryAt<=K.cornerEntryWindow






   local lapped=profile=='C' and leadLaps(other,a)>0
   if held and not (profile=='C' and not other.player and leadLaps(a,other)>0) and e.states[r.index].cornerGiveTo~=i and r.same and r.alongside and abs(r.lat)>=K.nearLine and abs(r.lat)<=g.occLatMax then
    local turn=0
    if K.duelAxles and a.axleKnown and other.axleKnown then
     if s.cornerTurnAt~=s.cornerEntryAt then s.cornerTurnAt=s.cornerEntryAt; s.cornerTurn=a.splineValid and Snapshot.turnAhead(a.spline,frame.length) or 0 end
     turn=s.cornerTurn or 0
    end
    Priority.duel(a,other,r.long,r.lat,turn,duel)
    if window and s.cornerPair[r.index] then Priority.record(s,r.index,other.identity or other.id,duel,now) end
    local gives,why=Priority.gives(duel,a,other,r.long)



    if not gives and K.duelConcede and profile=='C' and not firstLap and ownBrake>=K.duelHeavyBrake and Priority.yields(duel) then gives=true; why='chicane' end
    if lapped or gives then
     giveTo=r.index; s.cornerGiveBlue=lapped; s.cornerGiveMode=why or 'nez'
     break
    end
   end
  end
 end
 if giveTo>0 then


  if passStates[s.state] and s.state~='OVT_OUT' and giveTo==s.target then transition(e,s,'OVT_OUT','corner_priority',now); desired=s.offset
  elseif passStates[s.state] and s.state~='OVT_OUT' then desired=s.offset
  elseif s.state=='DEFEND' then transition(e,s,'DRIVE','corner_priority',now); desired=s.offset end



  local concede=K.duelConcede and profile=='C' and not firstLap and not s.cornerGiveBlue and (s.cornerGiveMode=='chicane' or ownBrake>=K.duelHeavyBrake)
  s.cornerGiveUntil=now+(concede and K.duelConcedeHold or K.cornerGiveHold)
  if concede then s.duelConcedeUntil=now+K.duelConcedeTime end
  if s.cornerGiveTo~=giveTo then
   s.cornerGiveTo=giveTo
   if not s.cornerCounted then
    s.cornerCounted=true; e.stats.cornerGive=(e.stats.cornerGive or 0)+1

    local axes=not s.cornerGiveBlue and s.cornerGiveMode=='interieur'
    if concede then e.stats.duelConcede=(e.stats.duelConcede or 0)+1 end
    if axes then e.stats.duelAxes=(e.stats.duelAxes or 0)+1 end
    U.log(e.log,now,'INFO',string.format(s.cornerGiveBlue and 'priorite au virage: %s cede a %s (drapeau bleu)' or s.cornerGiveMode=='chicane' and 'priorite au virage: %s cede a %s (freinage, sans droit a l espace)' or axes and 'priorite au virage: %s cede a %s (interieur sans droit a l espace)' or 'priorite au virage: %s cede a %s (nez derriere)',a.name,frame.cars[giveTo].name),i)
   end
  end
 else s.cornerGiveTo=0 end


 if K.duelConcede and profile=='C' and entering and giveTo==0 then for j=1,row.count do local r=row.neighbors[j]; local os=e.states[r.index]; if r.alongside and os and os.cornerGiveTo==i then desired=s.offset; s.duelKeepRoom=now; break end end end


 local liftTo=giveTo>0 and not (back and back.gap<K.cornerGiveBackGap) and (now<(s.duelConcedeUntil or 0) and K.duelConcedeLift or K.cornerGiveLift) or 1
 s.cornerLift=U.approach(s.cornerLift or 1,liftTo,K.cornerLiftRate*dt)
 if s.cornerLift<1 then cmd.throttleLimit=min(cmd.throttleLimit or 1,s.cornerLift) end


 if braking and s.state~='AVOID' and s.state~='CALM' and not (s.passBrakeFree and passStates[s.state] and profile~='C' and a.corner>=p.cornerMin and ownBrake<K.passBrakeMax) then desired=s.offset end
 if s.zone.noYield and yieldStates[s.state] or s.zone.noOvertake and passStates[s.state] then desired=s.base end
 if a.corner<K.returnCornerMin and (s.state=='YIELD_OUT' or s.state=='OVT_OUT' or s.state=='DRIVE') then desired=s.offset end
 if s.state=='IDLE' then desired=s.laneActive and s.lane or 0; s.confirm=0; s.pendingAt=0 end
 if frame.length<=0 or not a.splineValid then desired=0 end


 if now<s.driveUntil and s.state~='AVOID' and s.state~='CALM' and not (s.yieldBlue and yieldStates[s.state]) then desired=0; if s.state~='IDLE' then transition(e,s,'DRIVE','direction_limit',now) end end
 if rearLeft or rearRight then
  local move=(s.laneActive and desired or M.reachable(s,a,p,g,desired))-s.offset
  if (move<-K.rearLogMove and rearLeft or move>K.rearLogMove and rearRight) and (now>=(s.rearLogAt or -math.huge) or s.rearLogAt-now>K.defenseLogGap) then
   s.rearLogAt=now+K.defenseLogGap; e.stats.rearSide=(e.stats.rearSide or 0)+1
   local by=frame.cars[s.rearSideBy or 0]
   U.log(e.log,now,'INFO',string.format('conscience arriere: %s garde sa ligne, %s arrive cote %s (dans %.1f s, +%.0f km/h)',a.name,by and by.name or '?',move*g.offsetSign<0 and 'gauche' or 'droit',s.rearSideIn or 0,s.rearSideSa or 0),i)
  end
 end

 local yielding=s.state=='YIELD_IN' or s.state=='YIELD_HOLD'
 if yielding and desired~=0 then
  local allowed=abs(M.reachable(s,a,p,g,desired))
  s.yWant=max(s.yWant or 0,abs(desired))
  if not s.yBound or allowed<s.yBound then s.yBound=allowed end
 end
 local passing=s.state=='OVT_IN' or s.state=='OVT_HOLD'
 if passing and desired~=0 then
  local allowed=abs(M.reachable(s,a,p,g,desired))
  s.pWant=max(s.pWant or 0,abs(desired)); if not s.pBound or allowed<s.pBound then s.pBound=allowed end
 end





 s.edgePin=false
 if K.slowEdgePin and s.abnormal==true and frame.length>0 and a.splineValid and g.offsetSign~=0 and not a.pit and (s.state=='DRIVE' or yieldStates[s.state]) then
  if (s.edgeSide or 0)==0 then
   local rl,rr=sideRoom(s,a,p,g,-1),sideRoom(s,a,p,g,1)
   if rl and rr then
    s.edgeSide=rr>=rl and 1 or -1
    e.stats.slowEdge=(e.stats.slowEdge or 0)+1
    U.log(e.log,now,'INFO',string.format('IA lente: %s se range au bord (%.0f km/h, cote %s, %.1f m de place)',a.name,a.kmh,s.edgeSide*g.offsetSign>0 and 'droit' or 'gauche',max(rl,rr)),i)
   end
  end
  if (s.edgeSide or 0)~=0 then
   s.edgePin=true
   if not braking then
    local pin=s.edgeSide*p.maxSideOffset
    if sideFree(row,s.edgeSide) then desired=pin else desired=s.offset end
   end
  end
 elseif s.abnormal~=true then s.edgeSide=0 end
 cmd.offset=M.lateral(s,desired,row,a,p,g,dt,now)


 if yielding and s.yWant and abs(s.offset)>(s.yPeak or 0) then
  local right=s.offset*g.offsetSign>0
  s.yPeak=abs(s.offset); s.yRightSide=right; s.yLeft=a.leftWidth or 0; s.yRight=a.rightWidth or 0; s.yPeakM=s.yPeak*(right and s.yRight or s.yLeft)
 end
 if passing and s.pWant and abs(s.offset)>(s.pPeak or 0) then
  local right=s.offset*g.offsetSign>0
  s.pPeak=abs(s.offset); s.pPeakRight=right; s.pPeakM=s.pPeak*(right and (a.rightWidth or 0) or (a.leftWidth or 0))
 end
 if s.newDirectionLimit then s.newDirectionLimit=false; e.stats.limit=(e.stats.limit or 0)+1; U.log(e.log,now,'WARN',H.limitText(s,now),i) end






 local protect=ownBrake>K.ruleBrake or a.corner<p.cornerMin





 local floorCaution=K.diveCautionShare and s.diveNow==now and a.corner>=K.diveCorner and s.baseCaution*K.diveCautionShare or s.baseCaution
 if protect then caution=max(caution,passFree and ownBrake<=K.ruleBrake and min(floorCaution,K.passFreeCornerCaution) or floorCaution); aggression=min(aggression,s.baseAggression) end
 if passStates[s.state] or yieldStates[s.state] or s.state=='DEFEND' then s.maneuverAt=now end

 if s.dirty>0 then
  cmd.throttleLimit=min(cmd.throttleLimit or 1,1-p.dirtyAirLiftPct/100*s.dirty)
  if not s.dirtyBefore then e.stats.dirtyAir=(e.stats.dirtyAir or 0)+1 end
  if e.runtimeG.debugLog and s.dirtyLogWait<=0 and front then
   s.dirtyLogWait=K.dirtyLogPeriod
   U.log(e.log,now,'DEBUG',string.format('air sale: %s derriere %s (%.0f m)',a.name,frame.cars[front.index].name,front.gap),i)
  end
 end
 s.dirtyBefore=s.dirty>0



 if s.hotspot then caution=caution*K.hotspotCaution end



 if firstLap and not e.incidents.neutral and not e.incidents.red then
  caution=min(caution,U.lerp(caution,s.baseCaution*K.firstLapCautionMax,s.flW))
  if not s.yellow and s.state~='AVOID' and s.state~='CALM' then
   local pace=Delta.pace(e.delta,e.states,i,Delta.bin(a.spline,e.delta.bins),p.multiClass)

   if pace<=0 then pace=K.yellowUnknownPct*(s.topKmh or 0)/3.6 end
   if pace>K.firstLapFloorMinKmh/3.6 and a.speed<K.firstLapFloorPct*pace then caution=min(caution,U.lerp(caution,s.baseCaution,s.flW)) end
  end
 end
 if s.closeIn then caution=min(caution,K.closeInCaution); aggression=max(aggression,s.baseAggression or aggression) end

 if now<(s.duelConcedeUntil or 0) then caution=max(caution,(s.baseCaution or caution)*K.duelConcedeCaution) end
 local tau=s.state=='CALM' or s.state=='AVOID'
 tau=tau and K.fastModulatorTau or s.state=='YIELD_OUT' and K.yieldRecoveryTau or s.yieldBlue and yieldStates[s.state] and K.blueRecoveryTau or K.modulatorTau
 cmd.level=U.ema(cmd.level,U.clamp(level,K.minNativeLevel,K.nativeLevelMax),dt,tau)
 cmd.aggression=U.ema(cmd.aggression,U.clamp(aggression,0,K.maxAggression),dt,aggression<cmd.aggression and protect and K.fastModulatorTau or tau)
 cmd.caution=U.ema(cmd.caution,U.clamp(caution,K.minCaution,K.maxCaution),dt,caution>cmd.caution and (protect or now-(s.closeInOffAt or -math.huge)<=K.closeInReleaseTime) and K.fastModulatorTau or tau)

 if s.closeInOffAt==now and caution>cmd.caution then cmd.caution=U.clamp(caution,K.minCaution,K.maxCaution) end




 if K.cornerGuardEnabled and (a.corner or 1)<K.passCornerC and not a.player then
  local capL=max(K.cornerLevelMax,a.baseLevel or a.aiLevel or 1)
  if cmd.level>capL then cmd.level=capL; e.stats.cornerLevelCap=(e.stats.cornerLevelCap or 0)+1 end
  local floorC=min(K.cornerCautionMin,s.baseCaution or K.cornerCautionMin)
  if cmd.caution<floorC then cmd.caution=floorC; e.stats.cornerCautionFloor=(e.stats.cornerCautionFloor or 0)+1 end
 end
 cmd.levelOwned=p.section_general or abs(cmd.level-(a.baseLevel or a.aiLevel))>=K.levelEpsilon
 cmd.aggressionOwned=p.section_general or abs(cmd.aggression-(a.baseAggression or a.aiAggression))>=K.aggrEpsilon
 cmd.cautionOwned=p.section_general or abs(cmd.caution-K.defaultCaution)>=K.cautionEpsilon
 M.trafficCap(cmd,s,a,p,profile,dt)








 local close=false
 local followKmh=math.huge
 local capGap=profile~='C' and K.yieldCapGapOff or K.yieldCapGap
 if s.state=='YIELD_IN' or s.state=='YIELD_HOLD' then
  for j=1,row.count do local r=row.neighbors[j]; if s.followers[r.index] and (r.alongside or r.long<0 and r.gap<capGap) then close=true; followKmh=min(followKmh,frame.cars[r.index].kmh) end end




  if s.yieldRefStart~=s.yieldStart then s.yieldRefStart=s.yieldStart; s.yieldFollowRef=0 end
  if close and followKmh<math.huge then s.yieldFollowRef=max(s.yieldFollowRef or 0,followKmh); followKmh=s.yieldFollowRef end
 end


 if close and profile~='C' then
  local queued=0
  for j=1,row.count do local r=row.neighbors[j]; if s.followers[r.index] and not r.alongside and r.long<0 and r.gap<K.slowFollowGap then queued=queued+1 end end
  s.yieldQueueFor=queued>=2 and (s.yieldQueueFor or 0)+dt or 0
  if s.yieldQueueFor>K.yieldQueueTime then
   if s.yieldQueueStart~=s.yieldStart then s.yieldQueueStart=s.yieldStart; e.stats.yieldCapQueue=(e.stats.yieldCapQueue or 0)+1 end
   close=false
  end
 end



 if close and profile~='C' then
  local fleet=e.delta.fleet[p.multiClass and s.class or 1]
  local ref=s.freePace>0 and s.freePace or fleet and fleet[Delta.bin(a.spline,e.delta.bins)] or 0
  if s.abnormal==true or ref>0 and a.speed<ref*K.slowRatio then close=false end
 end


 if close then local room=sideRoom(s,a,p,g,s.targetSide~=0 and s.targetSide or 1); if room~=nil and s.targetSide~=0 and room<K.sideMinRoom then close=false end end





 local frankLift=false
 s.frankNowKmh=nil
 if close and (profile~='C' or s.yieldBlue) and not s.abnormal then
  local w=s.offset*g.offsetSign>0 and (a.rightWidth or 0) or (a.leftWidth or 0)
  local passer,third=false,false
  for j=1,row.count do
   local r=row.neighbors[j]; local os=e.states[r.index]
   local committed=s.followers[r.index] and os.target==i and (os.state=='OVT_IN' or os.state=='OVT_HOLD')



   if committed and abs(r.lat)>=K.passFreeLat and r.alongside then s.frankNowKmh=min(s.frankNowKmh or math.huge,frame.cars[r.index].kmh) end
   if committed and (r.alongside or r.long<0 and r.gap<K.frankLiftGap) then passer=true
   elseif not committed and r.long<0 and r.gap>=0 and r.gap<K.frankThirdGap and abs(r.lat)<=(a.width+frame.cars[r.index].width)*0.5+K.radarLatMargin then third=true end
  end
  frankLift=passer and not third and (s.yieldLine or w>0 and abs(s.offset-s.base)*w>=K.frankOffM) -- Beta 1.62 : « line », sans décalage
 end
 if frankLift and not s.frankLift then e.stats.frankLift=(e.stats.frankLift or 0)+1 end
 s.frankLift=frankLift






 if close and a.corner>=p.cornerMin and a.kmh>=(frankLift and profile~='C' and K.frankCapMinKmh or K.yieldCapMinKmh) then
  if not s.yieldCap then
   s.yieldCap=a.kmh-K.yieldTopCut; s.yieldCapNow=a.kmh

   if profile~='C' and followKmh<math.huge then s.yieldFollowRef=max(s.yieldFollowRef or 0,followKmh,a.kmh); followKmh=s.yieldFollowRef end
  end
  local target=max(K.trafficMinSpeed,s.freePace>0 and s.freePace*3.6-K.yieldTopCut or s.yieldCap)
  if profile~='C' and followKmh<math.huge then target=min(target,max(K.trafficMinSpeed,followKmh-K.yieldPassDeltaKmh)) end

  if profile=='C' and s.yieldBlue and followKmh<math.huge then target=min(target,max(K.trafficMinSpeed,followKmh-K.blueYieldDeltaKmh)) end





  if frankLift then
   local own=s.freePace>0 and s.freePace*3.6 or s.yieldCap+K.yieldTopCut
   target=min(target,max(K.trafficMinSpeed,own-K.frankDeltaKmh))
   if followKmh<math.huge then target=min(target,max(K.trafficMinSpeed,followKmh-K.frankDeltaKmh)) end
   if s.frankNowKmh then target=min(target,max(K.trafficMinSpeed,s.frankNowKmh-K.frankDeltaKmh)) end
  end
  s.yieldCapNow=target>=s.yieldCapNow and target or U.approach(s.yieldCapNow,target,(profile~='C' and K.yieldCapDecelOff or K.trafficDecelKmh)*dt)
  cmd.speedLimit=min(cmd.speedLimit,s.yieldCapNow)




 elseif profile~='C' and s.yieldCapNow and (s.state=='YIELD_IN' or s.state=='YIELD_HOLD' or back and back.gap<capGap) then
  s.yieldCap=nil; s.yieldCapNow=max(s.yieldCapNow,a.kmh)+K.yieldCapReleaseKmh*dt
  if s.yieldCapNow>=a.kmh+K.yieldCapReleaseMargin then s.yieldCapNow=nil else cmd.speedLimit=min(cmd.speedLimit,s.yieldCapNow) end
 else s.yieldCap=nil; s.yieldCapNow=nil end


 if pitGuard then
  local ahead=frame.cars[front.index].kmh
  local margin=K.pitGuardAllowance*U.lerp(0.5,1,s.persona.assertiveness)*U.clamp((front.gap-K.pitGuardMin)/(K.pitGuardGap-K.pitGuardMin),0,1)
  local cap=front.gap<K.pitGuardMin and ahead-K.pitGuardBack or ahead+margin
  cmd.speedLimit=math.min(cmd.speedLimit,math.max(math.min(K.trafficMinSpeed,ahead),cap))
 end



 local flagged=s.yellow or e.incidents.neutral or e.incidents.red
 if flagged then
 elseif profile=='C' and p.blueFlagEnabled and s.lappedByPlayer and s.playerGap<=p.blueFlagRange and (s.playerSa>0 or s.playerGap<=K.blueCloseGap) then
  s.blueWait=s.blueWait+dt
  s.blueClear=0
  if yieldStates[s.state] and s.target==frame.player then
   if not s.blueYieldLogged then s.blueYieldLogged=true; U.log(e.log,now,'INFO',string.format('drapeau bleu: %s laisse passer le joueur apres %.1f s',a.name,s.blueWait),i) end
  elseif s.blueWait>=K.blueLogTime and not s.blueWaitLogged then
   s.blueWaitLogged=true
   U.log(e.log,now,'INFO',string.format('drapeau bleu: %s devant le joueur depuis %.0f s sans le laisser passer (%s, %.0f m, %+.0f km/h)',a.name,s.blueWait,s.blueReason or 'en attente',s.playerGap,s.playerSa),i)
  end
 elseif s.playerGap>p.blueFlagRange*K.blueForgetMult or not s.lappedByPlayer then


  s.blueClear=(s.blueClear or 0)+dt
  if s.blueClear>=K.blueClearTime then s.blueWait=0; s.blueYieldLogged=false; s.blueWaitLogged=false; s.blueReason=nil end
 end



 do
  local bn=row.back>0 and row.neighbors[row.back] or nil
  local lapsB=0
  if not flagged and profile=='C' and frame.started and p.blueFlagEnabled and bn and bn.index~=frame.player and bn.gap>=0 and bn.gap<=p.blueFlagRange and (bn.sa>0 or bn.gap<=K.blueCloseGap) then
   lapsB=Classes.laps(a,frame.cars[bn.index],bn,frame.length)
  end
  if flagged then
  elseif lapsB>0 then
   if s.blueAiBy~=bn.index then s.blueAiBy=bn.index; s.blueAiWait=0; s.blueAiFree=0; s.blueAiYield=false; s.blueAiLate=false end



   if bn.gap<=K.blueCloseGap and bn.sa>=-K.blueSlack then s.blueAiWait=(s.blueAiWait or 0)+dt end; s.blueAiClear=0


   if now-(s.blueVetoAt or -math.huge)>K.blueVetoGrace then s.blueAiFree=(s.blueAiFree or 0)+dt end
   if yieldStates[s.state] and s.target==bn.index then
    if not s.blueAiYield then
     s.blueAiYield=true; e.stats.blueAiYield=(e.stats.blueAiYield or 0)+1
     U.log(e.log,now,'INFO',string.format('drapeau bleu IA: %s laisse passer %s (%d tour(s) d avance) apres %.1f s',a.name,frame.cars[bn.index].name,lapsB,s.blueAiWait),i)
    end
   elseif s.blueAiWait>=K.blueLogTime and not s.blueAiLate and not s.blueAiYield then
    s.blueAiLate=true; e.stats.blueAiLate=(e.stats.blueAiLate or 0)+1
    U.log(e.log,now,'INFO',string.format('drapeau bleu IA: %s devant %s depuis %.0f s sans la laisser passer (%s, %.0f m, %+.0f km/h)',a.name,frame.cars[bn.index].name,s.blueAiWait,s.blueReason or 'en attente',bn.gap,bn.sa),i)
   end
  elseif (s.blueAiBy or 0)>0 then
   s.blueAiClear=(s.blueAiClear or 0)+dt
   if s.blueAiClear>=K.blueClearTime then s.blueAiBy=0; s.blueAiWait=0; s.blueAiFree=0; s.blueAiYield=false; s.blueAiLate=false end
  end
 end
 pace(s,a,row,dt,p,e.delta.fleet[p.multiClass and s.class or 1],e.delta.bins)
 if front then s.gap=front.gap; s.sa=front.sa; s.ttc=front.ttc end
end
M.pace=pace
return M

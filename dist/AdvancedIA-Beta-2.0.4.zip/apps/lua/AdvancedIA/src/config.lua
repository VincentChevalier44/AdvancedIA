local U=require('src/util')
local M={version=3,release='Beta 2.0.4',profiles={'J','P','Q','C','H'},schema={},sections={'general','yield','blue','flash','overtake','lateral','human','start','accidents','rules','endurance','weather','traffic','globals','lights','strategy','sanctions'}}
local sectionKeys={}
for _,group in ipairs(M.sections) do sectionKeys[group]='section_'..group end
M.globalRuntimeKeys={'overrideAwareness','useGripBoost','useBrakeAssist','gripPerLevelPct','occLatMin','occLatMax','occMargin','occSpeedGain','seed','levelMode','debugLog'}



local presetSections={
 Nordschleife={general=true,yield=true,flash=true,overtake=true,lateral=true,human=true,accidents=true,rules=true,endurance=true,weather=true,traffic=true,lights=true},

 Circuit={general=true,yield=true,flash=true,overtake=true,lateral=true,human=true,accidents=true,rules=true,endurance=true,weather=true,traffic=true,lights=true},
 Qualifications={general=true,yield=true,flash=true,overtake=true,lateral=true,human=true,accidents=true,rules=true,endurance=true,weather=true,lights=true,sanctions=true},

 Essais={general=true,yield=true,flash=true,overtake=true,lateral=true,human=true,accidents=true,rules=true,endurance=true,weather=true,lights=true,sanctions=true},
 Course={general=true,blue=true,flash=true,overtake=true,lateral=true,human=true,start=true,accidents=true,rules=true,endurance=true,weather=true,lights=true,strategy=true,sanctions=true}}


local presetValues={









 Nordschleife={aiTurnSignals=true,multiClass=true,outLapEnabled=true,fineInputs=true,dynamicPersona=true,wearPace=true,rearAwareness=true,weatherLive=true},Qualifications={aiTurnSignals=true,multiClass=true,fineInputs=true,dynamicPersona=true,wearPace=true,rearAwareness=true,weatherLive=true,damagePit=true,qualiRuns=true},
 Course={aiTurnSignals=true,multiClass=true,overtakeSide='auto',passAid=true,rearAwareness=true,sanContact=true,startRealism=true,dynamicPersona=true,fineInputs=true,wearPace=true,strategySmart=true,weatherLive=true,damagePit=true,strategyStartVariety=true},



 Circuit={aiTurnSignals=true,multiClass=true,yieldSide='line',laneBiasEnabled=false,overtakeSide='auto',flashRange=150,flashMinAdvantage=15,outLapEnabled=true,fineInputs=true,dynamicPersona=true,wearPace=true,rearAwareness=true,weatherLive=true},
 Essais={aiTurnSignals=true,multiClass=true,levelPct=97,aggressionPct=40,paceSpreadPct=6,lapseEnabled=true,overtakeChain=true,fineInputs=true,dynamicPersona=true,wearPace=true,rearAwareness=true,weatherLive=true,damagePit=true,qualiRuns=true}}

local legacySections={
 Nordschleife={general=true,yield=true,flash=true,overtake=true,lateral=true,human=true,start=true,weather=true,traffic=true},
 Qualifications={general=true,yield=true,flash=true,overtake=true,lateral=true,human=true,start=true,weather=true},
 Essais={general=true,yield=true,flash=true,overtake=true,lateral=true,human=true,start=true,weather=true},
 Course={general=true,blue=true,flash=true,overtake=true,lateral=true,human=true,start=true,weather=true}}
local legacyGroups={general=true,yield=true,blue=true,flash=true,overtake=true,lateral=true,human=true,start=true,endurance=true,weather=true,traffic=true,globals=true}
local legacyCandidates={J={'Nordschleife','Endurance'},P={'Essais'},Q={'Qualifications'},C={'Course','Endurance'}}

M.ruleCategories={'base','F1','F1_2026','GT','Endurance'}
M.ruleProfiles={'P','Q','C'}











M.rulePresets={
 base={},
 F1={neutralization='vsc',mandatoryStops=1,pitWindowOpenPct=20,pitWindowClosePct=95,pitCompoundChange=true,redFlagWork=true,pitFuel='plan',redRestart='standing'},
 F1_2026={neutralization='vsc',mandatoryStops=1,pitWindowOpenPct=20,pitWindowClosePct=95,pitCompoundChange=true,redFlagWork=true,overtakeMode=true,rulesDrsLaps=0,pitFuel='plan',redRestart='standing'},
 GT={neutralization='fcy',fcyDeltaPct=150,mandatoryStops=1,pitWindowOpenPct=42,pitWindowClosePct=58,bopEnabled=true,proAmEnabled=true,pitFuel='plan'},
 Endurance={neutralization='fcy',fcyDeltaPct=150,slowZoneKmh=80,yellowSpeedKmh=80,maxStintMin=50,pitsClosed='pitFcySc',bopEnabled=true,proAmEnabled=true,predictableSlowClass=true,pitFuel='refuel',pitTyres=true,pitRepair=true}}



M.recommended={J='Nordschleife',P='Essais',Q='Qualifications',C='Course'}

M.integerKeys={flashMaxReactors=true,redFlagCars=true,mandatoryStops=true,penaltySeconds=true,penaltyDisqualify=true,rulesDrsLaps=true,sanTrackWarnings=true,sanServeLaps=true,finalLaps=true,sanEscalationStep=true,sanEscalationMax=true}

M.penaltyKeys={playerPenalties=true,deltaTolerance=true,penaltySeconds=true,penaltyDisqualify=true,aiPenalties=true}
M.overlayKeys={enduranceOverlay=true,stintLevelSwing=true,stintDegradationPct=true}



function M.solo(profile) return profile=='J' or profile=='H' end


M.spawnKeys={pitExitSpread=true,spawnMode=true,spawnMinCars=true,spawnPitPct=true,spawnGapVariation=true,floodRangeKm=true}


M.raceKeys={strategyEnabled=true,strategyTyreWearPct=true,strategyFuelMarginLaps=true,strategyUndercut=true,strategyRiskPct=true,strategySpreadPct=true,
 failuresEnabled=true,failureRate=true,failureLossPct=true,towBreakEnabled=true,towBreakRange=true,towBreakStraight=true,
 finalLapsEnabled=true,finalLaps=true,finalAggressionPct=true,finalDefensePct=true}
M.sanctionKeys={sanTrackLimits=true,sanTrackWarnings=true,sanCutPenalty=true,sanCutSeconds=true,sanJumpStart=true,sanPitSpeed=true,sanPitExit=true,
 sanProcedureKind=true,sanWrongWay=true,sanWrongWaySeconds=true,sanServeLaps=true,sanStopGoSeconds=true,sanTimeSeconds=true,sanUnservedTime=true,
 sanGiveBack=true,sanGiveBackSeconds=true,sanMessages=true,

 sanPlayerTrackLimits=true,sanPlayerSession=true,sanPlayerPenalty=true,sanEscalation=true,sanEscalationStep=true,sanEscalationMax=true,sanReport=true}
M.sanctionRaceKeys={sanTrackWarnings=true,sanCutPenalty=true,sanCutSeconds=true,sanJumpStart=true,sanPitSpeed=true,sanPitExit=true,sanProcedureKind=true,
 sanServeLaps=true,sanStopGoSeconds=true,sanTimeSeconds=true,sanUnservedTime=true,sanGiveBack=true,sanGiveBackSeconds=true,
 sanPlayerPenalty=true,sanEscalation=true,sanEscalationStep=true,sanEscalationMax=true,sanReport=true}

M.sanctionPracticeKeys={sanPlayerSession=true}

M.sanctionSwitches={'sanTrackLimits','sanCutPenalty','sanJumpStart','sanPitSpeed','sanPitExit','sanWrongWay','sanUnservedTime','sanGiveBack','sanMessages','sanPlayerTrackLimits','sanEscalation','sanReport'}
function M.hidden(profile,key) return M.solo(profile) and (M.penaltyKeys[key] or M.sanctionKeys[key]) or profile~='C' and (M.raceKeys[key] or M.sanctionRaceKeys[key] or M.raceOnlyKeys[key]) or (profile=='P' or profile=='Q' or profile=='H') and M.overlayKeys[key] or (profile=='C' or profile=='H') and M.spawnKeys[key] or key=='floodRangeKm' and profile~='J' or key=='qualiTraffic' and profile~='P' and profile~='Q' or key=='qualiRuns' and profile~='P' and profile~='Q' or key=='qualiCoolLaps' and profile~='Q' or profile=='C' and M.sanctionPracticeKeys[key] or key=='damagePit' and M.solo(profile) or false end

M.preferenceKeys={'flagPanel','yellowHud','yellowMessage','pitMessage','drsAssist','drsBeepVolume','deltaBeeps'}

local newKeys={}

function M.isNewKey(key) return newKeys[key]==true end
local function add(group,key,label,lo,hi,j,q,c,choices)


  M.schema[#M.schema+1]={group=group,sectionKey=sectionKeys[group],key=key,label=label,min=lo,max=hi,defaults={J=j,P=q,Q=q,C=c,H=j},choices=choices}
  if newKeys.open then newKeys[key]=true end
end
local function n(g,k,l,a,b,j,q,c) add(g,k,l,a,b,j,q,c) end
local function b(g,k,l,j,q,c) add(g,k,l,nil,nil,j,q,c) end
local function e(g,k,l,j,q,c,opts) add(g,k,l,nil,nil,j,q,c,opts) end
n('general','levelPct','Niveau (%)',40,110,95,100,100)
n('general','aggressionPct','Agressivité (%)',0,100,55,45,80)
n('general','caution','Prudence',0.5,8,1.6,2.2,1.2)
n('general','brakeZonePct','Zone de freinage émulée (%)',50,150,100,100,100)
n('general','paceSpreadPct','Dispersion du niveau (%)',0,20,8,3,2)
n('general','aggrSpreadPct','Dispersion d’agressivité (%)',0,30,12,8,10)
n('general','cautSpreadPct','Dispersion de prudence (%)',0,30,12,8,8)
newKeys.open=true
n('general','pitExitSpread','Sorties des stands étalées, essais et qualifications (s par IA, 0 = libre)',0,30,0,10,0)



e('general','spawnMode','Répartition des IA en début de session','track','pits','native',{'native','pits','track'})
n('general','spawnMinCars','Répartir à partir de (IA)',2,60,10,10,10)
n('general','spawnPitPct','IA laissées aux stands au départ (%)',0,50,25,25,25)
n('general','spawnGapVariation','Variation des écarts au départ (%)',0,100,100,100,100)
n('general','floodRangeKm','Portée d’AI flood de CSP, sous le seuil (km)',1,5,1,1,1)
newKeys.open=nil
b('yield','yieldEnabled','Cession ordinaire',true,true,false)

newKeys.open=true
b('lateral','aiTurnSignals','Clignotants des IA',true,true,true)
newKeys.open=nil

e('yield','yieldSide','Côté de cession','right','right','right',{'left','right','auto','line'})
n('yield','yieldOffset','Décalage de cession',0.2,0.95,0.65,0.8,0.6)
n('yield','yieldDetectBehind','Détection arrière (m)',30,400,100,200,80)
n('yield','yieldBehindMargin','Avantage du suiveur (km/h)',1,30,6,4,6)
n('yield','yieldHorizon','Horizon arrière (s)',3,30,10,12,8)
n('yield','confirmTime','Confirmation (s)',0.1,2,0.6,0.4,0.5)
n('yield','yieldHoldMin','Maintien minimal (s)',0.3,5,1,1,1)
n('yield','yieldHoldAfterMin','Maintien après passage min. (s)',0.2,6,0.8,0.6,0.8)
n('yield','yieldHoldAfterMax','Maintien après passage max. (s)',0.2,6,2.2,1.6,1.8)
n('yield','yieldSlowdownPct','Ralentissement en cession (%)',0,20,6,8,6)
n('yield','inviteSlowdownPct','Invitation supplémentaire (%)',0,25,10,10,10)
n('yield','yieldMaxHold','Durée maximale de cession (s)',8,60,25,25,25)

b('yield','qualiTraffic','Essais et qualifications : priorité aux tours lancés',false,true,false)

b('yield','qualiCoolLaps','Qualifications : tours de refroidissement des IA',false,true,false)
M.schema[#M.schema].defaults.P=false

newKeys.open=true
b('yield','qualiRuns','Essais et qualifications : vrais passages en piste des IA',false,false,false)
newKeys.open=nil
b('yield','pressureEnabled','Réaction à la pression',true,true,false)
n('yield','pressureGap','Distance de pression (m)',5,30,15,15,15)
n('yield','pressureTime','Durée de pression (s)',1,15,4,3,4)
b('blue','blueFlagEnabled','Drapeaux bleus',false,true,true)
n('blue','blueFlagRange','Portée du drapeau bleu (m)',50,400,150,200,150)
e('blue','blueFlagSide','Côté sous drapeau bleu','auto','auto','auto',{'auto','left','right'})
e('flash','flashMode','Appels de phares','always','always','lapped',{'never','lapped','always'})
n('flash','flashRange','Portée des appels (m)',40,250,200,200,150)
n('flash','flashMinAdvantage','Avantage pour appel (km/h)',3,40,12,8,15)
n('flash','flashCloseAdvantage','Avantage à courte distance (km/h)',-10,15,-5,-5,6)
n('flash','flashRequestTTL','Durée d’une demande (s)',3,20,8,8,8)
n('flash','flashObliviousPct','Inattention au premier appel (%)',0,40,10,5,10)
n('flash','flashMaxReactors','Nombre de réactions',1,3,3,3,3)
b('flash','hornEnabled','Klaxon en complément',false,false,false)
newKeys.open=true
b('flash','aiFlashEnabled','Appels de phares entre IA',true,true,true)
newKeys.open=nil
b('overtake','overtakeEnabled','Dépassements',true,true,true)
e('overtake','overtakeSide','Côté de dépassement','left','left','left',{'opposite','auto','left','right'})
n('overtake','overtakeOffset','Décalage de dépassement',0.2,0.95,0.7,0.65,0.6)
n('overtake','overtakeDetectAhead','Détection avant (m)',20,200,60,50,50)
n('overtake','overtakeAheadMargin','Avantage pour dépasser (km/h)',1,30,8,10,3)
n('overtake','overtakeHorizon','Horizon avant (s)',2,20,6,6,6)
n('overtake','overtakeClearMargin','Marge après dépassement (m)',8,40,18,20,10)
n('overtake','overtakeRestTime','Repos après dépassement (s)',0,10,2,3,1)
b('overtake','overtakeChain','Enchaîner les dépassements',true,false,true)
n('overtake','stuckTime','Confirmation de retenue (s)',0.5,10,2,3,1.2)
n('overtake','stuckPaceRatio','Seuil d’allure retenue',0.8,0.99,0.93,0.93,0.95)
n('overtake','pullOutGapBase','Distance de déboîtement (m)',4,15,8,8,8)
n('overtake','pullOutGapPerMps','Gain de déboîtement (s)',0,0.5,0.25,0.25,0.25)
b('overtake','slipstreamEnabled','Aspiration',true,true,true)
b('overtake','defenseEnabled','Défense',true,true,true)
n('overtake','defenseMaxOffset','Décalage maximal de défense',0.1,0.5,0.35,0.35,0.35)
n('overtake','defenseCooldown','Repos entre défenses (s)',2,30,8,8,8)
n('overtake','defenseTriggerGap','Distance de défense (m)',5,25,12,12,12)


newKeys.open=true
b('overtake','towBreakEnabled','Casser l’aspiration en ligne droite',false,false,true)
n('overtake','towBreakRange','Aspiration à casser : distance (m)',10,60,30,30,30)
n('overtake','towBreakStraight','Ligne droite minimale (m)',200,1500,400,400,400)
b('overtake','dirtyAirEnabled','Air sale derrière une voiture',false,true,true)
n('overtake','dirtyAirGap','Air sale : distance (m)',5,40,20,20,20)
n('overtake','dirtyAirLiftPct','Air sale : gaz relâchés en virage (%)',0,10,3,3,3)
b('overtake','finalLapsEnabled','Urgence des derniers tours',false,false,true)
n('overtake','finalLaps','Derniers tours concernés',1,10,3,3,3)
n('overtake','finalAggressionPct','Agressivité en plus (%)',0,50,15,15,15)
n('overtake','finalDefensePct','Défense renforcée (%)',0,100,40,40,40)
newKeys.open=nil
n('lateral','rampSpeed','Vitesse de déplacement latéral',0.1,1,0.3,0.3,0.45)
n('lateral','rampAccel','Accélération latérale',0.5,4,1.5,1.5,2)
n('lateral','lowPassTau','Lissage latéral (s)',0.05,1,0.25,0.25,0.2)
n('lateral','maxSideOffset','Décalage maximal',0.3,0.95,0.85,0.85,0.8)
n('lateral','cornerMin','Seuil de ligne droite',0,1,0.35,0.35,0.5)
n('lateral','cornerYawRef','Référence de rotation (rad/s)',0.2,1.2,0.5,0.5,0.5)
n('lateral','lateralCooldown','Repos entre directions (s)',0.3,5,1.2,1.2,1)
n('lateral','emergencyReleaseFactor','Facteur de relâchement',1,4,2,2,2)
n('human','reactMin','Réaction minimale (s)',0.1,2,0.25,0.2,0.2)
n('human','reactMax','Réaction maximale (s)',0.1,2,0.9,0.6,0.6)
n('human','awMin','Attention minimale (s)',0.2,5,0.6,0.4,0.4)
n('human','awMax','Attention maximale (s)',0.2,5,2,1.2,1.2)
n('human','paceDriftPct','Variation lente du rythme (%)',0,6,2,1,1)
n('human','personalLineJitter','Variation de trajectoire',0,0.15,0.05,0.03,0.02)
b('human','lapseEnabled','Petites baisses de concentration',true,false,false)
n('human','lapseIntervalMin','Intervalle minimal (s)',20,900,60,120,120)
n('human','lapseIntervalMax','Intervalle maximal (s)',20,900,300,600,600)
n('human','lapseDurMin','Durée minimale (s)',0.5,8,1.5,1,1)
n('human','lapseDurMax','Durée maximale (s)',0.5,8,3,2,2)
n('human','lapseDropMin','Perte minimale de rythme (%)',0,25,6,3,3)
n('human','lapseDropMax','Perte maximale de rythme (%)',0,25,12,7,7)
b('human','laneBiasEnabled','Ligne liée à l’allure',true,false,false)
n('human','laneBiasMax','Biais maximal de ligne',0,0.4,0.25,0.25,0.25)
newKeys.open=true
b('human','mistakesEnabled','Erreurs de pilotage des IA (blocages, patinage)',true,true,true)
n('human','mistakeRate','Erreurs : fréquence (par heure et par IA)',0,6,1,0.5,0.5)
newKeys.open=nil
n('start','startDelay','Attente au départ (s)',0,30,0,0,2)
n('start','startCautionMult','Prudence au départ',1,3,1,1,1.3)
n('start','startAggrMult','Agressivité au départ',0.2,1,1,1,0.8)
n('start','startRelax','Détente après départ (s)',2,30,12,12,25)
b('start','startLaneHold','Maintien de ligne au départ',false,false,false)

newKeys.open=true
b('start','firstLapCare','Premier tour attentif (départ et relances)',false,false,true)
newKeys.open=nil

b('accidents','obstacleEnabled','Évitement des voitures arrêtées ou accidentées',true,true,true)
n('accidents','obstacleSpeedKmh','Vitesse d’obstacle (km/h)',5,50,25,25,25)
n('accidents','obstacleDetect','Détection d’obstacle (m)',50,300,150,150,150)
n('accidents','obstacleLevelDrop','Réduction près d’obstacle (%)',0,50,25,25,25)
n('accidents','obstacleCautionMult','Prudence près d’obstacle',1,3,1.5,1.5,1.5)
newKeys.open=true
n('accidents','avoidOffset','Écart d’évitement',0.3,0.9,0.6,0.6,0.6)
b('accidents','contactRecovery','Récupération après contact',true,true,true)
b('accidents','incidentStop','Arrêt des IA accidentées',true,true,true)
n('accidents','incidentStopMin','Arrêt minimal (s)',1,15,3,3,3)
n('accidents','incidentStopMax','Arrêt maximal (s)',1,30,8,8,8)
n('accidents','rejoinGap','Piste libre derrière pour repartir (m)',30,300,120,120,120)
b('accidents','yellowEnabled','Drapeaux jaunes (zone d’incident)',true,true,true)
n('accidents','yellowBefore','Début de zone avant l’incident (m)',50,800,300,300,300)
n('accidents','yellowAfter','Fin de zone après l’incident (m)',0,300,50,50,50)
n('accidents','yellowHold','Maintien après dégagement (s)',0,60,10,10,10)
n('accidents','yellowDecel','Décélération d’approche (m/s²)',2,10,5,5,5)
n('accidents','zoneDeltaPct','Double jaune : temps de référence plus lent de (%)',5,200,15,15,15)
n('accidents','slowZoneKmh','Double jaune : Slow Zone à vitesse fixe (km/h, 0 = temps delta)',0,150,0,0,0)
n('accidents','yellowSpeedKmh','Double jaune : vitesse de repli, allure inconnue (km/h)',30,200,50,50,50)
b('accidents','yellowHud','Drapeau jaune natif d’AC sur le HUD',false,false,false)
b('accidents','flagPanel','Panneau de drapeaux AdvancedIA en conduite',true,true,true)
b('accidents','yellowMessage','Messages d’incident à l’écran',true,true,true)
b('accidents','deltaBeeps','Delta : bips sonores',true,true,true)
b('accidents','playerPenalties','Pénalités du joueur sous drapeau',false,true,true)
n('accidents','deltaTolerance','Delta : tolérance aux mini-secteurs (s)',0,1,0.5,0.5,0.5)
n('accidents','penaltySeconds','Pénalité : coupure des gaz (s)',2,15,5,5,5)
n('accidents','penaltyDisqualify','Infractions tolérées avant disqualification',1,20,5,5,5)
b('accidents','aiPenalties','Sanctions des IA sous drapeau',false,true,true)


b('accidents','damagePit','Arrêt aux stands pour dégâts',false,false,false)
b('rules','noMoveBraking','Pas de changement de trajectoire au freinage',true,true,true)
e('rules','neutralization','Neutralisation après un incident majeur','local','local','local',{'local','fcy','vsc','sc'})
n('rules','majorIncidentTime','Incident majeur : immobilisation en piste (s)',5,60,15,15,15)
n('rules','fcySpeedKmh','FCY : vitesse de repli, allure inconnue (km/h)',40,150,80,80,80)
n('rules','fcyDeltaPct','FCY : temps de référence plus lent de (%)',10,150,50,50,50)
n('rules','vscDeltaPct','VSC : temps de référence plus lent de (%)',10,80,30,30,30)
n('rules','neutralizationHold','Durée minimale de neutralisation (s)',10,180,30,30,30)
b('rules','safetyCarEscalation','Voiture de sécurité sur incident aggravé',false,true,true)
e('rules','restartOvertake','Dépassement permis après la relance','line','line','line',{'line','scIn'})
b('rules','redFlagEnabled','Drapeau rouge sur accident grave (essais, qualifications, course)',true,true,true)
n('rules','redFlagCars','Drapeau rouge : voitures immobilisées en piste',2,10,3,3,3)
n('rules','redFlagSpeedKmh','Drapeau rouge : vitesse de repli, allure inconnue (km/h)',40,150,80,80,80)
n('rules','redDeltaPct','Drapeau rouge : temps de référence plus lent de (%)',10,200,60,60,60)
n('rules','redFlagHold','Drapeau rouge : interruption minimale (s)',20,600,60,60,60)
b('rules','redFlagWork','Drapeau rouge : pneus changés aux stands (arrêt compté)',false,false,false)
e('rules','redRestart','Relance après drapeau rouge','rolling','rolling','rolling',{'rolling','standing'})
n('rules','mandatoryStops','Arrêt obligatoire en course',0,1,0,0,0)
n('rules','pitWindowOpenPct','Ouverture de la fenêtre (% de course)',5,95,25,25,25)
n('rules','pitWindowClosePct','Fermeture de la fenêtre (% de course)',5,100,75,75,75)
b('rules','pitTyres','Pneus neufs à chaque arrêt (règles d’arrêt actives)',true,true,true)
b('rules','pitRepair','Réparations à chaque arrêt en course (carrosserie, suspensions, moteur)',true,true,true)
b('rules','pitCompoundChange','Changer de composé sec (F1)',false,false,false)
n('rules','minPitTime','Temps d’arrêt minimal (s, 0 = libre)',0,120,0,0,0)
n('rules','maxStintMin','Relais maximal (min, 0 = libre)',0,240,0,0,0)
e('rules','pitFuel','Carburant aux arrêts forcés','refuel','refuel','refuel',{'refuel','plan','ac'})
e('rules','pitsClosed','Stands fermés sous neutralisation','open','open','open',{'open','pitFcy','pitFcySc'})
b('rules','pitMessage','Message d’ouverture de la fenêtre d’arrêt',true,true,true)
b('rules','overtakeMode','Overtake Mode (F1 2026, moins d’une seconde à la détection)',false,false,false)
n('rules','overtakeModeGap','Overtake Mode : écart de détection (s)',0.3,2,1,1,1)
n('rules','overtakeModeBoostPct','Overtake Mode : gain de niveau (%)',0,5,2,2,2)
b('rules','drsAssist','DRS du joueur : bip et panneau',true,true,true)
b('rules','rulesDrs','DRS : règles de course (pluie, drapeaux, départ, voiture de sécurité, drapeau rouge)',false,true,true)
n('rules','rulesDrsLaps','DRS : tours du leader avant activation (départ, voiture de sécurité, drapeau rouge)',0,5,1,1,1)
b('rules','aiDrs','DRS des IA : ouverture dans les zones',true,true,true)
n('rules','drsBeepVolume','Bips (DRS et delta) : volume (%)',25,400,200,200,200)
b('rules','bopEnabled','BoP : rythmes resserrés dans chaque classe',false,false,false)
n('rules','bopStrengthPct','BoP : correction maximale (%)',0,5,2,2,2)
b('rules','proAmEnabled','Grades Pro-Am (Bronze à Platinum)',false,false,false)
b('rules','predictableSlowClass','Classe lente : trajectoire prévisible',false,false,false)
newKeys.open=nil
b('endurance','enduranceOverlay','Surcouche Endurance',false,false,false)
b('endurance','multiClass','Multi-classes',false,false,false)
n('endurance','classGapPct','Écart entre classes (%)',3,25,8,8,8)
n('endurance','classYieldMargin','Avantage interclasse (km/h)',1,15,4,4,4)
n('endurance','stintLevelSwing','Variation entre relais (%)',0,8,3,3,3)
n('endurance','stintDegradationPct','Dégradation d’un relais (%)',0,5,1,1,1)
b('weather','weatherAdaptation','Adapter le rythme à la météo',true,true,true)
b('weather','weatherTyresEnabled','Gérer les pneus secs et pluie',true,true,true)
newKeys.open=true
b('weather','weatherMessage','Message à l’écran au changement de météo',true,true,true)
newKeys.open=nil
n('weather','rainGripBoostPct','Compensation pluie sans pneu pluie (%)',0,30,15,15,15)

newKeys.open=true
b('weather','outLapEnabled','Tour de sortie : chauffe des pneus',false,true,true)
n('weather','outLapLevelPct','Tour de sortie : niveau réduit de (%)',0,15,7,7,7)
b('weather','lockWearEnabled','Blocages liés à l’usure des pneus',false,true,true)
n('weather','lockWearGain','Blocages : gain en fin de relais',0,3,1.5,1.5,1.5)
n('weather','lockFlatSpotKm','Méplat : usure ajoutée par blocage (km)',0,5,1,1,1)
newKeys.open=nil




newKeys.open=true
b('lights','lightsYellow','Jaune · drapeau jaune, voiture de sécurité, VSC, FCY',true,true,true)
b('lights','lightsRed','Rouge · drapeau rouge',true,true,true)
b('lights','lightsBlue','Bleu · drapeau bleu vers vous',true,true,true)
b('lights','lightsWhite','Blanc · véhicule très lent devant',true,true,true)
b('lights','lightsOrange','Orange · piste glissante',true,true,true)
b('lights','lightsGreen','Vert · fin de zone, de neutralisation et relance',true,true,true)
n('lights','lightsGreenTime','Durée du vert (s)',0,15,5,5,5)
n('lights','lightsHold','Délai avant une couleur moins importante (s)',0.5,5,1.5,1.5,1.5)
newKeys.open=nil


newKeys.open=true
b('strategy','strategyEnabled','Stratégie individuelle des arrêts aux stands',false,false,true)
n('strategy','strategyTyreWearPct','Usure des pneus avant l’arrêt (%)',10,95,30,30,30)
n('strategy','strategyFuelMarginLaps','Marge de carburant (tours)',0,3,1,1,1)
b('strategy','strategyUndercut','Undercut et overcut (réaction aux arrêts des rivaux)',false,false,true)
n('strategy','strategyRiskPct','Prise de risque moyenne (%)',0,100,50,50,50)
n('strategy','strategySpreadPct','Écart entre stratèges (%)',0,100,60,60,60)
b('strategy','failuresEnabled','Pannes mécaniques progressives',false,false,true)
n('strategy','failureRate','Pannes : fréquence (par heure et par IA)',0,2,0.05,0.05,0.05)
n('strategy','failureLossPct','Panne : perte de rythme maximale (%)',3,30,12,12,12)


b('strategy','strategyStartVariety','Stratégies de départ variées',false,false,false)
b('sanctions','sanTrackLimits','Limites de piste (au moins trois roues dehors)',false,true,true)
n('sanctions','sanTrackWarnings','Avertissements avant pénalité (course)',0,5,3,3,3)
b('sanctions','sanCutPenalty','Virage coupé avec gain de temps : coupure des gaz',false,false,true)
n('sanctions','sanCutSeconds','Coupure des gaz (s)',2,15,5,5,5)
b('sanctions','sanJumpStart','Faux départ',false,false,true)
b('sanctions','sanPitSpeed','Excès de vitesse dans les stands',false,false,true)
b('sanctions','sanPitExit','Ligne de sortie des stands franchie',false,false,true)
e('sanctions','sanProcedureKind','Pénalité des infractions de procédure','drive','drive','drive',{'drive','stopgo','time'})
b('sanctions','sanWrongWay','Contresens : drapeau noir',false,true,true)
n('sanctions','sanWrongWaySeconds','Contresens toléré (s)',2,15,5,5,5)
n('sanctions','sanServeLaps','Tours pour purger une pénalité (drapeau noir ensuite)',1,5,3,3,3)
n('sanctions','sanStopGoSeconds','Stop-and-go : arrêt (s)',5,30,10,10,10)
n('sanctions','sanTimeSeconds','Pénalité de temps (s)',1,30,5,5,5)
b('sanctions','sanUnservedTime','Pénalité non purgée ajoutée au résultat',false,false,true)
b('sanctions','sanGiveBack','Place à rendre après un dépassement hors piste',false,false,true)
n('sanctions','sanGiveBackSeconds','Délai pour rendre la place (s)',5,30,15,15,15)
b('sanctions','sanMessages','Annonces des sanctions des IA à l’écran',false,true,true)


b('sanctions','sanPlayerTrackLimits','Vos limites de piste gérées par l’app',false,false,false)
e('sanctions','sanPlayerSession','Vos sorties en essais et qualifications','invalid','invalid','invalid',{'invalid','notice'})
e('sanctions','sanPlayerPenalty','Votre pénalité en course (limites de piste, contacts)','time','time','time',{'time','throttle'})
b('sanctions','sanEscalation','Pénalités croissantes en cas de récidive',false,false,false)
n('sanctions','sanEscalationStep','Hausse à chaque récidive (s)',1,30,5,5,5)
n('sanctions','sanEscalationMax','Pénalité maximale par sortie (s)',5,60,30,30,30)
b('sanctions','sanReport','Rapport de course (fichier CSV)',false,false,false)


b('human','fineInputs','Pilotage plus fin (gaz progressifs, erreurs à la limite)',false,false,false)
b('human','dynamicPersona','Personnalités dynamiques (phase de course, fatigue, pression)',false,false,false)
b('lateral','rearAwareness','Conscience de l’arrière',false,false,false)
b('overtake','passAid','Aide au dépassement (le défenseur tient sa ligne)',false,false,false)
b('weather','wearPace','Rythme selon l’usure, la gomme et le carburant',false,false,false)
b('strategy','strategySmart','Stratégie avancée (temps perdu aux stands, piste libre, voiture de sécurité)',false,false,false)
e('start','raceStart','Départ de la course','standing','standing','standing',{'standing','formation','rolling'})
b('sanctions','sanContact','Collisions et drapeaux bleus : sanctions des IA',false,false,false)
b('sanctions','sanPlayerContact','Collisions : vous êtes jugé aussi',false,false,false)


b('blue','classNuance','Retardataires et classes : comportement nuancé',false,false,false)
b('start','startRealism','Départs réalistes (réactions, tour de formation, faux départs gradués)',false,false,false)
b('weather','weatherLive','Météo en direct (rythme progressif, pneus anticipés)',false,false,false)
newKeys.open=nil
n('traffic','trafficGapSeconds','Intervalle de base (s)',0.5,5,2.5,2.5,2.5)
n('traffic','trafficDensityGain','Distance ajoutée par IA (m)',0.5,5,2.8,2.8,2.8)
n('traffic','trafficVariation','Variation des espacements (%)',0,50,45,45,45)
n('traffic','trafficMaxReduction','Réduction maximale de vitesse (%)',2,20,14,14,14)
M.globalDefaults={schemaVersion=1,enabled=true,autoProfile=true,manualProfile='J',offsetSign=0,sideSign=0,
 overrideAwareness=false,levelMode='auto',useGripBoost=false,gripPerLevelPct=0.004,useBrakeAssist=true,
 flashField='',occLatMin=0.3,occLatMax=5.5,occMargin=6,occSpeedGain=0.8,seed=19731019,debugLog=false,loadedPreset='',builtinMarks='',presetBySession=true,presetsUsed=false,dataRevision=0,safetyCarModel='ferrari_458_s3',safetyCarPicked=false,journal=true,panelOpacity=86,panelShow='info',overlayX=-1,overlayY=-1,overlayScale=1,overlayLocked=true,overlayBackground='solid',overlayContent=100,overlayClickThrough=true,overlayHideReplay=true,overlayHidePits=false,trackLights=true,overlayEnabled=true,overlaySession=true,overlayExplain=true,overlayRecap=true,overlayNativeBox=true,overlayMessages=true,overlayBlockMessages=true,cspHideMessages=true,cspHideFlags=true,cspMessagesLost=false,floodBackup='',panelInfoTime=0,windowCompacted=false,language='en',updateCheck=true}
M.globalBounds={panelOpacity={0,100},panelInfoTime={0,60},overlayX={-1,16000},overlayY={-1,16000},overlayScale={0.5,2.5},overlayContent={30,100},dataRevision={0,1000},offsetSign={-1,1},sideSign={-1,1},gripPerLevelPct={0,0.01},occLatMin={0.1,1},occLatMax={2,8},occMargin={2,15},occSpeedGain={0,2},seed={0,2147483647}}
M.globalChoices={language={'en','fr'},panelShow={'info','always'},overlayBackground={'solid','ghost','transparent'},manualProfile={'J','P','Q','C','H'},levelMode={'auto','native','grip','none'},flashField={'','highBeams','headlightsActive','lowBeams','flashingLightsActive'}}

M.K={maxCars=61,paceBins=400,logLines=200,logRate=20,logDedup=5,maxZones=64,maxZoneBytes=65536,
 maxPatterns=8,maxPatternLength=32,dtMax=0.25,teleport=40,perceptionPeriod=0.1,metaPeriod=1,classPeriod=60,classCycles=2,
 neighbors=8,neighborRange=400,fallbackRange=80,sameDirection=0.5,coherenceFloor=15,coherenceRatio=0.35,occLatMax=5.5,
 minLength=3.5,maxLength=6.5,minWidth=1.5,maxWidth=2.3,length=4.4,width=1.85,
 speedTau=0.4,yawTau=0.3,ttcEpsilon=0.1,nearLine=0.3,overlapMargin=2,
 freeRange=80,paceAlpha=0.3,paceRatioAlpha=0.05,paceRatioMin=40,paceMinBins=40,speedMinYield=20,speedMinPass=30,
 latYield=4,latPass=3.2,pressureSa=8,pressureResetTime=1,pressureResetRange=1.5,
 nearYield=25,nearYieldMargin=0.5,confirmReset=0.3,pendingTTL=12,detectMax=400,
 courtesyMin=1.25,courtesyMax=0.75,yieldMarginRange=50,gapMarginMin=0.5,
 holdFloor=1,passBuffer=3,lostRange=1.3,slowLostTime=2.5,slowLostGap=15,ignoreFollower=10,
 invitationGap=25,invitationTime=12,invitationRamp=4,urgentAmp=1.1,cornerAmpMin=0.4,
 assertMin=1.3,assertMax=0.7,passMarginRange=40,stuckGapMin=10,stuckGapTime=1.5,
 passAdvantageJ=4,passAdvantageC=3,passCornerC=0.6,passBrakeMax=0.3,pullOutMax=22,
 corridorMin=40,corridorMax=250,corridorSpeedMin=1.5,abortBlocked=0.4,abortSlowTime=3,abortGap=5,
 abortFollowerSpeed=25,abortFollowerGap=30,passHoldMax=4,holdProgress=0.5,clearConfirm=0.6,alongsideBuffer=3,
 followRange=60,followMinGap=5,followGapRange=30,followCaution=1.35,followTTC=3,followTTCMult=1.1,
 slipCorner=0.9,slipTime=1,slipSpeed=150,slipCaution=0.85,slipCautionMin=0.6,
 brakeClosing=2,brakeGain=10,brakeMax=0.6,
 defenseChance=0.3,defenseAssert=0.5,defenseTime=2.5,defenseAggression=1.2,defenseCaution=0.9,
 obstacleTime=2,stoppedTime=10,slipDegrees=35,obstacleBlockedLevel=0.6,obstacleClear=12,
 contactDrop=25,contactWindow=0.3,contactRange=6,calmTime=4,calmExitSpeed=40,
 driftPeriodMin=90,driftPeriodMax=240,jitterPeriodMin=7,jitterPeriodMax=19,jitterRange=40,baseMax=0.25,
 lapseRamp=0.3,playerFollowGap=8,playerCaution=1.15,lateralSpeedBase=100,lateralSpeedFloor=30,
 lateralRateMin=0.6,lateralRateMax=1.6,blockedRelease=0.3,directionLimit=6,directionWindow=60,directionRest=20,sideDeadband=0.05,
 pitOffsetMax=0.5,pitZone=60,pitExitDelay=2,stintExitDelay=3,stintExitCautionTime=8,stintExitCaution=1.3,
 stintDuration=2400,wetLevel=0.1,wetCaution=0.4,wetAggression=0.25,wetDetect=0.3,
 fatigueTime=5400,fatigueGain=1.3,fatigueMax=2,timeWrap=86400,
 classMax=4,classConfirm=0.7,classReaction=0.8,classFightSpeed=15,classCorner=0.7,classMargin=0.5,
 lapTolerance=0.02,lapRangeMult=1.5,lapSpeed=3,lapConfirm=0.3,lapReaction=0.8,lapCorner=0.7,lapCornerLevel=0.92,
 fightTime=2,fightSpeed=4,flashBurst=1.5,flashHoldMin=0.8,flashHoldMax=4,
 flashDebounce=0.15,flashDedup=0.4,flashLearnTime=6,flashPropagation=0.5,
 flashLat=6,flashSpeed=30,flashCloseGap=60,flashCatchMargin=5,courtesyRange=30,courtesyTime=20,courtesyAggression=0.35,courtesyPassSa=25,stuckRadius=15,inviteReport=3,brakeEcho=0.03,passCloseMin=4,closeMemory=5,realPassGap=20,realPassWindow=20,flashSecondTime=4,flashReact=0.6,flashConfirm=0.1,
 flashMargin=0.5,flashHorizon=1.5,flashUrgentCount=3,flashReactionMin=0.15,flashReactionMax=1.45,
 personaPatienceMin=0.7,personaPatienceMax=1.4,personaBrakeMin=0.9,personaBrakeMax=1.15,
 writePeriod=0.2,readbackPeriod=2,offsetEpsilon=0.002,levelEpsilon=0.005,aggrEpsilon=0.01,cautionEpsilon=0.02,gripEpsilon=0.001,
 capabilityFailures=3,carErrorTime=5,carErrorMax=3,saveDelay=1,maxCaution=16,maxAggression=0.95,
 probeLevel=1.05,probeDelay=0.3,probeTolerance=0.01,gripBase=1.2,calibrationOffset=0.5,
 calibrationTime=3,calibrationMinMove=0.15,calibrationRange=100,calibrationSpeed=60,calibrationCorner=0.95,
 calibrationPairGap=50,calibrationPairMax=150,calibrationMinWidth=2.5,calibrationActiveCorner=0.6,calibrationAlignment=0.98,
 classPatternClassMax=4,defaultLevel=1,defaultAggression=0.5,defaultCaution=1,modulatorTau=0.4,fastModulatorTau=0.15,
 minNativeLevel=0.3,yieldReachedEpsilon=0.03,centerEpsilon=0.03,yieldAggression=0.5,yieldHoldCaution=1.1,yieldRecoveryTau=1.5,
 passAggression=1.15,passCaution=0.7,alongsideCaution=0.8,avoidAggression=0.6,calmLevel=0.95,calmAggression=0.5,calmCaution=1.3,
 blueSlowdown=0.08,blueRecoveryTau=0.8,blueTrainHold=1,lostSaRatio=0.3,returnCornerMin=0.35,
 brakeEmulationGain=0.8,brakeEmulationPedal=0.2,brakeEmulationRange=80,brakeEmulationClosing=3,
 counterMax=2147483647,blockedYieldTime=3,blockedYieldGap=10,lapseSalt=50000,stintSalt=10000,performanceWindow=60,maxAppWindows=256,metadataLength=128,maxCapabilities=128,
 uiTipWidth=72,maxPresets=16,presetNameBytes=64,
 neutralReaction=0.3,neutralAwareness=0.5,trafficPeriod=0.5,trafficMinGap=15,trafficDensityCapacity=0.65,trafficMaxCapacity=0.9,
 trafficDecelKmh=4,trafficAccelKmh=8,trafficMinSpeed=30,trafficLogDelay=60,trafficFasterMargin=0.03,targetLostGrace=1,spreadDelay=1,spreadPlanDelay=0.5,spreadReport=8,spreadPlayerGap=300,spreadSpeed=50,spreadLaunchWait=0.5,spreadCheck=3,spreadTroubleKmh=10,spreadRetry=2,spreadReached=100,spreadTroubleLines=6,slowRatio=0.6,slowMinPaceKmh=60,slowMinKmh=15,slowFollowGap=60,slowLogTime=20,slowEnd=8,slowSettle=10,spreadMinGap=15,spreadWindow=60,spreadMaxKmh=30,trackDayExitSpeed=40,trackDayExitMaxTotal=600,floodPeriod=2,floodMinLength=7000,floodRound=50,messageProbe='AdvancedIA',probeFrames=90,probeTime=0.1,parkReturnPeriod=10,blueCloseGap=40,blueSlack=5,radarLatMargin=0.4,radarWarnTTC=2.5,radarCaution=1.4,radarTTC=1.2,radarMinBrake=0.08,radarBrakeMax=0.45,radarApply=1.5,radarRelease=0.8,radarLogPeriod=15,contactLogPeriod=10,contactLogBudget=3,towWindow=3,blueLogTime=3,pitExitWindow=60,pitExitSalt=7717,pitExitJitter=0.6,pitExitMaxTotal=180,pitExitSessionShare=0.25,pitExitMinGap=2,
 repairBase=3,repairBodyMin=5,repairBodyRate=0.1,repairSuspensionMin=0.02,repairSuspensionRate=40,repairEngineMin=990,repairEngineTime=30,repairMax=60,engineLifeNew=1000,trafficArmSpeed=60,trafficEpisode=6,trafficCycle=18,unlimitedSpeed=1e9,
 wrongWaySpeed=10,wrongWayTime=2,spinSpeed=15,spinTime=0.6,incidentClear=2,incidentMaxAge=120,crashSettle=4,rejoinWaitMax=10,rejoinSpeed=30,crashSalt=60000,stopPulse=1.5,stopPulsePeriod=0.5,
 yellowApproach=800,yellowNoPass=150,playerFlagLead=150,playerFlagLeadMax=800,flagLeadTime=1.25,gridGrace=6,gridMax=120,gridFirst=6,gridPitch=8,gridSlotRadius=4,gridApproachDecel=1.5,gridBrakeFrom=25,gridHoldDistance=1.5,gridColumn=0.35,gridColumnFrom=200,gridStillKmh=2,gridCrawlKmh=8,gridApproachKmh=80,gridBrakeMargin=3,gridBrakeScale=30,gridBrakeMin=0.1,gridNodeRange=400,gridLights=5,lightStep=1,lightsOutMin=0.2,lightsOutMax=3,jumpDistance=1,jumpSpeed=3,goShow=2,jumpShow=8,gridOvershoot=25,gridPassedShow=500,gridSideBySide=0.5,gridFormFrom=500,relaunchTravel=0.5,jumpServeDistance=150,jumpServeMax=30,slowGrace=10,flagsHiddenRead=5,cspLiveWait=15,cspWritesMax=8,slowLogGap=10,flagNone=0,flagCaution=2,flagStart=1,flagStop=5,flagReturnToPits=8,flagFasterCar=12,flagSlippery=3,flagSlowVehicle=6,flagFinished=13,flagOneLapLeft=14,penaltyMandatoryPits=1,penaltyTeleportToPits=2,
 ruleBrake=0.2,aiFlashGap=40,aiFlashCooldown=8,aiFlashPulses=2,aiFlashInterval=0.4,overtakeDetect=0.95,vscEnding=12,restartMax=600,redReleaseFirst=5,redReleaseGap=2,scClosedLaps=3,
 journalPeriod=2,journalSummary=60,journalKeep=3,journalMaxBytes=4194304,


 updateDelay=10,bootFrames=10,bootUIFrames=3,updateNotes=8,updateNotice=6,
 queueGap=15,pillFontMin=11,deltaBoxMin=12,deltaStart=1,laneMin=0.5,laneBias=0.3,laneRelease=1,deltaCap=3,deltaJump=150,deltaMinKmh=30,miniSectorLength=250,miniSectorsMin=8,miniSectorsMax=60,fleetBinsPerFrame=4,scMergeMargin=30,singleYellowPct=15,passGiveBack=10,giveBackMin=5,giveBackDrop=25,queueKeep=15,queueClose=0.5,aiDeltaMarginMin=0.02,aiDeltaMarginMax=0.06,slipperyShow=30,slipperyGrace=30,lightsHold=1.5,lightsFiles=64,lightsBytes=4194304,slowVehicleRange=300,slowVehicleBehind=10,slowVehicleTime=3,slowVehicleRatio=0.5,meatballShow=20,meatballBody=100,meatballSuspension=0.2,meatballEngine=600,meatballGearbox=0.4,playerDamagePeriod=1,warningShow=10,safetySkinPattern='safety',drsLateLoad=60,drsLapsMax=99,drsAiBrake=0.2,drsAiCorner=0.5,drsAiKmh=80,drsAiRetry=1,drsAiCloseRetry=0.1,mistakeCheck=1,mistakeStartMin=60,mistakeArm=15,mistakeCooldown=180,mistakeGap=60,mistakeCalm=180,mistakeLapse=4,mistakeWet=2,mistakeWetCause=0.3,mistakeSkill=5,mistakeSkillMin=0.5,mistakeSkillMax=3,mistakeWeak=0.95,mistakePlayerGap=40,mistakeMinKmh=50,mistakeBrakePedal=0.6,mistakeBrakeKmh=120,mistakeGasPedal=0.8,mistakeCorner=0.6,mistakeTractionKmh=180,mistakeSeverity=1.4,mistakeSalt=80000,mistakeBrakeMin=0.4,mistakeBrakeMax=0.9,mistakeTractionMin=0.3,mistakeTractionMax=0.7,deltaBeepFile='sounds/delta-beep.wav',deltaBeepNegative=0.15,deltaBeepNear=0.2,deltaBeepFast=0.3,deltaBeepMid=0.5,deltaBeepMedium=0.6,deltaBeepFar=1,deltaBeepSlow=1.2,slipperyStripes=6,flagBlinkTime=5,pitRemindTime=15,pitCompoundGrace=3,pitNoticeCounted=4,pitNoticeSame=8,pitPlanPeriod=2,pitPlanNotice=8,heldMessageMax=5,pitHintTime=20,pitHintMinSpeed=15,pitHintSector=0.67,pitEntryMinKmh=40,pitRemindLate=0.2,aiPenaltyDecel=3,inviteLatMax=6,inviteCurve=0.001,passArmMax=20,carNameMax=96,passStallSa=2,passStallTime=8,pullOutTargetLat=1,pitGuardTime=15,pitGuardGap=80,pitGuardMin=12,pitGuardAllowance=15,pitGuardBack=5,pitGuardCaution=1.5,inviteLat=2,inviteGap=40,inviteTime=0.6,inviteSa=3,inviteClear=60,inviteRespite=20,aiPenaltyFactor=0.7,penaltyBlackFlag=4,penaltyReleaseBlackFlag=5,journalMarker='.AdvancedIA.journal',drsBeepFile='sounds/drs-available-beep.wav',penaltyBrakeMargin=2.5,incidentStopSpeed=10,obstacleClosing=15,penaltyCooldown=20,passWatch=40,noticeTime=8,penaltySlowDown=3,avoidClearMargin=10,avoidRecheck=1,crashWindow=30,neutralMax=600,neutralRecoverTime=20,stuckRecoverTime=30,trackRecoverTime=8,brokenRecoverTime=3,ruleDecision=5,calibrationRetry=60,laneMaxOffset=0.7,hudMessageTime=5,hudMessageMin=2,hudMessageMax=10,recapPassGap=40,recapPeriod=0.1,hudStripPeriod=0.25,hudFuelWarn=2,hudLapTime=5,hudWidth=600,hudTop=0.07,hudStripH=26,hudBandH=82,hudExplainLine=16,hudPillH=24,hudPad=8,hudHandle=18,hudGhost=0.5,scKickPeriod=2,startCareRise=4,startCareFall=0.6,radarLaunchTTC=0.8,brokenSuspension=0.5,brokenEngine=50,brokenGearbox=0.9,damageReadSpeed=25,

 redFlagMax=300,compactWidth=900,compactHeight=700,fuelReserveLaps=0.6,fuelMargin=1.03,fuelAlpha=0.3,fuelLapShare=0.5,fuelLapTimeMin=20,fuelStep=1,redFlagMaxCap=1800,redLapFactor=1.25,redPitMargin=60,redRecoverTime=8,redStopSpeed=5,redStopTime=5,redClearWait=15,greenShow=5,greenZoneShow=3,panelPeriod=0.25,panelWrap=58,
 bopGain=0.5,bopPeriod=60,scCatchUp=40,scQueueGap=60,scCallTime=10,scEscalateCars=2,scEscalateTime=30,scMinOut=60,scExitMax=90,scStuckTime=20,scInMax=300,scPlaceJunction=200,scPlaceFirstOut=250,scPlaceOnTrack=30,scPlaceLeader=200,scPlaceFree=80,scPlaceStep=50,scPlaceSteps=8,scPlaceMax=15,scLeadKmh=80,scLeadGap=120,scParkingMax=90,redExitWait=20,redExitWaitPlayer=45,redExitClear=10,restartRetakeRange=300,scPlaceReach=100,parkPeriod=2,maxCarList=4000,carReadMax=24,carReadBudget=0.004,uiSlowFrame=0.05,uiSlowFirst=0.5,uiSlowLogs=8,pitSpread=0.85,pitSalt=8152,pitConcurrent=3,pitLastStint=0.95,gradeSalt=70000,gradeLevel={1,0.99,0.975,0.96},gradeCaution={1,1,1.05,1.1},
 weatherPeriod=1,weatherConfirm=15,weatherWetOn=0.12,weatherWetOff=0.05,weatherRainOn=0.1,weatherRainOff=0.02,weatherWaterOn=0.03,weatherWaterOff=0.01,weatherHeavy=0.6,maxTyreCompounds=32,tyreCatalogBudget=2,tyreStopSpeed=1,tyreSalt=90000,spawnWindow=15,enduranceSuggestionSeconds=3600}
M.timerFields={'since','aiFlashAt','stintStart','pitExitUntil','pitCautionUntil','pitGuardUntil','pendingUntil','holdUntil','ignoreUntil','restUntil','nextPerception',
 'defendUntil','defendCooldown','calmUntil','speedWindowStart','lastContact','lapseAt','errorUntil','lastDirectionAt','driveUntil','yieldStart'}
M.optionalTimerFields={'pendingAt','lapseUntil','slowTeleportAt','flashMuteUntil','flashHoldUntil','flashFailAt','noAdvAt','cornerGiveUntil','cornerEntryAt','blueVetoAt'}

local traffic141={

 clockProbeLoops=20000,



 slowObstacleTime=5,slowLeadMargin=5,slowPassRatio=0.8,slowPitTime=30,slowPitSuspension=0.2,slowPitBody=150,


 longRatioTau=60,longRatioMin=20,


 cessionSaMin=2,passFreeMargin=0.03,retainLossMax=5,


 passIgnore=45,passIgnoreGrowth=4,passIgnoreMax=600,passIgnoreForget=600,


 followerStallTime=6,followerStallSa=1,followerStallGap=2,


 yieldTopCut=8,yieldCapGap=25,yieldCapMinKmh=80,


 paceBinMeters=50,paceBinsMax=1300,








 mergeLearnPit=5,mergeLearnKmh=120,mergeAlpha=0.3,mergeOutlier=200,mergeBefore=100,mergeAfter=50,mergeHoldZone=80,mergeHoldMin=5,
 mergeWindow=3,mergeWindowMax=5,mergeCrawl=10,mergeTrafficKmh=30,mergeClear=15,mergeHoldMax=10,
 mergeHoldStartKmh=5,mergeBoxClear=15,mergeSeenKmh=15,mergeSeenCrawl=3,mergeSeenNear=30,


 lightsTotalBytes=8388608,
}
for key,value in pairs(traffic141) do assert(M.K[key]==nil,key); M.K[key]=value end






local k150={radarStraightTTC=0.6,radarStraightObstacleKmh=60,radarLaneWidth=8,scHoldTime=600,scHoldStop=2,scHoldPeriod=1,scLeaveMax=40,scExitLogPeriod=5,scLaneMax=45,
 scExitLead=20,scCallMaxWait=90,scExitGap=3,scEscapeMax=2,scHideAhead=800,scHideBehind=300,scHideMax=60,scLeaderMinSpeed=10,pitHintLatchSlack=200,

 aiGiveBackMax=30}
for key,value in pairs(k150) do assert(M.K[key]==nil,key); M.K[key]=value end







local k151={qualiOutGrace=30,qualiCoolRatio=0.75,qualiCoolPaceMin=0.85,qualiCoolTime=4,qualiCoolMinKmh=30,qualiYieldTime=3,qualiYieldSa=5,qualiYieldNear=30,
 qualiYieldRange=1.5,qualiWarnTime=3,qualiWarnRepeat=30,qualiLogGap=20,




 qualiCoolLevel=0.18,qualiCoolRamp=4,qualiCoolRelease=3,qualiPushMin=1,qualiPushMax=2,qualiCoolLate=2.5,qualiCoolLapMin=60,qualiCoolSalt=7151}
for key,value in pairs(k151) do assert(M.K[key]==nil,key); M.K[key]=value end





local k152a={launchCare=0.5,blueForgetMult=2,passSideAssert=0.5,mergeOutlierCount=3}
for key,value in pairs(k152a) do assert(M.K[key]==nil,key); M.K[key]=value end

for _,key in ipairs({'passedByPlayerAt','qualiLogAt','lastPassAt','passStartAt','maneuverAt','laneSeen','laneAt','straightHoldAt','defendLogAt','startLiftAt','radarLogAt'}) do M.timerFields[#M.timerFields+1]=key end




local k152b={presetSessionKeyMax=256,presetSessionProfilesMax=8,lightsOutSalt=9134,gridGapFine=20,gridGapStep=10,queueSpeedMargin=5,strategyRivalMinSpeed=10}
for key,value in pairs(k152b) do assert(M.K[key]==nil,key); M.K[key]=value end





local k152d={floodBackupBytes=512,builtinMarksBytes=128,loadedPresetPrefix=16,
 uiMeasureCache=3000,uiUpperCache=1000,uiDrawCache=6000,hudBlinkHz=2,
 overlayScaleStep=0.05,panelOpacityStep=5,overlayContentStep=5,panelInfoStep=1,uiEpsilon=1e-6}
for key,value in pairs(k152d) do assert(M.K[key]==nil,key); M.K[key]=value end





local k152c={tyreWriteGap=5,nativeLevelMax=1.1,weatherGripMax=1.3,minCaution=0.5,levelReadMax=2,storeMaxBytes=65536,flagLeftoverDelay=1,windowCheckPeriod=1,


 oldWorkMaxFiles=4000,oldWorkMaxDepth=8}
for key,value in pairs(k152c) do assert(M.K[key]==nil,key); M.K[key]=value end




local k152e={companionUpdatePeriod=10,companionUpdateBytes=200,companionVersionBytes=32}
for key,value in pairs(k152e) do assert(M.K[key]==nil,key); M.K[key]=value end




local k154={passIgnoreStrict=2}
for key,value in pairs(k154) do assert(M.K[key]==nil,key); M.K[key]=value end
















local k155={passProgressGain=3,passProgressTime=8,passAttemptMax=15,passCapGrace=4,yieldNeedAdvantage=true,yieldNoAdvForget=60,
 flashFailLimit=2,flashFailForget=180,flashMuteTime=120,flashAfterAbort=20,rainReassertGap=10,tyreModelsPeriod=1,
 qualiCatchWatch=8,qualiCatchSpanLong=3,qualiCatchRateLong=0.1,qualiCatchSpanShort=1,qualiCatchRateShort=0.3,
 qualiCatchProject=15,qualiCatchWindow=6,qualiCatchForget=2,qualiCatchFill=8,qualiCatchSamples=16}
for key,value in pairs(k155) do assert(M.K[key]==nil,key); M.K[key]=value end





local k156={sanPlayerCutConfirm=2,sanPlayerQueueGap=1,sanReportAfterFinish=90,sanReportKeep=5,sanReportMaxBytes=262144,sanReportFile='AdvancedIA-race'}
for key,value in pairs(k156) do assert(M.K[key]==nil,key); M.K[key]=value end


local k157={readErrorChars=120,onlineLogGap=60}
for key,value in pairs(k157) do assert(M.K[key]==nil,key); M.K[key]=value end




local k158={laneReleaseRate=1,laneReleaseStep=0.1,pitRequestServiceMax=2}
for key,value in pairs(k158) do assert(M.K[key]==nil,key); M.K[key]=value end





local k159={companionManualVersions={['1.1.0']=true,['1.1.1']=true},pitHintShow=10,
 sePlanKey='SpotterEnginer.pitplan',sePlanPeriod=1,sePlanStale=6,sePlanBytes=160,sePlanLapMax=1000,






 offClearTime=15,offClearLat=8,hotspotCount=3,hotspotMeters=100,hotspotWindow=300,hotspotCaution=1.15,hotspotForget=1800,
 hotspotRecent=24,hotspotMax=8,



 doubleFloorKmh=40,offClearEdge=2,offClearBack=2,hotspotForgetRace=600,hotspotStartGrace=120,hotspotLengthShare=0.25,firstLapFloorMinKmh=25,finalLapsShare=0.2,failureGap=300,

 firstLapFloorPct=0.7}
for key,value in pairs(k159) do assert(M.K[key]==nil,key); M.K[key]=value end

local k142schema={levelScaleMin=0.7,throttleMin=0.3,throttleEpsilon=0.01}

local k142aero={towCorner=0.9,towSpeed=150,towLat=1.2,towSaMin=-5,towMapSpeed=60,towMapAlpha=0.1,towMapSeen=3,towStraightShare=0.8,towMapPeriod=5,
 towMinAheadTime=6,towReturnTime=3,towHoldMax=8,towOffset=0.45,towCooldown=20,towPairCooldown=60,towChance=0.5,towAssert=0.4,towSalt=7,
 dirtyAirLat=1.5,dirtyAirSpeed=80,dirtyAirFull=5,dirtyJitterAmp=0.02,dirtyJitterGain=0.5,dirtyJitterRate=3,dirtyLogPeriod=30,finalRange=80,

 towSaMax=12,towMergeBefore=100,towMergeAfter=500,towLatSide=0.5}

local k142strategy={


 strategyRows=6,strategyRiskWear=0.3,strategyWearMin=0.1,strategyWearMax=0.98,strategyRiskFuel=1,strategyRivalLap=0.5,strategyRivalGap=2.5,
 strategyOvercutWear=0.85,strategyOvercutLaps=2,strategyCoverLaps=4,strategyBoldRisk=0.6,strategyUndercutLaps=3,strategyNeutralLaps=5,strategyLastLaps=2,
 strategyWearRateMax=0.25,strategyWearAlpha=0.4,strategyPlanLogGap=120,strategyWindowMargin=0.1,strategyRetry=5,
 strategyCauseLog={fuel='carburant',undercut='undercut',overcut='overcut',cover='couverture d un undercut',neutral='sous neutralisation',failure='panne',weather='meteo'},


 outLapSummaryTime=200,outLapTempMargin=5,outLapMax=150,outLapRelease=8,


 failureCheck=10,failureLateRace=0.9,failureMinKmh=60,failureSalt=91000,failureSessionSalt=7919,failureRampMin=60,failureRampMax=180,failureLossMin=0.5,
 failureRepairMin=8,failureRepairMax=20,failureThrottleMin=0.8,failureThrottleShare=0.5,failurePitDelay=10,
 failureKindLog={leak='fuite',battery='batterie',overheat='surchauffe',puncture='crevaison lente'},
 wheelNames={'avant gauche','avant droit','arriere gauche','arriere droit'},

 lockWearStart=0.3,lockWearBase=0.5,lockWearMaxKm=15,lockWearCause=1.2,lockWearReset=0.2,lockWearNew=0.05,




 wearTrustLow=0.1,wearTrustRise=0.01,wearProbeLaps=5,strategyCriticalFuel=1.5,strategyEndReserve=0.1,strategyCheckDelay=3,
 strategyTyreCheckMin=0.25,strategyFuelGainMin=1,kersSeenMin=0.01}

local k142sanctions={



 sanOutDwell=0.3,sanOutKmh=40,sanStrikeGap=4,sanLineCars=3,sanLineMeters=25,sanLineBinsMax=4000,




 sanCutGain=0.3,sanCutMinDist=10,sanCutMaxDist=600,sanCutBinsMax=400,sanCutThrottle=0.35,sanCutRampDown=1.3,sanCutRampUp=2,
 sanCutMinKmh=80,sanCutBehind=30,sanCutDeferMax=90,sanCutBrake=0.1,

 sanGraceStart=30,sanServeAfterStart=30,



 sanPitSpeedGrace=4,sanPitSpeedMargin=6,sanPitSpeedDwell=1.5,sanPitLimitDefault=80,sanPitExitMargin=40,sanPitExitSamples=3,sanPitExitLane=5,


 sanWrongWayKmh=20,sanDriveTime=20,sanGiveBackWindow=3,


 sanRowsMax=8,sanClassRows=4,sanClassLog=20,sanNoticeGap=6,sanIdleGap=1,

 sanNoOutLap=2}


local k142merge={strategyStretchLaps=2,strategyCoverWear=0.35,paceRatioLow=0.6,paceRatioHigh=1.4,









 aiJumpDwell=0.5,aiJumpMinMove=1,sanCutBehindTime=4,sanCutTtc=5,sanCutResume=50,sanStraightLat=2,sanCutAfterRejoin=3,sanCutAfterStart=10,
 sanGiveBackFloorDrop=25,sanGiveBackPaceFloor=0.7,sanGiveBackSlowPace=0.6,sanNoPitLaps=2,sanAppOffset=0.3,sanPitLimitMin=40,sanLaneDebounce=1,
 sanLineWindow=300,sanLineDecay=1800}





local k144={playerSlowRatio=0.85,playerCrawlRatio=1.25,inviteLatAccel=4,mergeExitGrace=10,slowVehicleAhead=10}


local k147={startYaw=0.2,startYawHold=0.3,startBrakeKmh=80,startAnticipate=2.5,radarStartBrakeMax=0.18,radarStartFollowTime=0.6,radarStartFollowMin=8,radarStartLift=0.3,
 defenseLatMin=0.5,defenseSaMax=20,defenseTTCMin=1.5,defenseCorner=0.9,defenseRunTime=2,defenseLogGap=20,passIgnoreCloseMult=2.5,
 followerStallTimeOff=3.5,sanContactGrace=3,blueClearTime=5,fuelLogStep=5,flagLeftoverTries=3}
















local k147fl={firstLapLineGrace=10,firstLapSpread=2,firstLapSpreadTime=3,firstLapMax=180,firstLapRelease=3,firstLapPointMerge=50,
 firstLapPoints=32,firstLapPointKmh=60,firstLapPointCorner=0.8,firstLapPointFree=1,firstLapSpeedMin=10,firstLapGapMin=0.25,firstLapGapTime=0.8,
 firstLapFollowCaution=1.3,firstLapAnticipate=2,firstLapBrakeCaution=1.25,firstLapCareRise=1,firstLapCareFall=0.5,firstLapBrakeTTC=0.8,firstLapLastTTC=0.4,
 firstLapPassCorner=0.97,firstLapPassMargin=1.5,firstLapCorridor=1.3,firstLapAvoidPct=0.3,firstLapAggr=0.85,firstLapCautionMax=1.6,
 yellowUnknownPct=0.35,topKmhMax=450,
 redIncidentStill=10,redOffLine=4,redBlockSpan=40,redBlockMargin=0.3,redPassWidth=2.5,redTrackHalf=5}
for _,block in ipairs({k142schema,k142aero,k142strategy,k142sanctions,k142merge,k144,k147,k147fl}) do for key,value in pairs(block) do assert(M.K[key]==nil,key); M.K[key]=value end end
for _,key in ipairs({'passIgnoreUntil','yieldIgnoreUntil'}) do M.timerFields[#M.timerFields+1]=key end



M.acDrawnMessages={'^CUT DETECTED','LAP WILL NOT COUNT','^PENALTY','SLOW DOWN FOR','SLOW DOWN TO','BEFORE THE END OF CURRENT LAP',
 'DRIVE ?%-?THROUGH','STOP ?& ?GO','STOP AND GO','JUMP ?%-?START','DISQUALIFIED'}
function M.defaults(profile)
 local r={schemaVersion=M.version,classPatterns='',configured=false}
 for _,s in ipairs(M.schema) do r[s.key]=s.defaults[profile] end
 for _,group in ipairs(M.sections) do r['section_'..group]=false end

 if profile=='H' then r.section_rules=true end

 r.section_lights=true
 return r
end

function M.sectionsChanged(profile,p)
 for _,group in ipairs(M.sections) do
  local key=sectionKeys[group]
  if (p[key]==true)~=(profile=='H' and group=='rules' or group=='lights') then return true end
 end
 return false
end
function M.anySection(p)
 for _,group in ipairs(M.sections) do if group~='lights' and p[sectionKeys[group]]==true then return true end end
 return false
end
local function choice(v,list) for _,x in ipairs(list) do if x==v then return true end end return false end
function M.patterns(text,out)
 out=out or {}; for i=#out,1,-1 do out[i]=nil end
 if type(text)~='string' or #text>M.K.maxPatterns*(M.K.maxPatternLength+4) then return out,false end
 for pattern,class in text:gmatch('([%w_%-]+)%s*:%s*([1-4])') do
  if #pattern>M.K.maxPatternLength or #out>=M.K.maxPatterns then return out,false end
  out[#out+1]={pattern=pattern:lower(),class=tonumber(class)}
 end
 local rest=text:gsub('[%w_%-]+%s*:%s*[1-4]',''):gsub('[%s,;]','')
 return out,rest==''
end
function M.validate(profile,input,out)
 out=out or {}; local errors=0


 if input.schemaVersion~=nil and (not U.finite(input.schemaVersion) or input.schemaVersion<0 or input.schemaVersion%1~=0) then input=M.defaults(profile); errors=errors+1 end
 local newer=input.schemaVersion~=nil and input.schemaVersion>M.version
 for _,s in ipairs(M.schema) do
  local v=input[s.key]; local good

  if s.key=='mandatoryStops' and U.finite(v) and v>1 and v<=3 then v=1 end
  if s.min then good=U.finite(v) and v>=s.min and v<=s.max
  elseif s.choices then good=choice(v,s.choices) else good=type(v)=='boolean' end
  if not good then v=s.defaults[profile]; if not (input.schemaVersion==2 and (s.key=='weatherTyresEnabled' or s.key=='rainGripBoostPct')) then errors=errors+1 end end
  out[s.key]=v
 end
 for _,group in ipairs(M.sections) do
  local active=(input.schemaVersion==M.version or input.schemaVersion==2 or newer) and input[sectionKeys[group]]==true

  if group=='lights' and input[sectionKeys[group]]==nil then active=true end
  if group=='weather' and input.schemaVersion==2 then active=input.section_endurance==true and input.weatherAdaptation==true end
  out[sectionKeys[group]]=active
 end
 for _,s in ipairs(M.schema) do if M.hidden(profile,s.key) then out[s.key]=s.defaults[profile] end end
 for _,pair in ipairs({{'yieldHoldAfterMin','yieldHoldAfterMax'},{'reactMin','reactMax'},{'awMin','awMax'},{'lapseIntervalMin','lapseIntervalMax'},{'lapseDurMin','lapseDurMax'},{'lapseDropMin','lapseDropMax'},{'incidentStopMin','incidentStopMax'},{'pitWindowOpenPct','pitWindowClosePct'}}) do
  if out[pair[1]]>out[pair[2]] then out[pair[2]]=out[pair[1]]; errors=errors+1 end
 end
 local _,valid=M.patterns(input.classPatterns); out.classPatterns=valid and input.classPatterns or ''
 if not valid then errors=errors+1 end
 for key in pairs(M.integerKeys) do out[key]=math.floor(out[key]+0.5) end

 out.lightsYellow=true
 out.schemaVersion=newer and input.schemaVersion or M.version

 out.configured=input.configured==true or M.sectionsChanged(profile,out)
 return out,errors
end
function M.validateGlobals(input,out)
 out=out or {}; local errors=0

 if input.schemaVersion~=nil and (not U.finite(input.schemaVersion) or input.schemaVersion<0 or input.schemaVersion%1~=0) then input=M.globalDefaults; errors=errors+1 end
 local newer=input.schemaVersion~=nil and input.schemaVersion>M.version
 for k,d in pairs(M.globalDefaults) do
  local v=input[k]; local valid=type(v)==type(d)
  if type(d)=='number' then valid=U.finite(v); local r=M.globalBounds[k]; if valid and r then valid=v>=r[1] and v<=r[2] end end
  if M.globalChoices[k] then valid=choice(v,M.globalChoices[k]) end
  if k=='floodBackup' then valid=type(v)=='string' and #v<=M.K.floodBackupBytes and not v:find('%c') end
  if k=='loadedPreset' then valid=type(v)=='string' and #v<=M.K.presetNameBytes+M.K.loadedPresetPrefix and not v:find('%c') end
  if k=='builtinMarks' then valid=type(v)=='string' and #v<=M.K.builtinMarksBytes and v:match('^[%w=,]*$')~=nil end
  if k=='overlayLayout' then valid=type(v)=='string' and #v<=160 and v:match('^[%d,;%-]*$')~=nil end
  if k=='overlayParts' then valid=type(v)=='string' and #v<=160 and v:match('^[%d,;%-]*$')~=nil end
  if k=='safetyCarModel' then valid=type(v)=='string' and #v<=M.K.metadataLength and v:match('^[%w_%-%.]*$')~=nil end
  if (k=='offsetSign' or k=='sideSign') and valid then valid=v==-1 or v==0 or v==1 end
  if not valid then v=d; errors=errors+1 end
  out[k]=v
 end
 out.seed=math.floor(out.seed); out.dataRevision=math.floor(out.dataRevision); out.schemaVersion=newer and input.schemaVersion or M.version
 if out.loadedPreset~='' then out.presetsUsed=true end
 return out,errors
end


function M.preset(name,profile,out,track,length)
 local p=(name=='Nordschleife' or name=='Circuit') and 'J' or name=='Essais' and 'P' or name=='Qualifications' and 'Q' or name=='Endurance' and profile or 'C'
 out=M.validate(p,M.defaults(p),out)


 local base=presetSections[name] and name or p=='J' and (track~=nil and M.trackDayPreset(track,length or 0) or 'Circuit') or 'Course'
 local sections=presetSections[base]
 for _,group in ipairs(M.sections) do out['section_'..group]=sections[group]==true end
 for key,value in pairs(presetValues[base]) do out[key]=value end
 local endurance=name=='Endurance' and profile~='Q' and profile~='P'
 if endurance then out.section_endurance=true; out.enduranceOverlay=true; out.multiClass=true; out.lapseEnabled=true end

 if name=='Endurance' and profile=='C' then out.classNuance=true end
 out.configured=true
 return out
end
function M.on(p,group) return p[sectionKeys[group]]==true end
function M.any(p)
 for _,group in ipairs(M.sections) do if group~='globals' and group~='lights' and M.on(p,group) then return true end end
 return false
end

function M.effective(profile,p,out)
 out=out or {}
 for _,s in ipairs(M.schema) do
  if p[s.sectionKey]==true then out[s.key]=p[s.key] else out[s.key]=s.defaults[profile] end
 end
 for _,group in ipairs(M.sections) do local key=sectionKeys[group]; out[key]=p[key]==true end
 out.classPatterns=M.on(p,'endurance') and p.classPatterns or ''


 if not M.on(p,'general') then out.paceSpreadPct=0; out.aggrSpreadPct=0; out.cautSpreadPct=0; out.brakeZonePct=100; out.spawnMode='native'; out.pitExitSpread=0 end
 if not M.on(p,'yield') then out.yieldEnabled=false; out.pressureEnabled=false; out.qualiTraffic=false; out.qualiCoolLaps=false end
 if not M.on(p,'blue') then out.blueFlagEnabled=false end
 if not M.on(p,'flash') then out.flashMode='never'; out.hornEnabled=false; out.aiFlashEnabled=false end
 if not M.on(p,'overtake') then out.overtakeEnabled=false; out.defenseEnabled=false; out.slipstreamEnabled=false end
 if not M.on(p,'human') then out.paceDriftPct=0; out.personalLineJitter=0; out.laneBiasEnabled=false; out.lapseEnabled=false; out.mistakesEnabled=false end
 if not M.on(p,'start') then out.startDelay=0; out.startRelax=0; out.startCautionMult=1; out.startAggrMult=1; out.startLaneHold=false; out.firstLapCare=false end
 if not M.on(p,'accidents') then
  out.obstacleEnabled=false; out.contactRecovery=false; out.incidentStop=false; out.yellowEnabled=false; out.yellowHud=false; out.playerPenalties=false; out.aiPenalties=false

  if M.on(p,'rules') then out.yellowMessage=p.yellowMessage; out.flagPanel=p.flagPanel; out.deltaBeeps=p.deltaBeeps else out.yellowMessage=false; out.flagPanel=false; out.deltaBeeps=false end
 end
 if not M.on(p,'rules') then
  out.noMoveBraking=false; out.neutralization='local'; out.mandatoryStops=0; out.minPitTime=0; out.maxStintMin=0
  out.overtakeMode=false; out.bopEnabled=false; out.proAmEnabled=false; out.predictableSlowClass=false; out.redFlagEnabled=false; out.drsAssist=false

  out.rulesDrs=false; out.aiDrs=false; out.pitsClosed='open'; out.redFlagWork=false; out.pitRepair=false

  out.safetyCarEscalation=false
 end

 out.drsBeepVolume=p.drsBeepVolume
 if not M.on(p,'endurance') then out.enduranceOverlay=false; out.multiClass=false; out.stintLevelSwing=0; out.stintDegradationPct=0 end
 if not M.on(p,'weather') then out.weatherAdaptation=false; out.weatherTyresEnabled=false; out.rainGripBoostPct=0; out.weatherMessage=false end

 if not M.on(p,'overtake') then out.towBreakEnabled=false; out.dirtyAirEnabled=false; out.finalLapsEnabled=false end
 if not M.on(p,'weather') then out.outLapEnabled=false; out.lockWearEnabled=false end
 if not M.on(p,'strategy') then out.strategyEnabled=false; out.failuresEnabled=false end
 if not M.on(p,'sanctions') then for _,key in ipairs(M.sanctionSwitches) do out[key]=false end end

 if not M.on(p,'human') then out.fineInputs=false; out.dynamicPersona=false end
 if not M.on(p,'lateral') then out.rearAwareness=false; out.aiTurnSignals=false end
 if not M.on(p,'overtake') then out.passAid=false end
 if not M.on(p,'weather') then out.wearPace=false end
 if not M.on(p,'strategy') then out.strategySmart=false end
 if not M.on(p,'start') then out.raceStart='standing' end
 return out
end
function M.effectiveGlobals(g,p,out)
 out=out or {}; for key,value in pairs(g) do out[key]=value end
 if not M.on(p,'globals') then
  for _,key in ipairs(M.globalRuntimeKeys) do out[key]=M.globalDefaults[key] end
 end
 return out
end

function M.needsOffset(p,profile)
 return p.yieldEnabled or p.blueFlagEnabled or p.flashMode~='never' or p.overtakeEnabled or p.defenseEnabled and (profile==nil or profile=='C') or p.obstacleEnabled or p.laneBiasEnabled or p.personalLineJitter>0 or p.multiClass
end
local function equal(a,b) return a==b or type(a)=='number' and type(b)=='number' and math.abs(a-b)<1e-6 end

local trafficOld={trafficGapSeconds=1.2,trafficVariation=35,trafficMaxReduction=10}

local startOld={startCautionMult=1.6,startAggrMult=0.6}



local startOld126={startDelay=12,startRelax=12}
local startMoved127={startDelay=12,startRelax=12,startLaneHold=true}

local flashOld128={J=120,P=150,Q=150,C=100,H=120}
local flashCloseOld128={J=5,P=4,Q=4,C=6,H=5}

M.switchKeys={mandatoryStops=true,safetyCarEscalation=true}

function M.legacyMatch(profile,p)
 if p.classPatterns~='' then return nil end
 local base=M.validate(profile,M.defaults(profile),{})
 for _,name in ipairs(legacyCandidates[profile] or {}) do
  local endurance=name=='Endurance'
  local sections=legacySections[endurance and (profile=='J' and 'Nordschleife' or 'Course') or name]
  local same=true
  for _,s in ipairs(M.schema) do
   if not newKeys[s.key] then
    local expected=trafficOld[s.key] or s.key=='flashRange' and flashOld128[profile] or s.key=='flashCloseAdvantage' and flashCloseOld128[profile] or profile=='C' and (startOld[s.key] or startOld126[s.key]) or base[s.key]
    if endurance and (s.key=='enduranceOverlay' or s.key=='multiClass' or s.key=='lapseEnabled') then expected=true end
    if not equal(p[s.key],expected) then same=false; break end
   end
  end
  for _,group in ipairs(M.sections) do
   if not same then break end
   local expected=legacyGroups[group]==true and (sections[group]==true or endurance and group=='endurance')
   if group~='lights' and p['section_'..group]~=expected then same=false end
  end
  if same then return name end
 end
 return nil
end


function M.upgradeObstacles(p) if p.section_start==true and not p.section_accidents then p.section_accidents=true; p.yellowEnabled=false; p.incidentStop=false end end









local keys18={safetyCarEscalation=true}
M.dataRevision=23
function M.migrateProfile(profile,p,from,_preset,out)
 out=out or {}
 if from<5 and equal(p.deltaTolerance,0.1) then p.deltaTolerance=M.defaults(profile).deltaTolerance; out[#out+1]=profile..':delta' end
 if from<6 and not M.solo(profile) and p.pitsClosed=='pitFcy' then
  p.pitsClosed='open'
  if M.ruleCategory(profile,p,keys18)=='GT' then out[#out+1]=profile..':regles GT' else p.pitsClosed='pitFcy' end
 end


 if from<7 and profile~='C' then
  if p.mistakesEnabled==false then p.mistakesEnabled=true end
  if M.solo(profile) and equal(p.mistakeRate,0.5) then p.mistakeRate=M.defaults(profile).mistakeRate end
 end

 if from<8 and profile=='H' and not p.configured and not M.anySection(p) then p.section_rules=true end

 if from<7 and not M.solo(profile) and p.pitFuel=='refuel' then
  p.pitFuel='plan'
  local category=M.ruleCategory(profile,p,keys18)
  if category~='F1' and category~='F1_2026' and category~='GT' then p.pitFuel='refuel' end
 end


 if from<11 and not M.solo(profile) then p.safetyCarEscalation=true end


 if from<12 then
  local moved=false
  for key,old in pairs(trafficOld) do if equal(p[key],old) then p[key]=M.defaults(profile)[key]; moved=true end end
  if moved and profile=='J' then out[#out+1]='J:espacement' end
 end

 if from<16 and profile=='C' then
  local moved=false
  for key,old in pairs(startMoved127) do if equal(p[key],old) then p[key]=M.defaults('C')[key]; moved=true end end
  if moved then out[#out+1]='C:depart' end
 end


 if from<17 then
  local moved=false
  if equal(p.flashRange,flashOld128[profile]) then p.flashRange=M.defaults(profile).flashRange; moved=true end
  if equal(p.flashCloseAdvantage,flashCloseOld128[profile]) and not equal(p.flashCloseAdvantage,M.defaults(profile).flashCloseAdvantage) then p.flashCloseAdvantage=M.defaults(profile).flashCloseAdvantage; moved=true end
  if moved then out[#out+1]=profile..':phares' end
 end

 if from<13 and profile=='C' then
  local moved=false
  for key,old in pairs(startOld) do if equal(p[key],old) then p[key]=M.defaults('C')[key]; moved=true end end
  if moved then out[#out+1]='C:depart' end
 end


 if from<19 and p.section_rules==true then
  if profile=='C' and not (p.section_strategy==true and p.section_sanctions==true) then p.section_strategy=true; p.section_sanctions=true; out[#out+1]='C:strategie et sanctions'
  elseif (profile=='P' or profile=='Q') and p.section_sanctions~=true then p.section_sanctions=true; out[#out+1]=profile..':sanctions' end
 end


 if from<20 and equal(p.strategyTyreWearPct,75) then p.strategyTyreWearPct=M.defaults(profile).strategyTyreWearPct; out[#out+1]=profile..':usure des pneus 30 %' end


 if from<21 and profile=='C' and equal(p.startDelay,1) then p.startDelay=M.defaults('C').startDelay; out[#out+1]='C:attente au depart 2 s' end
 return out
end

function M.migrate(g,profiles,customs)
 if g.dataRevision>=M.dataRevision then return nil end
 local upgraded={}



 local fresh=g.dataRevision==0 and not g.presetsUsed

 for _,profile in ipairs(M.profiles) do
  local p=profiles[profile]
  if p.configured or M.sectionsChanged(profile,p) then fresh=false end
 end
 if g.dataRevision<1 then
  for _,profile in ipairs(M.profiles) do
   local p=profiles[profile]
   local name=M.legacyMatch(profile,p)
   if name then M.preset(name,profile,p); upgraded[#upgraded+1]=profile..':'..name else M.upgradeObstacles(p) end
  end
 end

 if g.dataRevision<2 then for _,profile in ipairs(M.profiles) do profiles[profile].yellowHud=false end end

 if g.dataRevision<3 then
  for _,profile in ipairs(M.profiles) do
   local name=M.migrateRules(profile,profiles[profile])
   if name and name~='base' then upgraded[#upgraded+1]=profile..':regles '..name end
  end
 end
 if fresh then M.applyRules('base',profiles) end
 for _,profile in ipairs(M.profiles) do M.migrateProfile(profile,profiles[profile],g.dataRevision,false,upgraded) end


 if g.dataRevision<9 and not fresh then g.language='fr' end


 if g.dataRevision<11 and not fresh then g.safetyCarPicked=g.safetyCarModel~='' and g.safetyCarModel~=M.globalDefaults.safetyCarModel end
 if g.dataRevision<11 and g.safetyCarModel=='' then g.safetyCarModel=M.globalDefaults.safetyCarModel end

 if g.dataRevision<13 and g.useBrakeAssist==false then g.useBrakeAssist=true end



 local restored=g.dataRevision<14 and not fresh and g.offsetSign==0 and g.sideSign==0
 if restored then g.offsetSign=-1; g.sideSign=-1 end

 if g.dataRevision<15 then g.overlayBlockMessages=true end



 if g.dataRevision<18 and g.trackLights==false then for _,profile in ipairs(M.profiles) do profiles[profile].section_lights=false end end


 if g.dataRevision<22 and customs then local profile=M.markPersonal(g,customs); if profile then upgraded[#upgraded+1]=profile..':preset personnel garde' end end




 local provisional=false
 if g.dataRevision<23 and M.K.signProvisional and g.offsetSign==0 and g.sideSign==0 then g.offsetSign=-1; g.sideSign=-1; g.signProvisional=true; provisional=true end
 g.dataRevision=M.dataRevision
 return upgraded,fresh,restored,provisional
end




local zoneRuleKeys={zoneDeltaPct=true,slowZoneKmh=true,yellowSpeedKmh=true}
M.ruleSchema={}
M.keptKeySet={classPatterns=true}; for _,key in ipairs(M.preferenceKeys) do M.keptKeySet[key]=true end
for _,s in ipairs(M.schema) do if s.group=='rules' and not M.keptKeySet[s.key] or zoneRuleKeys[s.key] then M.ruleSchema[#M.ruleSchema+1]=s end end
M.ruleKeySet={}
for _,s in ipairs(M.ruleSchema) do M.keptKeySet[s.key]=true; M.ruleKeySet[s.key]=true end


M.presetKeptKeySet={classPatterns=true}; for _,key in ipairs(M.preferenceKeys) do M.presetKeptKeySet[key]=true end


M.presetMatchSkip={}; for key in pairs(M.presetKeptKeySet) do M.presetMatchSkip[key]=true end; for _,s in ipairs(M.ruleSchema) do M.presetMatchSkip[s.key]=true end


function M.kept(profile,key) return M.keptKeySet[key] and (not M.solo(profile) or not M.ruleKeySet[key]) end
local function ruleValue(values,s,profile) local value=values[s.key]; if value==nil then return s.defaults[profile] end return value end
function M.restore(profile,p)
 local kept={}
 for _,group in ipairs(M.sections) do kept['section_'..group]=p['section_'..group] end
 for key in pairs(M.keptKeySet) do if M.kept(profile,key) then kept[key]=p[key] end end
 M.validate(profile,M.defaults(profile),p)
 for key,value in pairs(kept) do p[key]=value end
 M.validate(profile,p,p)
 return p
end
local function applyValues(category,profile,p) for _,s in ipairs(M.ruleSchema) do p[s.key]=ruleValue(M.rulePresets[category],s,profile) end end



function M.weekendSwitch(profiles,key,on)
 for _,profile in ipairs(M.ruleProfiles) do
  local p=profiles[profile]
  if not (p.configured or M.anySection(p)) and M.recommended[profile] then M.preset(M.recommended[profile],profile,p) end
  if key=='mandatoryStops' then p.mandatoryStops=on and 1 or 0 else p[key]=on==true end
  p.configured=true
  M.validate(profile,p,p)
 end
end


function M.rulesLocked(profile,frame)
 return profile=='C' and frame~=nil and frame.started==true and frame.finished~=true
end
function M.applyRules(category,profiles)
 if not M.rulePresets[category] then return false end
 for _,profile in ipairs(M.ruleProfiles) do
  local p=profiles[profile]
  if not p.configured and not M.anySection(p) and M.recommended[profile] then M.preset(M.recommended[profile],profile,p) end
  applyValues(category,profile,p)
  p.section_rules=true; p.configured=true
  M.validate(profile,p,p)
 end
 return true
end




function M.spreadRules(from,profiles)
 if M.solo(from) then return false end
 local source=profiles[from]
 for _,profile in ipairs(M.ruleProfiles) do
  local p=profiles[profile]
  if profile~=from then
   for _,s in ipairs(M.ruleSchema) do p[s.key]=source[s.key] end
   M.validate(profile,p,p)
  end
 end
 return true
end



function M.mark(g,profile)
 for x,name in (g.builtinMarks or ''):gmatch('(%u)=(%w+)') do if x==profile then return name end end
 return ''
end
function M.setMark(g,profile,name)
 local parts={}
 for _,x in ipairs(M.profiles) do local value=x==profile and (name or '') or M.mark(g,x); if value~='' then parts[#parts+1]=x..'='..value end end
 g.builtinMarks=table.concat(parts,',')
end





local builtinProfiles={Nordschleife={J=true},Circuit={J=true},Essais={P=true},Qualifications={Q=true},Course={C=true},Endurance={J=true,C=true}}
M.personalMark='Perso'


function M.markPersonal(g,customs)
 local name=type(g.loadedPreset)=='string' and g.loadedPreset:match('^custom:(.+)$')
 if not name then return nil end
 for i=1,M.K.maxPresets do
  local entry=customs[i]
  if entry and entry.name==name then M.setMark(g,entry.profile,M.personalMark); return entry.profile end
 end
 return nil
end


function M.isNordschleife(track,length)
 local name=tostring(track or ''):lower()
 if name:find('nordschleife',1,true) then return true end
 return (name:find('nurburgring',1,true) or name:find('nuerburgring',1,true)) and (tonumber(length) or 0)>M.K.nordschleifeMinLength or false
end
function M.trackDayPreset(track,length) return M.isNordschleife(track,length) and 'Nordschleife' or 'Circuit' end
function M.sessionPreset(g,profile,track,length)
 if profile=='H' or not M.recommended[profile] then return nil end
 local mark=M.mark(g,profile)
 if mark==M.personalMark then return nil end
 if profile=='J' and track~=nil and (mark=='Nordschleife' or mark=='Circuit' or not builtinProfiles[mark]) then return M.trackDayPreset(track,length) end
 if builtinProfiles[mark] and builtinProfiles[mark][profile] then return mark end
 return M.recommended[profile]
end




function M.applyBuiltin(g,profiles,name,profile,keepRules,kept,track,length)
 local p=profiles[profile]; kept=kept or {}
 for key in pairs(kept) do kept[key]=nil end
 for key in pairs(M.presetKeptKeySet) do kept[key]=p[key] end
 if keepRules then for _,s in ipairs(M.ruleSchema) do kept[s.key]=p[s.key] end end
 M.preset(name,profile,p,track,length)
 for key,value in pairs(kept) do p[key]=value end
 M.validate(profile,p,p)
 if not keepRules then if name=='Endurance' and profile=='C' then M.applyRules('Endurance',profiles) else M.spreadRules(profile,profiles) end end
 g.loadedPreset='builtin:'..name; g.presetsUsed=true; M.setMark(g,profile,name)
end

function M.withRules(category,profile,p) applyValues(category,profile,p); return M.validate(profile,p,p) end

local axis13={'noMoveBraking','neutralization','majorIncidentTime','fcySpeedKmh','fcyDeltaPct','vscDeltaPct','neutralizationHold',
 'redFlagEnabled','redFlagCars','redFlagSpeedKmh','redDeltaPct','redFlagHold','mandatoryStops','pitWindowOpenPct',
 'pitWindowClosePct','pitTyres','pitCompoundChange','minPitTime','maxStintMin','pitMessage','overtakeMode','overtakeModeGap',
 'overtakeModeBoostPct','rulesDrs','rulesDrsLaps','aiDrs','bopEnabled','bopStrengthPct','proAmEnabled','predictableSlowClass','yellowSpeedKmh'}
local presets13={base={},F1={neutralization='vsc',mandatoryStops=1,pitWindowOpenPct=20,pitWindowClosePct=80,pitCompoundChange=true,overtakeMode=true},
 GT={neutralization='fcy',mandatoryStops=1,pitWindowOpenPct=30,pitWindowClosePct=70,minPitTime=50,bopEnabled=true,proAmEnabled=true},
 Endurance={neutralization='fcy',yellowSpeedKmh=80,maxStintMin=50,bopEnabled=true,proAmEnabled=true,predictableSlowClass=true}}
local schemaByKey={}; for _,s in ipairs(M.schema) do schemaByKey[s.key]=s end
local oldZoneDelta=70
local function category13(profile,p)
 for _,name in ipairs({'base','F1','GT','Endurance'}) do
  local values=presets13[name]; local same=true
  for _,key in ipairs(axis13) do
   local expected=values[key]; if expected==nil then expected=schemaByKey[key].defaults[profile] end
   if not equal(p[key],expected) then same=false; break end
  end
  if same then return name end
 end
 return nil
end



function M.migrateRules(profile,p)
 local zone=p.zoneDeltaPct
 local name=not M.solo(profile) and category13(profile,p) or nil
 if name then applyValues(name,profile,p) end
 if not equal(zone,oldZoneDelta) then p.zoneDeltaPct=zone elseif not name then p.zoneDeltaPct=schemaByKey.zoneDeltaPct.defaults[profile] end
 return name
end



function M.closestRuleCategory(profile,p,skip)
 local best,count=nil,math.huge
 for _,category in ipairs(M.ruleCategories) do
  local values=M.rulePresets[category]; local n=0
  for _,s in ipairs(M.ruleSchema) do if not (skip and skip[s.key]) and not equal(p[s.key],ruleValue(values,s,profile)) then n=n+1 end end
  if n<count then best,count=category,n end
 end
 return best
end
function M.ruleCategory(profile,p,skip)
 for _,category in ipairs(M.ruleCategories) do
  local values=M.rulePresets[category]; local same=true
  for _,s in ipairs(M.ruleSchema) do
   if not (skip and skip[s.key]) and not equal(p[s.key],ruleValue(values,s,profile)) then same=false; break end
  end
  if same then return category end
 end
 return nil
end


function M.autoProfile(frame)
 local declared=frame.configType~=nil and frame.configType>=1 and frame.configType<=7
 local kind=declared and frame.configType or frame.type


 if declared and frame.configTrackDay and (kind==1 or kind==2) then return 'J' end
 if kind==3 then return 'C' elseif kind==2 then return 'Q' end
 if kind==1 and declared and not frame.configTrackDay then return 'P' end

 if kind>=4 and kind<=7 then return 'H' end
 return 'J'
end


local k159ha={runsSalt=15901,runsWeights={quali=0.30,long=0.25,tyre=0.15,fuel=0.15,setup=0.15},runsSecondChance=0.35,
 runsLongMin=8,runsLongMax=14,runsTyreMin=4,runsTyreMax=7,runsFuelMin=5,runsFuelMax=8,runsSetupMin=2,runsSetupMax=3,
 runsTimeMargin=1.1,runsFuelReserveLaps=1.5,runsHeavyLaps=10,runsLongFuelMargin=1.05,
 runsBoxQMin=60,runsBoxQMax=150,runsBoxPMin=90,runsBoxPMax=300,runsConcurrent=3}
for key,value in pairs(k159ha) do assert(M.K[key]==nil,key); M.K[key]=value end



local k159hb={startVarietyShare=0.4,startVarietyBias=0.3,startVarietySalt=1597,startVarietyPlaces=64,compoundPirelliBase=8,
 compoundHardnessLong={{'hyper',0},{'ultra',1},{'extrasoft',2},{'supersoft',2},{'soft',3},{'medium',4},{'extrahard',6},{'superhard',6},{'hard',5}},
 compoundHardnessShort={HS=0,US=1,ES=2,SS=2,S=3,M=4,H=5,EH=6,SH=6},
 damagePitScanPeriod=2,damagePitBody=150,damagePitSuspension=0.08,damagePitGearbox=0.3,damagePitEngine=700,damagePitConfirm=3,
 damagePitMinLapsLeft=2,damagePitUnsafe=0.3,damagePitRegrowBody=40,damagePitRegrowSuspension=0.05,
 damagePitRegrowEngine=150}
for key,value in pairs(k159hb) do assert(M.K[key]==nil,key); M.K[key]=value end

M.raceKeys.strategyStartVariety=true


local k159hc={presetFileFormat=1,presetFileMaxBytes=524288,presetFolder='AdvancedIA',presetFileName='AdvancedIA-presets.ini'}
for key,value in pairs(k159hc) do assert(M.K[key]==nil,key); M.K[key]=value end









local k159t={slowUnknownRatio=0.5,yieldRefuseKmh=3,yieldPassDeltaKmh=15,yieldCapGapOff=40,yieldCapDecelOff=6,nordschleifeMinLength=15000,radarClearMargin=0.3,radarOpenRate=0.5,radarLatTau=0.2,radarOpenHold=0.15,corridorLeadMargin=1.5,cornerPhaseGap=0.5,yieldQueueTime=3,slowQueueLinks=6,cornerNoseMargin=2.2,cornerGiveLift=0.8,cornerGiveHold=1.5,cornerEntryWindow=1,cornerGiveBackGap=20,cornerLiftRate=1,yieldCapReleaseKmh=8,yieldCapReleaseMargin=15}
for key,value in pairs(k159t) do assert(M.K[key]==nil,key); M.K[key]=value end


M.raceKeys.strategySmart=true; M.raceKeys.raceStart=true
M.sanctionKeys.sanContact=true; M.sanctionKeys.sanPlayerContact=true; M.sanctionRaceKeys.sanPlayerContact=true
for _,key in ipairs({'sanContact','sanPlayerContact'}) do M.sanctionSwitches[#M.sanctionSwitches+1]=key end



M.pendingKeys={}
do
 local effective=M.effective
 local default={}; for _,s in ipairs(M.schema) do default[s.key]=s.defaults end
 function M.effective(profile,p,out)
  out=effective(profile,p,out)
  for key in pairs(M.pendingKeys) do out[key]=default[key][profile] end
  return out
 end
end

local k160={rollCallDistance=500}
for key,value in pairs(k160) do assert(M.K[key]==nil,key); M.K[key]=value end







local k160b={blameSample=0.25,blameMinKmh=3,blameStartGrace=20,blameStartKmh=30,blameChain=2,blameRejoin=3,blameCutTime=1,blameMoveRatio=2,blameOutcome=6,
 blamePlaces=2,blameWarnings=2,blameOutTime=15,blameMoveMin=1,blamePairGap=3}
for key,value in pairs(k160b) do assert(M.K[key]==nil,key); M.K[key]=value end













local k160c={exitCornerFrom=0.5,exitMinCorner=0.6,exitGas=0.5,exitFromPro=0.85,exitFromAm=0.7,exitTimePro=0.4,exitTimeAm=1.4,exitWetGain=0.5,exitPassFactor=0.5,exitFromRear=0.9,exitStep=0.05,coastBrake=0.1,coastThrottle=0.5,coastTimeAm=0.3,limitSlipDeg=6,limitSlipTime=0.3,limitChance=0.08,limitSeverity=0.75,limitTimeMin=0.2,limitTimeMax=0.5,limitCooldown=90,styleGradeShare=0.7,
 moodPressTime=0.6,moodPressHold=2,moodStressRise=0.05,moodStressContact=0.3,moodStressMistake=0.2,moodStressPlace=0.15,moodStressDecay=45,moodDecayPro=0.7,moodDecayAm=1.3,moodGainPro=0.7,moodGainAm=1.3,moodFatigueStint=3600,moodFatigueRace=0.3,moodFatigueRest=0.5,phaseEarly=0.95,phaseEarlyEnd=0.1,phaseLate=1.08,phaseLateShare=0.15,moodAggrGain=0.12,moodAggrMin=0.85,moodAggrMax=1.15,moodCautionStress=0.1,moodCautionFatigue=0.08,moodLevelFatigue=0.012,moodRiskStress=0.5,moodLapseFatigue=0.3,moodLogGap=120,moodLogStress=0.6,moodLogFatigue=0.6,moodPeriod=1,moodStepMax=2}
for key,value in pairs(k160c) do assert(M.K[key]==nil,key); M.K[key]=value end














local k160d={pitLossAlpha=0.3,pitLossMin=8,pitLossMax=120,pitLossLogStep=1,pitLossMinSpeed=5,smartRivalGap=1.5,rejoinAhead=4,rejoinSlowPct=0.01,rejoinTrain=3,rejoinTrainSpan=6,rejoinDelayMax=2,
 scMinWear=0.5,scGainMin=8,scStayOutLaps=6,scStayOutShare=0.5,scDecideDelay=1,seStrategyKey='SpotterEnginer.strategy',seStrategyBytes=160,seStrategyStale=6,seStrategyMax=600,
 strategyPubKey='AdvancedIA.strategy',strategyPubPeriod=1,
 wearPaceStart=0.3,wearPaceAtThreshold=0.015,wearPaceCliff=0.04,compoundPaceStep=0.0035,compoundPaceMax=0.007,fuelPace=0.012,wearHotDelta=15,wearHotTime=10,wearHotPct=0.005,
 wearScaleMaxLoss=0.05,wearScaleMaxGain=0.01,wearBrakeCaution=0.08,wearExitGain=0.5,wearScaleRate=0.01,wearLogStep=0.005,wearLogGap=60,wearPeriod=1}
for key,value in pairs(k160d) do assert(M.K[key]==nil,key); M.K[key]=value end






local k160e={formationMaxLength=7500,formationMinKmh=80,formationSpeedMult=1.25,formationExtraLaps=1,rollGreenBefore=100,rollClearAhead=400,rollT1Min=4,rollT1Max=25}
for key,value in pairs(k160e) do assert(M.K[key]==nil,key); M.K[key]=value end


local k160m={formationGrace=8}
for key,value in pairs(k160m) do assert(M.K[key]==nil,key); M.K[key]=value end





local k159n={offLineKmh=25,trackWedgedTime=45,passAfterIncident=30,lineAheadMeters=5}
for key,value in pairs(k159n) do assert(M.K[key]==nil,key); M.K[key]=value end








local k160a={rearMinSa=5,rearHorizonMin=1,rearHorizonMax=2,rearHold=0.5,rearFastSa=25,rearYieldTtc=6,rearFastRange=250,rearFastConfirm=0.5,defensePulledLat=2.2,intentCaution=1.1,rearLogMove=0.05,rearCloseMin=8,rearCloseTime=0.7,rearCloseSa=10,rearThrottleRate=0.6,rearThrottleFloor=0.7,rearCapDecel=6,rearLevelRate=0.03,rearBrakeMax=0.12,rearLastTtc=0.8,rearCautionRate=0.5,commitLat=1.5,commitGap=8,holdLineTime=1.5,passAidLevel=0.015,passAidMax=6,passAidPairCooldown=30,passAidSaMax=5,passAidHold=4,passReopenSa=25,passReopenWait=10,yieldOverallMargin=0.01,yieldRefuseOverallKmh=8,passMinRoom=1.2}
for key,value in pairs(k160a) do assert(M.K[key]==nil,key); M.K[key]=value end









local k160m2={reachWideShare=0.8,reachWideMeters=4,reachEdgeMargin=0.5,reachLook1=1,reachLook2=2,reachLookMin=15,blameLatPeriod=0.1,blameCornerG=3,lineStill=0.05,seStartMinMajor=1,seStartMinMinor=3,seStartMinPatch=4,troubleRatio=0.5,troubleTime=3,sideMinRoom=1,reachSideMax=6,passReopenHold=8,reachLookPeriod=0.1,reachLookStagger=0.016}
for key,value in pairs(k160m2) do assert(M.K[key]==nil,key); M.K[key]=value end












local k160s={scNominalKmh=120,scCatchPct=10,scPacePct=25,scWatch=200,scOverlapDrop=10,scPassedMax=60,scLeaveStill=10,scBunchGap=150,scBunchLaps=3}
for key,value in pairs(k160s) do assert(M.K[key]==nil,key); M.K[key]=value end













local k160w={frankOffM=1,frankClear=0.4,frankLevel=0.02,frankMax=8,frankDeltaKmh=30,frankLiftGap=20,frankThirdGap=25,frankYieldLevel=0.06,frankYieldExtra=15,
 qualiOutLevel=0.12,qualiOutRamp=3,qualiYieldLead=6,nameRefresh=1,frankTracePeriod=2,frankTraceGap=30}
for key,value in pairs(k160w) do assert(M.K[key]==nil,key); M.K[key]=value end





local k160x={abortTgGrow=0.1,abortTgSpeed=10,passReopenWaitRace=20,sideFollowerLat=1,teleportPath=1.5,scDownKmh=40,frankCapMinKmh=50}
for key,value in pairs(k160x) do assert(M.K[key]==nil,key); M.K[key]=value end




local k160y={passSoonShare=1,passIgnoreMaxRace=180,scFreeMargin=20,scFreeGap=80,scBunchMax=420,scGiveNear=15,scGiveStuck=8,scGiveFloor=60,troubleAheadGap=30,planSpreadLaps=2}
for key,value in pairs(k160y) do assert(M.K[key]==nil,key); M.K[key]=value end



M.globalDefaults.trackMemory=false
M.raceKeys.startRealism=true





M.startUiKeys={startDelay=true,startCautionMult=true,startAggrMult=true,startRelax=true,startLaneHold=true,firstLapCare=true}
M.trackDayOnlyKeys={trafficGapSeconds=true,trafficDensityGain=true,trafficVariation=true,trafficMaxReduction=true}
M.notRaceKeys={yieldEnabled=true,pressureEnabled=true,pressureGap=true,pressureTime=true}
function M.uiHidden(profile,key) return M.hidden(profile,key) or profile~='C' and M.startUiKeys[key] or profile~='J' and M.trackDayOnlyKeys[key] or profile=='C' and M.notRaceKeys[key] or false end
M.pendingGlobals={} -- réglage global trackMemory livré (tranches A et B) ; la table reste (ui.lua, effectiveness.py)
do
 local effectiveGlobals=M.effectiveGlobals
 function M.effectiveGlobals(g,p,out)
  out=effectiveGlobals(g,p,out)
  for key in pairs(M.pendingGlobals) do out[key]=M.globalDefaults[key] end
  return out
 end
end





local k161={trackLengthTol=0.01,trackKeyMax=96,zoneFolder='tracks',paceFolder='pace',trackFileFormat=1,trackFileMaxBytes=262144,trackFileMaxSections=512,trackFileMaxKeys=32,trackFileMaxValue=8192}
for key,value in pairs(k161) do assert(M.K[key]==nil,key); M.K[key]=value end






local k161c={blueCatchTime=5,blueBrakeTime=2,blueZoneTime=4,blueFastSa=20,blueSlowMin=0.02,nuanceBattleTime=1,blueTruceAfter=2,unlapMargin=1.3,relapHold=10,relapSa=8,
 classSideLat=1.5,classNoDiveTime=2,classAmCorridor=1.2,classTrainTime=2,bluePlayerOrderTime=2,blueStartGrace=30,blueTrainRange=200,trafficKeyBytes=160,nuanceLogGap=20,classAmStyle=0.6}
for key,value in pairs(k161c) do assert(M.K[key]==nil,key); M.K[key]=value end










local k161a={zoneLearntMax=64,zoneNote=64,zoneConfirmSessions=2,zoneForgetSessions=10,brakeLearnHits=5,brakeLearnCars=2,zoneBrakeMax=48,
 attackMargin=0.8,attackWaitTime=6,attackNoWaitSa=20,attackStuckTime=8,attackLearnPasses=4,attackMergeMeters=150,attackMaxMeters=600,attackMinMeters=120,attackMax=8,
 lineRamp=1.5,lineShareDefault=0.5,lineSalt=1613,zoneSavePeriod=300,lineWet=0.1}
for key,value in pairs(k161a) do assert(M.K[key]==nil,key); M.K[key]=value end









local k161b={paceMapMaxBytes=262144,paceMapModels=32,paceMapNameMax=64,paceMapSerialMax=100000,paceMapAlpha=0.3,paceMapLow=0.7,paceMapHigh=1.15,
 paceMapMinShare=0.5,paceMapWetShare=0.1,paceMapMaxSpeed=1200,paceMapSpike=0.4,paceMapSavePeriod=300,paceMapSlowMs=30,paceMapStartNote=5,
 priorRatioMin=10,priorRatioLow=0.8,priorRatioHigh=1.2,priorRatioAlpha=0.1,priorWetMax=0.1}
for key,value in pairs(k161b) do assert(M.K[key]==nil,key); M.K[key]=value end












local k161d={formLaunchGap=0.6,formBunchDistance=800,formOutDistance=300,formSlowMult=0.75,formBriskMult=1.15,formOffsetRate=0.25,
 weaveAmp=0.35,weaveClear=25,weaveStopBefore=600,weavePeriodMin=2,weavePeriodMax=3.5,weaveMinKmh=40,weaveLatAccel=1.5,rollZoneFrom=300,
 anticReactMin=0.05,anticReactMax=0.4,anticPoorShare=0.12,anticPoorMax=3,anticBogThrottle=0.75,anticBogTimeMin=0.8,anticBogTimeMax=1.8,anticBogFloor=0.85,
 anticWetGain=1,anticSalt=1619,anticAccordionRow=3,anticRollThrottle=0.7,anticTail=1,
 jumpCreepMin=0.2,jumpCreepMeters=0.6,jumpCreepKmh=3,jumpFlagrantMeters=4,jumpFlagrantLead=0.5,jumpFlagrantMult=2,jumpJudgeTime=5,
 anticJumpChance=0.03,anticJumpLeadMin=0.1,anticJumpLeadMax=0.35}
for key,value in pairs(k161d) do assert(M.K[key]==nil,key); M.K[key]=value end









local k161e={wxPeriod=1,wxTrendTau=60,wxSlopeMin=0.0005,wxEtaMax=900,wxPaceTau=8,wxSlickPenalty=0.5,wxInterHeavy=0.2,wxDryLine=0.15,wxWetOnDry=0.3,
 wxSkillMin=0.8,wxSkillMax=1.2,wxSkillSalt=1621,wxOnsetTime=90,wxOnsetCaution=1.1,wxWetMax=1.6,wxRiskSpan=0.08,wxAnticipate=90,wxGambleRisk=0.65,
 wxComboLaps=3,wxPitEntryFrom=0.7,wxShowerTime=180,wxProjectTime=300,wxProjectMax=0.3,wxMinStint=240,wxPitWave=3,wxLogGap=60,weatherKeyBytes=160,wxRetry=60,wxCallMax=180}
for key,value in pairs(k161e) do assert(M.K[key]==nil,key); M.K[key]=value end

local k161f={passLappedHold=10}
for key,value in pairs(k161f) do assert(M.K[key]==nil,key); M.K[key]=value end



local k161t={passFreeLat=1.2,abortTgGrowRace=0.3,pullOutCloseGap=8,pullOutClosingMin=1,passFreeCaution=1}
for key,value in pairs(k161t) do assert(M.K[key]==nil,key); M.K[key]=value end



local k161u={metaCarsPerFrame=8,slowFrameMs=40,slowFrameLogs=20,slowFrameGap=10}
for key,value in pairs(k161u) do assert(M.K[key]==nil,key); M.K[key]=value end










local k161v={gridPlayerWait=25,gridNodeAfter=400,gridNodeLatMax=1.6,gridLatClamp=0.85,gridWaitMax=12,gridWaitFirstMax=18,formWeaveFullKmh=80,formWeaveFastKmh=140,formWeaveFastShare=0.35,gridLateRoll=30,
 formWeaveAmp=0.85,formWeaveMax=0.85,formWeaveEdge=0.6,formWeaveRate=0.9,formWeaveRampMult=3,formWeaveStopBefore=800,
 formAheadBrakeTime=1,formAheadBrake=0.2,formBrakeTime=0.6,formBrakeDrop=30,formBrakeFloor=60,formBrakeEveryMin=8,
 formBrakeEveryMax=15,formBrakeClear=40,formBurstFrom=80,formBurstTo=45,formBurstKmh=12,formBurstTime=0.7,formBurstDecel=3}
for key,value in pairs(k161v) do assert(M.K[key]==nil,key); M.K[key]=value end





local k162a={cornerLatRef=10,jFollowTime=1,jFollowCaution=1.4,jPassMargin=0.5,qualiSacrificeTime=2,lapEndMeters=600,practiceLapMargin=0.015}
for key,value in pairs(k162a) do assert(M.K[key]==nil,key); M.K[key]=value end









local k162b={qualiExitGap=2,qualiGapLevel=0.08,qualiGapUntil=0.6,qualiOutMaxDrop=0.2,qualiGapMinSpeed=10,runsRedoMax=2,
 blueIgnoreStep=6,blueIgnoreMax=3,blueVetoGrace=2,boxLaneKmh=20,boxReleaseGap=60,boxReleaseMax=8,boxReleaseStill=3,boxReleaseCatch=15,
 formationMaxGap=44,formationGapTime=4,formationWaitMult=0.8,rejoinWaitMaxJ=30}
for key,value in pairs(k162b) do assert(M.K[key]==nil,key); M.K[key]=value end


M.raceOnlyKeys={defenseEnabled=true,defenseMaxOffset=true,defenseCooldown=true,defenseTriggerGap=true}

local k162c={lapseBrakeTime=3,lapseRearTime=6,lapseFastKmh=15}
for key,value in pairs(k162c) do assert(M.K[key]==nil,key); M.K[key]=value end




local k162q={passFreeCornerCaution=1,reachWideEdge=1.2,anticBogGrace=1}
for key,value in pairs(k162q) do assert(M.K[key]==nil,key); M.K[key]=value end





local k162s={seekLat=1,seekLatMax=5,seekTime=2,seekRange=90,seekSaMax=25,seekTTC=3,seekAheadTime=5,seekReturnTime=3,seekSettleLat=0.4,seekSettle=1.5,seekPullMargin=1.5,seekLogGap=20}










for key,value in pairs({wakePullGap=3,wakeStallSa=2,wakeStallTime=0.6,wakeStallGap=12,blueHoldTime=1.5,blueHoldSlack=30,blueYieldDeltaKmh=15,avoidLatMargin=0.6,avoidShareMin=0.35}) do assert(M.K[key]==nil,key); M.K[key]=value end



for key,value in pairs({pushLevel=0.03,pushCaution=1.0,pushTime=1.0,pushGapMin=25,pushMax=10,pushPairCooldown=20}) do assert(M.K[key]==nil,key); M.K[key]=value end
for key,value in pairs(k162s) do assert(M.K[key]==nil,key); M.K[key]=value end






local k163={rejoinStill=3,rejoinWedged=8,rejoinTries=3,rejoinGap=6,rejoinMaxTime=40,
 coolPace=0.70,coolDecel=3,coolMinKmh=50,coolRoomRange=150,coolOffset=0.5,coolOffsetRate=0.3}
for key,value in pairs(k163) do assert(M.K[key]==nil,key); M.K[key]=value end



for key,value in pairs({flTouchGap=2.5,flTouchClosing=0.4,flZoneBrakeMax=0.3,flZoneGap=6}) do assert(M.K[key]==nil,key); M.K[key]=value end




for key,value in pairs({raceConfirmTime=0.2,raceCloseShare=0.5,raceStallGrow=3,raceAttemptMax=30,passCornerExitC=0.45,passExitGas=0.8,rejoinLastWait=6,passExitWindow=0.2,passExitRise=0.01,pushWetMax=0.1}) do assert(M.K[key]==nil,key); M.K[key]=value end





for key,value in pairs({passLenientRatio=0.7,blameNudgeKmh=8,sanCrowdGap=8,sanCrowdLat=3.5}) do assert(M.K[key]==nil,key); M.K[key]=value end









for key,value in pairs({startWindowMax=10,flGuardTTC=0.8,diveGap=12,diveCorner=0.85,diveSa=5,raceSlowGap=40,raceSlowSa=12}) do assert(M.K[key]==nil,key); M.K[key]=value end
M.K.firstLapAggr=1; M.K.firstLapPassMargin=1; M.K.firstLapCorridor=1; M.K.firstLapPassCorner=M.K.passCornerC





for key,value in pairs({pitCloseLaps=1.5,pitCallLeadLaps=1}) do assert(M.K[key]==nil,key); M.K[key]=value end






for key,value in pairs({sprintMaxKm=100,sprintLapsSeen=2,sprintQuiet=5,sprintLapShare=0.97}) do assert(M.K[key]==nil,key); M.K[key]=value end


for key,value in pairs({unlapRacePct=3,unlapTailGap=200}) do assert(M.K[key]==nil,key); M.K[key]=value end










for key,value in pairs({blueFullSide=true,blueRampMult=1.6,blueHoldLift=0.22,blueHoldGap=80,slowEdgePin=true,slowGlueGap=30,slowPitTime2=5,slowPitBody2=120,slowPitSuspension2=0.11,slowWarnLead=400,slowWarnAfter=30}) do assert(M.K[key]==nil,key); M.K[key]=value end






for key,value in pairs({attackRampMult=1.6,wakeStallGapRace=6,slingGainKmh=10,pushTowGap=12,pushMaxRace=20}) do assert(M.K[key]==nil,key); M.K[key]=value end







for key,value in pairs({slingMinGap=3,wakeAlignLat=0.3,diveGapRace=10,diveSaRace=-2,diveCautionRace=0.6,diveCautionShare=0.85,pitPassSa=30}) do assert(M.K[key]==nil,key); M.K[key]=value end



for key,value in pairs({closeInEnabled=true,closeInMin=3,closeInGap=30,closeInKmh=150,closeInTTC=0.6,closeInRadarTTC=0.6,closeInBrakeLead=1.2,closeInFrontDecel=3,closeInNearGap=8,closeInNearSa=10,closeInHoldOff=2,closeInCaution=0.5,closeInMaxSa=20,closeInReleaseTime=1,closeInLogPeriod=20}) do assert(M.K[key]==nil,key); M.K[key]=value end











for key,value in pairs({duelAxles=true,duelTolerance=0.3,duelYawMin=0.05,duelMirrorLead=0.4,duelMirrorShare=0.45,duelBaseMin=1.5,duelBaseMax=4.5,duelRecordKeep=4,duelTurnStep=25,duelTurnAhead=200,duelTurnMin=0.2,duelGeomWait=10}) do assert(M.K[key]==nil,key); M.K[key]=value end





for key,value in pairs({overlapYieldEnabled=true,overlapYieldThrottle=0.08,overlapYieldKmh=150,overlapYieldShare=0.5,overlapYieldBrakeLead=2.0,overlapYieldMax=3,overlapYieldHoldOff=4,overlapYieldLogPeriod=20}) do assert(M.K[key]==nil,key); M.K[key]=value end





for key,value in pairs({startAbortMax=2,startAbortSalt=1000,startBackHold=15,startBackHoldBare=5}) do assert(M.K[key]==nil,key); M.K[key]=value end


for key,value in pairs({startBackHoldBareMax=9}) do assert(M.K[key]==nil,key); M.K[key]=value end








for key,value in pairs({dangerFolder='danger',rejoinLap1Gap=500,rejoinLap1Speed=5,rejoinSideGap=15,rejoinLap1Wait=25}) do assert(M.K[key]==nil,key); M.K[key]=value end











for key,value in pairs({lastPullEnabled=true,lastPullLat=2.0,lastPullTTC=0.8,lastPullLogPeriod=15,lastPullGap=1.0,exitRearGap=12,exitRearLatMin=0.6,exitRearLatMax=4.5,exitHoldMax=4}) do assert(M.K[key]==nil,key); M.K[key]=value end




for key,value in pairs({rejoinRaceTime=4,rejoinRaceReachMax=450,rejoinRaceWait=15}) do assert(M.K[key]==nil,key); M.K[key]=value end





for key,value in pairs({wakeHoldEnabled=true,wakeHoldGap=20,slingMaxGap=12,wakeHoldLogPeriod=20}) do assert(M.K[key]==nil,key); M.K[key]=value end


M.nextSessionKeys={raceStart=true,startRealism=true,strategyStartVariety=true}
for key in pairs(M.spawnKeys) do M.nextSessionKeys[key]=true end


for _,key in ipairs({'overlayDesk1','overlayDesk2','overlayDesk3','overlayDesk4'}) do assert(M.globalDefaults[key]==nil,key); M.globalDefaults[key]=true end


assert(M.globalDefaults.overlayLayout==nil); M.globalDefaults.overlayLayout=''


assert(M.globalDefaults.overlayParts==nil); M.globalDefaults.overlayParts=''



for key,value in pairs({sprintWaiver=false}) do assert(M.K[key]==nil,key); M.K[key]=value end


for key,value in pairs({signalMinOffset=0.15}) do assert(M.K[key]==nil,key); M.K[key]=value end




for key,value in pairs({duelConcede=true,duelHeavyBrake=0.8,duelConcedeLift=0.6,duelConcedeCaution=1.5,duelConcedeTime=1.5,duelConcedeHold=3}) do assert(M.K[key]==nil,key); M.K[key]=value end



for key,value in pairs({rejoinNoRetire=true,rejoinNoRetireMax=60,flTailSa=30}) do assert(M.K[key]==nil,key); M.K[key]=value end


for key,value in pairs({recoverRetire=true}) do assert(M.K[key]==nil,key); M.K[key]=value end




for key,value in pairs({coverEnabled=true,coverGap=20,coverSaMin=5,coverLatMax=1.2,coverAheadMin=120,coverAheadMax=400,coverTimeMax=6,coverChance=0.35,coverAssert=0.3,coverSeed=7,coverLogGap=20}) do assert(M.K[key]==nil,key); M.K[key]=value end






for key,value in pairs({exitPassEnabled=true,exitPassWindow=2.5,exitPassGap=15,exitPassSa=12,exitPassLatMin=0.3,exitPassHold=3,exitPassRadarTTC=0.6,exitPassLogPeriod=15}) do assert(M.K[key]==nil,key); M.K[key]=value end


for key,value in pairs({cornerGuardEnabled=true,cornerLevelMax=1.03,cornerCautionMin=0.8}) do assert(M.K[key]==nil,key); M.K[key]=value end




for key,value in pairs({blueCornerClear=18,blueCornerCaution=1.4,blueNoAttack=5}) do assert(M.K[key]==nil,key); M.K[key]=value end



for key,value in pairs({mistakePassEnabled=true,mistakePassSa=8,mistakeWheels=2,mistakeSlip=12}) do assert(M.K[key]==nil,key); M.K[key]=value end


for key,value in pairs({dangerKeptAfter=30}) do assert(M.K[key]==nil,key); M.K[key]=value end







M.K.lastPullEnabled=false; M.K.coverSaMin=0; M.K.coverAheadMax=600



M.K.raceSlowPlayer=true; M.K.raceSlowPlayerSa=20



M.K.yellowRamp=true; M.K.yellowRearWatch=80; M.K.yellowRearSa=15; M.K.yellowRearDecel=2.5
M.K.yellowFollowWatch=250; M.K.yellowFollowSa=15; M.K.yellowFollowDecel=6; M.K.yellowRampLogPeriod=10










for key,value in pairs({yieldExitNoDecel=true,yieldExitGap=40,slowLapRelax=true,slowLapBehind=5,slowLapFastKmh=20,slowLapExitTime=2.5,
 slowLapRelaxIn=0.5,slowLapRelaxOut=2,pqExitPass=true,yieldClosingTTC=4,yieldStallCorners=true}) do assert(M.K[key]==nil,key); M.K[key]=value end
M.optionalTimerFields[#M.optionalTimerFields+1]='yieldCornerAt'












for key,value in pairs({wearRaceMult=1.8,wearRaceMaxLoss=0.03,wearRaceMaxGain=0.015,abortSlowTimeRace=4.5,towBoost=0.02,towBoostMin=3,towBoostRange=30,towBoostSpeed=200,pullOutSlackMax=3,towTooEarlyLat=2.5,towTooEarlySa=15,raceSlowAny=true}) do assert(M.K[key]==nil,key); M.K[key]=value end


M.K.companionNames={'SpotterEngineer','SpotterEnginer'}
M.K.sePlanKey='SpotterEngineer.pitplan'; M.K.sePlanKeyOld='SpotterEnginer.pitplan'
M.K.seStrategyKey='SpotterEngineer.strategy'; M.K.seStrategyKeyOld='SpotterEnginer.strategy'








for key,value in pairs({startFiles=true,startFilesMax=25,startFilesMerge=5,startFilesGapBack=15,startFilesGapTime=2,startFilesGapAhead=20,startFilesLineWidth=0.5}) do assert(M.K[key]==nil,key); M.K[key]=value end



for key,value in pairs({coverDiagPeriod=120,towBoostEndAhead=150}) do assert(M.K[key]==nil,key); M.K[key]=value end
M.K.coverGap=25; M.K.coverLatMax=1.6; M.K.coverAheadMin=80; M.K.coverChance=0.5



for key,value in pairs({rejoinNear=true,rejoinNearBehind=40,raceSlowNoUnlap=true}) do assert(M.K[key]==nil,key); M.K[key]=value end



for key,value in pairs({retireBrokenOnly=true,formationWaitSign=true,failureMinLaps=2}) do assert(M.K[key]==nil,key); M.K[key]=value end


assert(M.globalDefaults.windowScale==nil and M.globalDefaults.appSounds==nil); M.globalDefaults.windowScale=1; M.globalDefaults.appSounds=true
assert(M.globalBounds.windowScale==nil); M.globalBounds.windowScale={1,1.5}
for key,value in pairs({windowScaleStep=0.1}) do assert(M.K[key]==nil,key); M.K[key]=value end




for key,value in pairs({yellowPassIncident=true,avoidRejoinEnds=true}) do assert(M.K[key]==nil,key); M.K[key]=value end





assert(M.globalDefaults.mandatoryManual==nil); M.globalDefaults.mandatoryManual=false
function M.distanceDefault(profile,p,g,run)
 run.mandatoryByDistance=profile=='C' and M.on(p,'rules') and g~=nil and g.mandatoryManual~=true
 if run.mandatoryByDistance then run.mandatoryStops=1 end
 return run
end
do
 local applyRules=M.applyRules
 function M.applyRules(category,profiles,g)
  local done=applyRules(category,profiles)
  if done and g then g.mandatoryManual=false end
  return done
 end
end






for key,value in pairs({signProvisional=true,startFilesBrakeKmh=30,startRelatch=true}) do assert(M.K[key]==nil,key); M.K[key]=value end
assert(M.globalDefaults.signProvisional==nil); M.globalDefaults.signProvisional=false




for key,value in pairs({laneLogMax=12,leaderFallbackWarnLaps=2}) do assert(M.K[key]==nil,key); M.K[key]=value end


for key,value in pairs({pitIgnoredLaps=5}) do assert(M.K[key]==nil,key); M.K[key]=value end













for key,value in pairs({pitEntryBefore=250,pitEntryAfter=150,rollPairs=true,rollStagger=0.5,rollPairFrom=1600,
 rollPairLatMin=0.8,rollRowGap=2.5,rollCloseRate=2,rollCatchMax=30,rollCaution=0.5,rollAggression=0.8,rollCompactMax=10,rollCompactOff=14,rollCompactHold=2,rollWaitPct=70,rollWaitMinKmh=50,rollGreenLast=40,formCatchFrom=1600,formCatchPct=30,formWeaveSpeed=4,formWeaveAccel=30,formWeaveTau=0.02,formWeaveFlat=3,gridSteerFreeze=10,gridFreezeKmh=25,gridFreezeTol=0.4,gridColumnEarly=350,burnFrom=1600,burnTo=700,burnSlowKmh=30,burnGap=45,burnSlowMax=7,burnGoMax=4,burnGoGap=12,burnBrake=1,burnBrakeTime=1.2,burnIncidentGrace=2,burnClearBehind=25,burnClearTime=1.5,burnBrakeDrop=45,burnRest=1.5,rollLogPeriod=4,rollLogCars=8,formWeaveShare=0.9,formWeaveBend=0.004,formWeaveLook=1.5,formWeaveProbe=15,formWeaveMeasure=0.2}) do assert(M.K[key]==nil,key); M.K[key]=value end









M.K.formWeaveMax=0.97; M.K.formWeaveEdge=0.3


for key,value in pairs({classGlueGap=15}) do assert(M.K[key]==nil,key); M.K[key]=value end
return M

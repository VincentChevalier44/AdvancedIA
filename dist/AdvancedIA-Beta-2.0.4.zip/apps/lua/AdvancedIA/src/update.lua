



















local M={}
M.repo='VincentChevalier44/AdvancedIA'
M.api='https://api.github.com/repos/'..M.repo..'/releases/latest'
M.page='https://github.com/'..M.repo..'/releases'
M.download='https://github.com/'..M.repo..'/releases/download/'
M.prefix='apps/lua/AdvancedIA/'

M.assetPrefix='AdvancedIA-Beta-'
M.required={'manifest.ini','AdvancedIA.lua','src/update.lua','src/remote.lua'}
M.headers={['User-Agent']='AdvancedIA',['Accept']='application/vnd.github+json'}
M.notesMax=40
M.lineMax=200
M.sizeMax=16*1024*1024
M.eventsMax=32
M.checkGap=60
M.restartWait=10
M.recoverTries=2
M.bootTries=2
M.checkTimeout=45
M.downloadTimeout=180

function M.version(text)
 if type(text)~='string' then return nil end
 local s=text:match('(%d+%.%d+[%.%d]*)') or text:match('(%d+)')
 if not s then return nil end
 local out={}; for n in s:gmatch('%d+') do out[#out+1]=tonumber(n) end
 return out
end
function M.label(text) local v=M.version(text); return v and 'Beta '..table.concat(v,'.') or nil end

function M.newer(a,b)
 local x,y=M.version(a),M.version(b)
 if not x or not y then return false end
 for i=1,math.max(#x,#y) do local p,q=x[i] or 0,y[i] or 0; if p~=q then return p>q end end
 return false
end
local function str(v) return type(v)=='string' and v or nil end
local function starts(s,p) return type(s)=='string' and s:sub(1,#p)==p end

function M.cut(text,n)
 if #text<=n then return text end
 local i=n
 while i>0 do local b=text:byte(i+1); if not b or b<0x80 or b>=0xC0 then break end; i=i-1 end
 return text:sub(1,i)
end

function M.notes(body)
 local out={}
 if type(body)~='string' then return out end
 for line in (body:gsub('\r','')..'\n'):gmatch('([^\n]*)\n') do
  line=line:gsub('^%s*#+%s*',''):gsub('%*%*',''):gsub('`',''):gsub('%s+$','')
  if #line>M.lineMax then line=M.cut(line,M.lineMax-3)..'...' end
  if line~='' or (#out>0 and out[#out]~='') then out[#out+1]=line end
  if #out>=M.notesMax then break end
 end
 while #out>0 and out[#out]=='' do out[#out]=nil end
 return out
end


function M.release(data)
 if type(data)~='table' or data.draft==true or data.prerelease==true then return nil,'format' end
 local tag=str(data.tag_name); local version=M.label(tag)
 if not version then return nil,'format' end
 local number=table.concat(M.version(tag),'.')
 local zipName=M.assetPrefix..number..'.zip'
 local r={version=version,tag=tag,notes=M.notes(data.body),published=str(data.published_at) and data.published_at:sub(1,10) or '',
  page=starts(data.html_url,M.page) and data.html_url or M.page}
 if type(data.assets)=='table' then
  for _,asset in ipairs(data.assets) do
   local name=type(asset)=='table' and str(asset.name); local url=type(asset)=='table' and str(asset.browser_download_url)
   if name and url and starts(url,M.download) then
    if name==zipName then r.zip={name=name,url=url,size=tonumber(asset.size) or 0}
    elseif name==zipName..'.sha256' or name==M.assetPrefix..number..'.sha256' then r.sha={name=name,url=url} end
   end
  end
 end
 if not r.zip or not r.sha then return nil,'format' end
 if r.zip.size<=0 or r.zip.size>M.sizeMax then return nil,'format' end
 return r
end

function M.digest(text,zipName)
 if type(text)~='string' then return nil end
 local hash,name=text:match('^%s*(%x+)%s+%*?([^%s]+)')
 if not hash or #hash~=64 or name~=zipName then return nil end
 return hash:lower()
end


local function safe(name)
 if type(name)~='string' or not starts(name,M.prefix) or name:find('\\',1,true) or name:find(':',1,true) then return false end
 local rest=name:sub(#M.prefix+1)
 if rest:sub(-1)=='/' then rest=rest:sub(1,-2) end
 if rest=='' then return true end
 for segment in (rest..'/'):gmatch('([^/]*)/') do
  if segment=='' or segment=='.' or segment=='..' then return false end


  local base=segment:match('^([^.]*)'):upper()
  if base=='CON' or base=='PRN' or base=='AUX' or base=='NUL' or base:match('^COM%d$') or base:match('^LPT%d$') then return false end
  local last=segment:sub(-1); if last=='.' or last==' ' then return false end
 end
 return true
end


function M.content(entries)
 if type(entries)~='table' or #entries==0 then return false end
 local seen={}
 for _,name in ipairs(entries) do
  if not safe(name) then return false end
  seen[name]=true
 end
 for _,file in ipairs(M.required) do if not seen[M.prefix..file] then return false end end
 return true
end

function M.files(entries)
 local out={}
 for _,name in ipairs(entries) do if name:sub(-1)~='/' and #name>#M.prefix then out[#out+1]=name:sub(#M.prefix+1) end end
 return out
end


function M.requires(entries,read)
 local seen={}
 for _,name in ipairs(entries) do seen[name]=true end
 for _,name in ipairs(entries) do
  if name:sub(-4)=='.lua' then
   local text=read(name)
   if type(text)=='string' then
    for _,pattern in ipairs({"require%(%s*'(src/[%w_/]+)'%s*%)",'require%(%s*"(src/[%w_/]+)"%s*%)'}) do
     for target in text:gmatch(pattern) do if not seen[M.prefix..target..'.lua'] then return false,target end end
    end
   end
  end
 end
 return true
end

function M.manifestVersion(text)
 if type(text)~='string' then return nil end
 return M.label(('\n'..text):match('\n[ \t]*VERSION[ \t]*=[ \t]*([^\r\n]+)'))
end

function M.stopped(frame,player)
 if frame==nil then return false end
 if frame.paused==true or frame.menu==true then return true end
 return player~=nil and player.inPitBox==true and (tonumber(player.kmh) or 99)<1
end

function M.new(installed)
 return {phase='idle',installed=installed,error='',status=0,detail='',release=nil,previous=nil,updated=nil,serial=0,
  after='',events={},gen=0,askedAt=-math.huge,startedAt=0,now=0,restartAt=nil,restartLate=false,brokenFile=nil,warning=nil}
end

local function event(u,level,text)
 local list=u.events
 if #list>=M.eventsMax then table.remove(list,1) end
 list[#list+1]={level,text}
end

function M.take(u,out)
 local list=u.events
 for i=1,#list do out[#out+1]=list[i]; list[i]=nil end
 return out
end

local busy={checking=true,downloading=true,verifying=true,staging=true,saving=true,ready=true,rollbackReady=true,placing=true,restoring=true,restarting=true,broken=true}
function M.busy(u) return busy[u.phase]==true end

M.cancelable={downloading=true,verifying=true,staging=true,ready=true}
local failures={network='echec reseau',rate='GitHub refuse temporairement (limite de requetes)',format='version publiee illisible ou incomplete',
 integrity='paquet different de celui publie',content='contenu du paquet refuse',write='ecriture impossible',
 driving='refusee en conduite (disponible a l arret : emplacement des stands, pause ou menu)'}

local function fail(u,code,status,detail,kept)
 u.phase='failed'; u.error=code; u.status=status or 0; u.detail=detail or ''; u.serial=u.serial+1
 local text='mise a jour: '..failures[code]..((status or 0)>0 and ' (statut '..status..')' or '')..((detail or '')~='' and ' : '..detail or '')
 event(u,code=='driving' and 'INFO' or 'WARN',text..(kept and ', version actuelle conservee' or ''))
end

local function parse(text)
 if type(text)~='string' then return nil end
 local kind,from,to=text:match('^(%a+) ([^\n]-) %-> ([^\n]+)')
 if kind~='update' and kind~='rollback' then return nil end
 return kind,from,to,tonumber(text:match('\ntries (%d+)')) or 0
end
M.parse=parse


function M.parseReport(text)
 if type(text)~='string' then return nil end
 local kind,from,to=text:match('^(%a+) ([^\n]-) %-> ([^\n]+)')
 if kind~='update' and kind~='rollback' and kind~='recovered' then return nil end
 local auto=to:match('^(.-) auto$')
 return kind,from,auto or to,auto~=nil
end

local targets={update='next',rollback='backup'}



local function bootCheck(port,installed)
 local version,count,from=port.boot()
 if not version then return nil end
 if version~=installed then port.bootClear(); return nil end
 if count<M.bootTries then port.bootSet(version,from,count+1); return nil end
 port.bootClear()
 local result={kind='rollback',from=installed,to=from,file=port.markerFile(),auto=true}
 if not from or port.sourceVersion('backup')~=from or not port.sourceComplete('backup') then result.outcome='bootfailed'; return result end
 if not port.mark('rollback '..installed..' -> '..from) then result.outcome='failed'; result.failed='repere'; return result end
 local ok,failed=port.place('backup')
 if not ok then result.outcome='failed'; result.failed=failed; return result end
 port.report('rollback '..installed..' -> '..from..' auto')
 if port.clearMarker() then result.outcome='autorollback'; result.restart=true else result.outcome='failed'; result.failed='repere' end
 return result
end






function M.recover(port)
 local marker=port.marker()
 if not marker then return bootCheck(port,port.installedVersion()) end
 local kind,from,to,tries=parse(marker)
 if not kind then local gone=port.clearMarker(); return {outcome=gone and 'cleared' or 'failed',failed=not gone and 'repere' or nil,text=marker,file=port.markerFile()} end
 local installed=port.installedVersion()
 local result={kind=kind,from=from,to=to,file=port.markerFile()}
 if installed==to then
  port.promote(kind)
  if port.clearMarker() then
   port.report(kind..' '..from..' -> '..to); result.outcome='finished'

   if kind=='update' then port.bootSet(to,from,1) else port.bootClear() end
  else result.outcome='failed'; result.failed='repere' end
  return result
 end
 if installed~=from and installed~=nil then
  local gone=port.clearMarker(); result.outcome=gone and 'cleared' or 'failed'; result.failed=not gone and 'repere' or nil; result.installed=installed; return result
 end
 if tries>=M.recoverTries then
  port.clearMarker(); port.failedNote(kind..' '..from..' -> '..to..'\ninstalled '..tostring(installed)); result.outcome='gaveup'; return result
 end

 if not port.mark(kind..' '..from..' -> '..to..'\ntries '..(tries+1)) then result.outcome='failed'; result.failed='repere'; return result end
 local source=targets[kind]
 if port.sourceVersion(source)==to and port.sourceComplete(source) then
  local ok,failed=port.place(source)
  if ok then
   port.promote(kind)
   if port.clearMarker() then
    port.report(kind..' '..from..' -> '..to); result.outcome='completed'; result.restart=true

    if kind=='update' then port.bootSet(to,from,0) else port.bootClear() end
    return result
   end
   result.outcome='failed'; result.failed='repere'; return result
  end
  result.failed=failed
 end
 if port.sourceVersion('current')==from and port.sourceComplete('current') then
  local ok,failed=port.place('current')
  if ok then
   if port.clearMarker() then port.report('recovered '..from..' -> '..to); result.outcome='restored'; result.restart=true; return result end
   result.outcome='failed'; result.failed='repere'; return result
  end
  result.failed=failed or result.failed
 end
 result.outcome='failed'; return result
end

local recoverTexts={
 finished=function(r) return 'INFO','mise a jour: copie reprise au lancement, '..(r.kind=='update' and 'installation' or 'retour arriere')..' termine ('..r.from..' -> '..r.to..')' end,
 completed=function(r) return 'INFO','mise a jour: copie reprise au lancement, '..(r.kind=='update' and 'installation' or 'retour arriere')..' termine ('..r.from..' -> '..r.to..')' end,
 restored=function(r) return 'WARN','mise a jour: copie interrompue ('..r.from..' -> '..r.to..'), '..r.from..' remise en place au lancement' end,
 autorollback=function(r) return 'WARN','mise a jour: la '..r.from..' n a pas demarre deux fois de suite, '..r.to..' remise en place automatiquement' end,
 bootfailed=function(r) return 'ERROR','mise a jour: la '..r.from..' n a pas demarre deux fois de suite et la version precedente est incomplete : reinstallez l app' end,
 cleared=function(r) return 'WARN','mise a jour: repere d une copie interrompue leve sans rien copier ('..(r.installed and 'version installee '..r.installed or 'repere illisible')..')' end,
 gaveup=function(r) return 'ERROR','mise a jour: reprise abandonnee apres '..M.recoverTries..' essais ('..(r.from or '?')..' -> '..(r.to or '?')..') : reinstallez l app ('..(r.file or '?')..')' end,
 failed=function(r) return 'ERROR','mise a jour: reprise impossible ('..(r.from or '?')..' -> '..(r.to or '?')..(r.failed and ', '..r.failed or '')..') : relancez le jeu ; si le probleme reste, reinstallez l app ('..(r.file or '?')..')' end}
function M.recoverText(r)
 local f=r and recoverTexts[r.outcome]
 if not f then return nil end
 return f(r)
end


function M.start(u,port,recovered)
 local backup=port.sourceVersion('backup')
 u.previous=backup~=u.installed and port.sourceComplete('backup') and backup or nil
 local note=port.failed()
 if note then
  local version=note:match('\ninstalled ([^\n]+)')
  if version==u.installed then u.warning=note:match('^[^\n]*'); event(u,'WARN','mise a jour: une reprise a echoue ('..u.warning..'), l app peut melanger deux versions : reinstallez-la')
  else port.clearFailed() end
 end
 if recovered then
  local level,text=M.recoverText(recovered)
  if text then event(u,level,text) end
  if recovered.outcome=='failed' or recovered.outcome=='gaveup' or recovered.outcome=='bootfailed' then u.phase='broken'; u.brokenFile=recovered.file; u.serial=u.serial+1 end
 end

 if recovered and recovered.restart then


  u.phase='restarting'; u.after=recovered.kind=='rollback' and 'rollback' or 'update'; u.afterVersion=recovered.to; u.restartPending=true; u.serial=u.serial+1
  event(u,'INFO','mise a jour: redemarrage de l app pour charger une version complete')
  return
 end
 local kind,from,to,auto=port.takeReport()
 if kind then
  u.updated={kind=kind,from=from,to=to,auto=auto}; u.serial=u.serial+1
  event(u,'INFO',kind=='update' and 'mise a jour reussie: '..from..' -> '..to or kind=='rollback' and 'retour arriere termine'..(auto and ' (automatique)' or '')..': '..from..' -> '..to
   or 'installation interrompue rattrapee: '..from..' remise en place, '..to..' a refaire')
 end
 M.tidy(u,port)
end



function M.tidy(u,port)
 if M.busy(u) or u.release and u.release.staged then return 0 end
 if not port.ready or type(port.tidy)~='function' or port.marker() or port.boot() then return 0 end
 local n=port.tidy() or 0
 if n>0 then event(u,'INFO',string.format('mise a jour: nettoyage (%d fichiers)',n)) end
 return n
end

local function live(u,gen) return u.gen==gen end

function M.check(u,port,now)
 if M.busy(u) or now-u.askedAt<M.checkGap then return false end
 u.askedAt=now; u.gen=u.gen+1; local gen=u.gen
 u.phase='checking'; u.error=''; u.status=0; u.detail=''
 port.get(M.api,M.headers,function(err,status,body)
  if not live(u,gen) or u.phase~='checking' then return end
  if err or not status then fail(u,'network',0,err); return end
  if status==404 then u.phase='none'; u.serial=u.serial+1; event(u,'INFO','mise a jour: aucune version publiee sur GitHub'); return end
  if status==403 or status==429 then fail(u,'rate',status); return end
  if status~=200 then fail(u,'network',status); return end
  local r=M.release(port.json(body))
  if not r then fail(u,'format'); return end
  u.release=r; u.phase=M.fresh(u) and 'available' or 'current'; u.serial=u.serial+1
  event(u,'INFO',u.phase=='available' and 'mise a jour disponible: '..r.version..' (publiee le '..r.published..', '..r.zip.size..' octets)' or 'mise a jour: '..u.installed..' est la derniere version')
 end)
 return true
end

function M.cancel(u)
 if not M.cancelable[u.phase] then return false end
 u.gen=u.gen+1; u.phase='available'; u.serial=u.serial+1; event(u,'INFO','mise a jour: annulee avant toute copie')
 return true
end



local function place(u,port,kind,to,now)
 u.phase='saving'

 local from=port.installedVersion() or u.installed
 local saved,missing,kept=port.snapshot(targets[kind])
 if not saved then fail(u,'write',0,'sauvegarde : '..tostring(missing),true); return end
 u.phase='placing'
 local mark=kind..' '..from..' -> '..to
 if not port.mark(mark) then fail(u,'write',0,'repere',true); return end
 local ok,failed,stats=port.place(targets[kind])
 if not ok then
  u.phase='restoring'
  local back,failed2=port.place('current')
  if back and port.clearMarker() then fail(u,'write',0,failed,true); return end
  u.phase='broken'; u.brokenFile=port.markerFile(); u.serial=u.serial+1
  event(u,'ERROR','mise a jour: copie de '..tostring(failed)..' impossible, puis remise en place impossible ('..tostring(failed2 or 'repere')..') : relancez le jeu')
  return
 end

 if stats and type(stats.skipped)=='table' and #stats.skipped>0 then event(u,'WARN','mise a jour: '..#stats.skipped..' fichier(s) d appoint garde(s), ouvert(s) par le jeu : '..table.concat(stats.skipped,', ',1,math.min(#stats.skipped,4))) end
 local promoted,why=port.promote(kind)
 if not promoted then event(u,'WARN','mise a jour: version precedente non gardee ('..tostring(why)..'), retour arriere indisponible') end
 if not port.clearMarker() then event(u,'WARN','mise a jour: repere non efface ('..tostring(port.markerFile())..'), termine au lancement suivant') end



 if not port.report(kind..' '..(kind=='update' and u.installed or from)..' -> '..to) then event(u,'WARN','mise a jour: compte rendu non ecrit') end
 if kind=='update' then port.bootSet(to,from,0) else port.bootClear() end
 u.phase='restarting'; u.after=kind; u.afterVersion=to; u.restartAt=now; u.serial=u.serial+1
 event(u,'INFO',string.format('mise a jour: %s%s (%d fichiers compares, %d copies en %.0f ms ; %d fichiers gardes en %.0f ms), commandes des IA rendues a AC et redemarrage de l app',
  to,kind=='update' and ' installee' or ' retablie',stats and stats.compared or 0,stats and stats.copied or 0,stats and stats.ms or 0,kept and kept.saved or 0,kept and kept.ms or 0))
 port.restart()
end


function M.install(u,port,stopped)
 local r=u.release
 if M.busy(u) or not r or not M.fresh(u) then return false end
 if not stopped then fail(u,'driving'); return false end
 u.gen=u.gen+1; local gen=u.gen
 u.error=''; u.detail=''; u.serial=u.serial+1; u.startedAt=u.now
 if r.staged and port.sourceVersion('next')==r.version and port.sourceComplete('next') then
  u.phase='ready'; event(u,'INFO','mise a jour: '..r.version..' deja telechargee et verifiee ; copie a l arret'); return true
 end
 r.staged=false
 u.phase='downloading'
 event(u,'INFO','mise a jour: telechargement de la '..r.version)
 port.get(r.sha.url,nil,function(err,status,text)
  if not live(u,gen) then return end
  if err or status~=200 then fail(u,'network',status~=200 and status or 0,err,true); return end
  local expected=M.digest(text,r.zip.name)
  if not expected then fail(u,'format',0,'fichier d empreinte illisible',true); return end
  port.get(r.zip.url,nil,function(err2,status2,data)
   if not live(u,gen) then return end
   if err2 or status2~=200 or type(data)~='string' then fail(u,'network',status2~=200 and status2 or 0,err2,true); return end
   u.phase='verifying'
   if #data~=r.zip.size then fail(u,'integrity',0,'taille '..#data..' octets au lieu de '..r.zip.size,true); return end
   if port.sha256(data)~=expected then fail(u,'integrity',0,'empreinte SHA-256 differente',true); return end
   local entries=port.entries(data)
   if not M.content(entries) or M.manifestVersion(port.entry(data,M.prefix..'manifest.ini'))~=r.version then fail(u,'content',0,nil,true); return end
   local loads,module=M.requires(entries,function(name) return port.entry(data,name) end)
   if not loads then fail(u,'content',0,'module absent : '..module,true); return end
   u.phase='staging'
   port.stage(data,M.files(entries),function(err3)
    if not live(u,gen) then return end
    if err3 then fail(u,'write',0,'extraction : '..tostring(err3),true); return end
    if port.sourceVersion('next')~=r.version or not port.sourceComplete('next') or not port.sourceHas('next',M.required) then fail(u,'content',0,'paquet extrait incomplet',true); return end
    u.phase='ready'; r.staged=true; u.serial=u.serial+1
    event(u,'INFO','mise a jour: '..r.version..' prete, empreinte et contenu verifies ; copie a l arret')
   end)
  end)
 end)
 return true
end


function M.rollback(u,port,stopped)
 if M.busy(u) or not u.previous then return false end
 if not stopped then fail(u,'driving'); return false end
 if port.sourceVersion('backup')~=u.previous or not port.sourceComplete('backup') then fail(u,'write',0,'version precedente incomplete',true); return false end
 u.phase='rollbackReady'; u.serial=u.serial+1
 event(u,'INFO','mise a jour: retour a la '..u.previous..' demande')
 return true
end


function M.tick(u,port,stopped,now)
 u.now=now
 if u.restartPending then u.restartPending=false; u.restartAt=now; port.restart(); return end
 local phase=u.phase
 if phase=='ready' then
  if stopped and u.release then place(u,port,'update',u.release.version,now)
  else u.gen=u.gen+1; u.phase='available'; u.serial=u.serial+1; event(u,'INFO','mise a jour: copie reportee (pilote reparti), paquet garde : nouveau clic a l arret') end
 elseif phase=='rollbackReady' then
  if stopped and u.previous then place(u,port,'rollback',u.previous,now)
  else u.phase='idle'; u.serial=u.serial+1; event(u,'INFO','mise a jour: retour arriere annule (pilote reparti)') end
 elseif phase=='checking' and now-u.askedAt>M.checkTimeout then
  u.gen=u.gen+1; fail(u,'network',0,'pas de reponse de GitHub en '..M.checkTimeout..' s')
 elseif (phase=='downloading' or phase=='verifying' or phase=='staging') and now-u.startedAt>M.downloadTimeout then
  u.gen=u.gen+1; fail(u,'network',0,'telechargement non termine en '..M.downloadTimeout..' s',true)
 elseif phase=='restarting' and not u.restartLate and u.restartAt and now-u.restartAt>M.restartWait then
  u.restartLate=true; u.serial=u.serial+1; event(u,'WARN','mise a jour: l app n a pas redemarre, relancez la session pour finir')
 end
end



local errorViews={network='errNet',rate='errRate',format='errFormat',integrity='errHash',content='errHash',write='errWrite'}
local reportViews={update='success',rollback='rolledback',recovered='interrupted'}
local busyViews={staging='installing',saving='installing',placing='installing',restoring='installing',rollbackReady='installing'}


local reportPhases={idle=true,current=true,checking=true,none=true}
function M.reported(u) return u.updated~=nil and reportPhases[u.phase]==true end
function M.view(u,stopped)
 local phase=u.phase
 if phase=='broken' then return 'broken' end
 if M.reported(u) then return reportViews[u.updated.kind] end
 if phase=='failed' then
  if u.error=='driving' then
   if not M.fresh(u) then return u.previous and 'driving' or 'unchecked' end
   return stopped and 'available' or 'driving'
  end
  return errorViews[u.error] or 'errNet'
 end
 if phase=='available' then return stopped and 'available' or 'driving' end
 if phase=='restarting' then return u.after=='rollback' and 'rolledback' or 'done' end
 if busyViews[phase] then return busyViews[phase] end
 if phase=='current' then return 'uptodate' end
 if phase=='idle' then return 'unchecked' end
 return phase
end

function M.fresh(u)
 local r=u.release
 if not r then return false end
 if r.newer==nil then r.newer=M.newer(r.version,u.installed) end
 return r.newer
end

function M.offered(u) return M.fresh(u) and (u.phase=='available' or u.phase=='failed' and u.error~='format' and u.error~='rate') end
return M


local U=require('src/util')
local K=require('src/config').K
local M={}
local function clear(c)
 c.stops=0; c.windowStops=0; c.boxed=false; c.boxSince=0; c.visit=0; c.wanted=false; c.redVisit=false; c.pendingCompound=nil; c.pendingUntil=nil; c.wasPit=nil
 c.fuelLap=-1; c.fuelAt=-1; c.lapAt=0; c.pitLap=false; c.perLap=0; c.lapTime=0; c.repairVisit=-1; c.repairTime=0; c.towedAt=nil


 c.passBox=false; c.deferred=false



 c.usedDry={}; c.usedCount=0; c.requestServices=0; c.requestAbandoned=false; c.laneVisit=nil; c.laneStopped=false; c.reboxLogged=false; c.appTowAt=nil

 c.askLap=nil; c.askLaps=0; c.requestIgnored=false
end
function M.new()
 local t={cars={},entrySpline=-1,playerNotice='',playerNoticeUntil=-math.huge,playerNoticeFrom='',playerNoticeTo='',hintFor=-2,hintTyre='',hintOthers={},opened=false,openedAt=-math.huge,justClosed=false,stopAwait=false,wasStarted=false,progress=-1,position=-1,open=-1,close=-1,csp=false,state='off',done=0,total=0,restored={},models={},restoredSession=-1,dirty=false,wetRace=false,waived=false,sprintKm=-1,sprintLap=0,sprintSaid=false,sprintShow=false,sprintEmitted=false,sprintSeen=false,ignoredCount=0}
 for i=1,K.maxCars do local c={identity='',lastStop=0}; clear(c); t.cars[i]=c end
 return t
end
function M.reset(t,now)
 for i=1,K.maxCars do local c=t.cars[i]; clear(c); c.identity=''; c.lastStop=now end
 t.opened=false; t.openedAt=-math.huge; t.justClosed=false; t.state='off'; t.dirty=true; t.wetRace=false; t.waived=false

 t.openedPos=-1; t.heldOpen=false
 t.shortWaived=false; t.effectiveKey=nil; t.callBy=nil; t.leaderFallbackSaid=false
 t.ignoredCount=0

 t.sprint=nil; t.sprintKm=-1; t.sprintLap=0; t.sprintSaid=false

 t.sprintShow=false; t.sprintEmitted=false; t.sprintSeen=false

 t.stopAwait=false; t.wasStarted=false
 t.entrySpline=-1; t.playerNotice=''; t.playerNoticeUntil=-math.huge; t.hintFor=-2

 t.remindLap=nil; t.remindAt=nil; t.hintLap=nil; t.hintAt=nil
end
function M.rebase(t,amount)

 for i=1,K.maxCars do local c=t.cars[i]; c.boxSince=c.boxSince-amount; c.lastStop=c.lastStop-amount; c.lapAt=c.lapAt-amount; if c.pendingUntil then c.pendingUntil=c.pendingUntil-amount end; if c.towedAt then c.towedAt=c.towedAt-amount end; if c.appTowAt then c.appTowAt=c.appTowAt-amount end end
 if t.playerNoticeUntil>-math.huge then t.playerNoticeUntil=t.playerNoticeUntil-amount end
 if t.openedAt>-math.huge then t.openedAt=t.openedAt-amount end
 if t.remindAt then t.remindAt=t.remindAt-amount end; if t.hintAt then t.hintAt=t.hintAt-amount end

 if t.release then for _,r in pairs(t.release) do if r.since>=0 then r.since=r.since-amount end; if (r.readyAt or -1)>=0 then r.readyAt=r.readyAt-amount end end end
end


function M.leaderLaps(frame)
 local laps=frame.leaderLaps or 0
 if laps>0 or frame.started~=true or not frame.cars then return laps end
 local best=0
 for i=1,frame.count or 0 do local c=frame.cars[i]; if c and c.valid and (c.lap or 0)>best then best=c.lap end end
 return best
end

function M.progress(frame)
 if frame.sessionLaps>0 and not frame.timedRace then return M.leaderLaps(frame)/frame.sessionLaps end
 if frame.sessionMinutes>0 then return U.clamp(1-frame.left/(frame.sessionMinutes*60),0,1) end
 return -1
end

function M.refLap(t,frame)
 local list={}
 for i=1,frame.count do local c=t.cars[i]; if c and (c.lapTime or 0)>0 then list[#list+1]=c.lapTime end end
 if #list==0 then return 0 end
 table.sort(list)
 return list[math.floor((#list+1)/2)]
end




function M.effective(opening,closing,frame,refLap)
 if frame.sessionLaps>0 and not frame.timedRace then
  local laps=frame.sessionLaps
  local cap=(laps-K.pitCloseLaps)/laps
  if closing>cap then closing=cap end

  local last=math.min(laps,math.floor(closing*laps)+1)
  while last>=0 and last/laps>closing do last=last-1 end
  if last<1 then return opening,closing,true,nil end
  if last/laps<opening then opening=last/laps end
  local callBy=nil
  local lead=last-K.pitCallLeadLaps
  if lead>=1 and lead/laps>=opening then callBy=lead/laps else callBy=opening end
  return opening,closing,false,callBy
 end
 if frame.sessionMinutes>0 and refLap>0 then
  local duration=frame.sessionMinutes*60
  local lap=refLap/duration
  local cap=1-K.pitCloseLaps*lap
  if closing>cap then closing=cap end
  if closing<=lap then return opening,closing,true,nil end
  if opening>closing-lap then opening=math.max(0,closing-lap) end
  local callBy=closing-K.pitCallLeadLaps*lap
  if callBy<opening then callBy=opening end
  return opening,closing,false,callBy
 end
 return opening,closing,false,nil
end





function M.raceKm(frame)
 if frame.length<=0 then return -1,0 end
 if frame.sessionLaps>0 and not frame.timedRace then return frame.sessionLaps*frame.length/1000,0 end
 if frame.sessionMinutes<=0 then return -1,0 end
 local lap=math.huge
 for i=1,frame.count do
  local a=frame.cars[i]
  if a.valid and not a.safetyCar and (a.lap or 0)>=K.sprintLapsSeen and (a.bestLap or 0)>=K.fuelLapTimeMin and a.bestLap<lap then lap=a.bestLap end
 end
 if lap==math.huge then return -1,0 end


 local laps=(math.floor(frame.sessionMinutes*60/(lap*K.sprintLapShare))+1)+(frame.extraLap==true and 1 or 0)
 return laps*frame.length/1000,lap
end





function M.compound(a,cmd,p,used,usedCount)

 if not cmd.weatherManaged and cmd.weatherRain then return -1 end
 if cmd.weatherManaged and cmd.weatherCompound>=0 and (cmd.weatherRain or cmd.weatherCompound~=a.compoundIndex) then return cmd.weatherCompound end
 if not a.tyresKnown or a.compoundIndex==nil then return -1 end

 if p.pitCompoundChange and a.dryCompounds and not cmd.sprintFree then
  if used and (usedCount or 0)<2 then for index=0,K.maxTyreCompounds-1 do if a.dryCompounds[index] and index~=a.compoundIndex and not used[index] then return index end end end
  for index=0,K.maxTyreCompounds-1 do if a.dryCompounds[index] and index~=a.compoundIndex then return index end end
 end
 return a.compoundIndex
end


function M.repairTime(a)
 local body,suspension,engine=a.damageBody or 0,a.damageSuspension or 0,a.engineLife or K.engineLifeNew
 if body<K.repairBodyMin and suspension<K.repairSuspensionMin and engine>=K.repairEngineMin then return 0 end
 return math.min(K.repairMax,K.repairBase+body*K.repairBodyRate+suspension*K.repairSuspensionRate+(K.engineLifeNew-engine)/K.engineLifeNew*K.repairEngineTime)
end

local function tyreShort(a,index) return index~=nil and (a.tyreNames and a.tyreNames[index] or tostring(index)) or '?' end
local function notice(t,kind,from,to,untilAt,fromIndex,toIndex) t.playerNotice=kind; t.playerNoticeFrom=from; t.playerNoticeTo=to; t.playerNoticeUntil=untilAt; t.playerNoticeFromIndex=fromIndex or -1; t.playerNoticeToIndex=toIndex or -1 end


function M.update(t,frame,commands,p,profile,now,seed,announce,red,dq,closed,busy)
 local active=profile=='C' and (p.mandatoryStops>0 or p.maxStintMin>0 or p.minPitTime>0)
 local progress=M.progress(frame); t.progress=progress



 if not t.leaderFallbackSaid and (frame.leaderLaps or 0)==0 and frame.sessionLaps>0 and not frame.timedRace and M.leaderLaps(frame)>=(K.leaderFallbackWarnLaps or 1) then
  t.leaderFallbackSaid=true
  if t.note then t.note('WARN','tours du leader indisponibles, avancement d apres les voitures',-1) end
 end

 local csp=frame.pitWindowStart>0 and frame.pitWindowEnd>frame.pitWindowStart
 local position,opening,closing
 if csp then position=frame.simTime; opening=frame.pitWindowStart; closing=frame.pitWindowEnd
 else position=progress; opening=p.pitWindowOpenPct/100; closing=p.pitWindowClosePct/100 end


 local short,callBy=false,nil
 if not csp then opening,closing,short,callBy=M.effective(opening,closing,frame,M.refLap(t,frame)) end
 t.csp=csp; t.position=position; t.open=opening; t.close=closing; t.callBy=callBy





 local timed=not (frame.sessionLaps>0 and not frame.timedRace)



 if t.restoredUndecided and frame.session==t.restoredSession then t.sprintSeen=true end

 local byDistance=K.sprintWaiver or p.mandatoryByDistance==true
 if byDistance and t.sprint==nil and active and p.mandatoryStops>0 and not csp then

  if t.restoredSprint~=nil and frame.session==t.restoredSession then
   t.sprint=t.restoredSprint; t.sprintKm=t.restoredSprintKm; t.sprintLap=t.restoredSprintLap; t.sprintSaid=t.restoredSprintSaid
  elseif t.opened then t.sprint=false; t.sprintKm=-1; t.sprintLap=0; t.dirty=true

  elseif not t.sprintSeen and frame.started==true and timed and position>=opening then t.sprint=false; t.sprintKm=-1; t.sprintLap=0; t.dirty=true
  else
   local km,lap=M.raceKm(frame)
   if km>=0 then t.sprint=km<=K.sprintMaxKm; t.sprintKm=km; t.sprintLap=lap; t.dirty=true end



   if km<0 and timed and (frame.leaderLaps or 0)>=K.sprintLapsSeen+1 then t.sprint=false; t.sprintKm=-1; t.sprintLap=0; t.dirty=true end
  end
 end
 t.sprintSeen=true
 local sprint=t.sprint==true and not csp


 local undecided=byDistance and t.sprint==nil and timed and active and p.mandatoryStops>0 and not csp and not t.opened and frame.length>0 and frame.sessionMinutes>0
 if not csp and not short and not sprint and active and p.mandatoryStops>0 and (opening~=p.pitWindowOpenPct/100 or closing~=p.pitWindowClosePct/100) and not undecided then
  local key=string.format('%.3f|%.3f',opening,closing)
  if t.effectiveKey~=key then
   t.effectiveKey=key
   if t.note then t.note('INFO',string.format('fenetre d arret ajustee a la longueur de la course: %.0f a %.0f %% (reglee %.0f a %.0f %%), fermee avant le dernier tour',opening*100,closing*100,p.pitWindowOpenPct,p.pitWindowClosePct),-1) end
  end
 end

 local waived=p.pitCompoundChange and t.wetRace
 if waived and not t.waived and not sprint and active and p.mandatoryStops>0 then
  if t.note then t.note('INFO','arret obligatoire leve: course mouillee',-1) end
  if p.pitMessage and announce then announce('pitWaived') end
 end

 if sprint then waived=true end
 if short and not waived and not t.shortWaived and not undecided and active and p.mandatoryStops>0 then
  if t.note then t.note('INFO','arret obligatoire leve: course trop courte (aucun tour ouvert avant le dernier)',-1) end
  if p.pitMessage and announce then announce('pitShort') end
 end
 t.shortWaived=short and not waived and not undecided
 waived=waived or short
 t.waived=waived

 if t.sprint~=nil and not t.sprintSaid and frame.started==true and not csp then
  t.sprintSaid=true
  t.dirty=true
  if t.note and t.sprint and t.sprintLap>0 then t.note('INFO',string.format('arret obligatoire leve: course sprint estimee a %.1f km (%.0f min, meilleur tour %.1f s, %.0f km au plus)',t.sprintKm,frame.sessionMinutes,t.sprintLap,K.sprintMaxKm),-1) end
  if t.note and t.sprint and t.sprintLap==0 then t.note('INFO',string.format('arret obligatoire leve: course sprint de %.1f km (%d tours, %.0f km au plus)',t.sprintKm,frame.sessionLaps,K.sprintMaxKm),-1) end
  if t.note and not t.sprint and t.sprintKm>=0 then t.note('INFO',string.format('arret obligatoire maintenu: course de %.1f km (plus de %.0f km)',t.sprintKm,K.sprintMaxKm),-1) end
  if t.note and not t.sprint and t.sprintKm<0 then t.note('INFO','arret obligatoire maintenu: distance inconnue avant l ouverture de la fenetre',-1) end

  if t.note and p.mandatoryByDistance==true then t.note('INFO',string.format('arret obligatoire par defaut selon la distance: %s (%.0f km au plus sans arret)',t.sprint and 'desactive' or 'active',K.sprintMaxKm),-1) end

  t.sprintShow=t.sprint==true and K.sprintWaiver==true
 end
 t.sprintEmitted=false
 if t.sprintShow and not busy and not csp then
  t.sprintShow=false
  t.sprintEmitted=t.sprint==true and p.pitMessage==true and announce~=nil
  if t.sprint and p.pitMessage and announce then announce('pitSprint',t.sprintKm,K.sprintMaxKm) end
 end
 local mandatory=active and p.mandatoryStops>0 and position>=0 and not waived
 local before=t.state



 t.state=not mandatory and 'off' or position<opening and 'pending' or undecided and position<=closing and 'pending' or position<=closing and 'open' or 'closed'
 t.justClosed=before=='open' and t.state=='closed'



 if t.state=='open' and not t.opened then
  t.opened=true; t.openedAt=now; t.openedPos=t.heldOpen and position or -1
  local playerDone=t.heldOpen==true and frame.player>0 and t.cars[frame.player].windowStops>=p.mandatoryStops
  if t.note then t.note('INFO',csp and 'fenetre d arret ouverte (CSP)' or string.format('fenetre d arret ouverte: %.0f a %.0f %% de la course',opening*100,closing*100),-1) end
  if p.pitMessage and announce and not playerDone then if csp then announce('pitOpenCsp') else announce('pitOpen',opening*100,closing*100) end end
 end
 t.heldOpen=t.state=='pending' and position>=opening
 t.done=0; t.total=0


 local started=frame.started==true
 if started and not t.wasStarted then for i=1,K.maxCars do t.cars[i].lastStop=now end end
 t.wasStarted=started

 local requested=0



 for i=1,frame.count do local a=frame.cars[i]; if (t.cars[i].wanted and t.cars[i].identity==(a.identity or a.id) or commands[i].stratCalled or commands[i].sanCalled or commands[i].slowCalled) and not a.pit and not t.cars[i].requestIgnored then requested=requested+1 end end
 for i=1,frame.count do
  local a=frame.cars[i]; local c=t.cars[i]; local cmd=commands[i]
  local identity=a.identity or a.id
  if c.identity~=identity then
   clear(c); c.identity=identity; c.lastStop=now; c.boxed=a.inPitBox==true; c.boxSince=now
   c.windowStops=frame.session==t.restoredSession and t.restored[identity] or 0
  end


  if cmd.recover or a.teleport then c.towedAt=now end

  if cmd.recover then c.appTowAt=now end

  if frame.started and not a.pit and a.compoundIndex~=nil and a.dryCompounds and a.dryCompounds[a.compoundIndex] and not c.usedDry[a.compoundIndex] then c.usedDry[a.compoundIndex]=true; c.usedCount=c.usedCount+1 end

  if not a.pit then c.laneVisit=nil; c.laneStopped=false end

  if a.pit and a.inPitBox and (a.kmh or 0)<=K.tyreStopSpeed and c.laneVisit~=nil then c.laneStopped=true end
  local towed=c.towedAt~=nil and now>=c.towedAt and now-c.towedAt<=K.towWindow



  local pass=cmd.penaltyPass==true


  if a.pit and red then c.redVisit=true elseif not a.pit then c.redVisit=false end
  local underRed=red or c.redVisit==true


  if a.pit and c.wasPit==false and t.entrySpline<0 and a.splineValid and not a.safetyCar and (a.kmh or 0)>=K.pitEntryMinKmh then t.entrySpline=a.spline end
  c.wasPit=a.pit==true
  if a.inPitBox and not c.boxed and pass then
   c.boxed=true; c.boxSince=now; c.passBox=true
   if t.note and not a.player then t.note('INFO',string.format('passage de penalite a l emplacement: %s, non compte comme arret',a.name),i) end
  elseif a.inPitBox and not c.boxed then
   c.boxed=true; c.boxSince=now; c.visit=c.visit+1


   local rebox=c.laneVisit~=nil


   local flicker=rebox and not c.laneStopped
   if flicker then c.laneVisit=c.visit end
   if not rebox then c.laneVisit=c.visit end
   if (a.kmh or 0)<=K.tyreStopSpeed then c.laneStopped=true end
   local appTowed=c.appTowAt~=nil and now>=c.appTowAt and now-c.appTowAt<=K.towWindow
   if t.note and active and not a.player then t.note('DEBUG',string.format('arrivee a l emplacement: %s, passage %d, demande d arret AC %s, demande de l app %s, deplacee %s',a.name,c.visit,a.requestingPit and 'oui' or 'non',c.wanted and 'oui' or 'non',towed and 'oui' or 'non'),i) end
   if rebox and not flicker and not c.reboxLogged and t.note and not a.player then c.reboxLogged=true; t.note('INFO',string.format('emplacement de nouveau sans sortie de la voie des stands: %s, aucun nouveau service',a.name),i) end





   local countedNow=false
   if not rebox and not a.safetyCar and (not towed or red or c.wanted and not appTowed) then
    c.stops=c.stops+1







    local early=not underRed and position<opening and p.pitCompoundChange and t.neutralCount==true
    local counts=mandatory and position<=closing and (underRed and p.redFlagWork or not underRed and (position>=opening or early)) and not closed and not (dq and dq[i])
    c.pendingCompound=nil; c.pendingUntil=nil
    if counts and a.player and p.pitCompoundChange and a.compoundIndex~=nil then c.pendingCompound=a.compoundIndex
    elseif counts then c.windowStops=c.windowStops+1; t.dirty=true end
    countedNow=counts
    if counts and early and t.note and active then t.note('INFO',string.format('arret aux stands compte sous neutralisation, avant la fenetre: %s',a.name),i) end
    if t.note and active then t.note('INFO',string.format('arret aux stands%s: %d (dont %d dans la fenetre)%s, %s',a.player and ' du joueur' or '',c.stops,c.windowStops,c.pendingCompound and ', compte au changement de compose (arrivee en '..tyreShort(a,c.pendingCompound)..')' or '',a.name),i) end
   end


   if c.wanted and not rebox and not countedNow and not a.player and p.pitTyres and (not underRed or p.redFlagWork) then c.requestServices=c.requestServices+1 end
  end

 if not a.inPitBox and c.boxed then
  c.boxed=false; if not c.passBox then c.lastStop=now end; c.passBox=false
 end




 if c.pendingCompound~=nil then
  local changed=a.compoundIndex~=nil and a.compoundIndex~=c.pendingCompound
  if changed then
   c.windowStops=c.windowStops+1; t.dirty=true
   local from,to=tyreShort(a,c.pendingCompound),tyreShort(a,a.compoundIndex)
   if t.note and active then t.note('INFO',string.format('arret aux stands du joueur compte: compose change (%s -> %s, %d dans la fenetre)',from,to,c.windowStops),i) end
   notice(t,'counted',from,to,now+K.pitNoticeCounted,c.pendingCompound,a.compoundIndex)
   if announce then announce('pitValidated',c.pendingCompound,a.compoundIndex) end
   c.pendingCompound=nil; c.pendingUntil=nil
  elseif a.pit or a.inPitBox or c.boxed then c.pendingUntil=nil
  elseif not c.pendingUntil then c.pendingUntil=now+K.pitCompoundGrace
  elseif now>=c.pendingUntil then
   local from=tyreShort(a,c.pendingCompound)
   if t.note and active then t.note('INFO',string.format('arret aux stands du joueur non compte: compose inchange (%s -> %s)',from,from),i) end
   notice(t,'same',from,from,now+K.pitNoticeSame,c.pendingCompound,c.pendingCompound)
   if announce then announce('pitNotCounted',c.pendingCompound,c.pendingCompound) end
   c.pendingCompound=nil; c.pendingUntil=nil
  end
 end
  cmd.rulePit=false; cmd.pitHold=false; cmd.pitCompound=-1; cmd.pitVisit=c.visit; cmd.pitRepair=false

  cmd.sprintFree=sprint

  local served=c.laneVisit~=nil and c.laneStopped and a.pit and not a.inPitBox
  cmd.laneServed=served
  local first=c.laneVisit==nil or c.laneVisit==c.visit

  if active and a.valid and a.control and not a.player and not a.finished and not a.safetyCar and not (dq and dq[i]) then
   local want=false
   if mandatory then
    t.total=t.total+1
    if c.windowStops>=p.mandatoryStops then t.done=t.done+1


    elseif t.state=='open' then

     local from=math.max(opening,t.openedPos or -1)
     local span=closing-from

     local at=from+span*K.pitSpread*U.unit(seed,i,K.pitSalt)
     if callBy and at>callBy then at=callBy end
     want=position>=at



     local planAt=cmd.stratPlanAt or -1
     if want and not csp and not c.wanted and planAt>position and planAt<closing-span*K.strategyWindowMargin then want=false end
    end
   end



   if want and c.requestServices>=K.pitRequestServiceMax and not a.inPitBox then
    if not c.requestAbandoned and t.note then t.note('WARN',string.format('arret demande abandonne: %s, servie %d fois sans arret compte',a.name,c.requestServices),i) end
    c.requestAbandoned=true
   end
   if c.requestAbandoned then want=false end
   if p.maxStintMin>0 and not c.boxed and now-c.lastStop>=p.maxStintMin*60 and (progress<0 or progress<K.pitLastStint) then want=true end
   if closed and not a.pit then want=false end


   if served then want=false end

   c.deferred=false
   if want and not a.pit and not c.wanted then if requested<K.pitConcurrent then requested=requested+1 else want=false; c.deferred=true end end
   if want and not c.wanted and t.note then t.note('INFO',string.format('arret demande: %s, %s',mandatory and c.windowStops<p.mandatoryStops and 'obligatoire' or 'fin de relais',a.name),i) end
   c.wanted=want
   if not want and not served then c.requestServices=0 end
   cmd.rulePit=want
   cmd.pitHold=a.inPitBox and p.minPitTime>0 and now-c.boxSince<p.minPitTime
   if a.inPitBox and first and p.pitTyres and (not underRed or p.redFlagWork) then cmd.pitCompound=M.compound(a,cmd,p,c.usedDry,c.usedCount) end
  else c.wanted=false; c.deferred=false end



  if profile=='C' and p.pitRepair and not pass and first and a.inPitBox and a.valid and a.control and not a.player and not a.safetyCar and (not underRed or p.redFlagWork) and not (dq and dq[i]) then
   if c.repairVisit~=c.visit then c.repairVisit=c.visit; c.repairTime=M.repairTime(a) end
   if c.repairTime>0 then cmd.pitRepair=true; if now-c.boxSince<c.repairTime then cmd.pitHold=true end end
  end
 end
end




local function modelKey(c,frame,a)
 if c.keyTrack~=frame.track or c.keyId~=a.id then c.keyTrack=frame.track; c.keyId=a.id; c.key=frame.track..'|'..a.id end
 return c.key
end


local function learn(t,c,a,frame,now,fuel)
 if a.lap~=c.fuelLap then
  if c.fuelLap>=0 and a.lap==c.fuelLap+1 and not c.pitLap and not a.pit then
   if fuel and c.fuelAt>0 then
    local used=c.fuelAt-a.fuel
    if used>0 and used<a.maxFuel*K.fuelLapShare then c.perLap=c.perLap>0 and c.perLap+(used-c.perLap)*K.fuelAlpha or used end
   end
   local lap=now-c.lapAt
   if lap>=K.fuelLapTimeMin then c.lapTime=c.lapTime>0 and c.lapTime+(lap-c.lapTime)*K.fuelAlpha or lap end
   if fuel and c.perLap>0 and c.lapTime>0 then
    local key=modelKey(c,frame,a); local model=t.models[key]
    if not model then model={}; t.models[key]=model end
    model.perLap=c.perLap; model.lapTime=c.lapTime
   end
  end


  c.fuelLap=a.lap; c.fuelAt=fuel and a.fuel or -1; c.lapAt=now; c.pitLap=a.pit==true or t.neutral==true
 elseif a.pit or t.neutral then c.pitLap=true end
end


local function lapsLeft(frame,a,lapTime)
 if frame.sessionLaps>0 and not frame.timedRace then return math.max(0,frame.sessionLaps-a.lap) end
 if frame.sessionMinutes>0 and lapTime>0 then return math.ceil(frame.left/lapTime)+1 end
 return -1
end
M.lapsLeft=lapsLeft


local function stintLaps(p,lapTime,left)
 local laps=left
 if p.maxStintMin>0 and lapTime>0 then laps=math.min(laps,math.max(1,math.floor(p.maxStintMin*60/lapTime))) end
 return laps
end








function M.ignored(t,frame,commands,red)
 for i=1,frame.count do
  local a=frame.cars[i]; local c=t.cars[i]; local cmd=commands[i]
  if not (a.valid and a.control and not a.player and not a.finished) or a.pit or red then c.askLap=nil
  elseif cmd.rulePit and c.identity==(a.identity or a.id) then

   local lap=a.lap or 0
   if c.askLap==nil then c.askLap=lap; c.askLaps=0 elseif lap==c.askLap+1 then c.askLap=lap; c.askLaps=c.askLaps+1 elseif lap~=c.askLap then c.askLap=lap end
   if not c.requestIgnored and c.askLaps>=K.pitIgnoredLaps then
    c.requestIgnored=true; t.ignoredCount=(t.ignoredCount or 0)+1
    c.requestAbandoned=true
    if t.note then t.note('WARN',string.format('arret demande ignore par le jeu: %s, %d tours sans entrer aux stands, demande abandonnee',a.name,K.pitIgnoredLaps),i) end
   end
   if c.requestIgnored then cmd.rulePit=false; cmd.slowCalled=false end
  else c.askLap=nil end
 end
end
function M.fuel(t,frame,commands,p,profile,now,red)
 local mode=p.pitFuel
 local learning=profile=='C' and not frame.online and not frame.replay
 local on=learning and mode~='ac' and frame.fuelRate>0
 for i=1,frame.count do
  local a=frame.cars[i]; local c=t.cars[i]; local cmd=commands[i]
  cmd.fuelTarget=-1; cmd.fuelLaps=0; cmd.fuelSet=-1
  local eligible=learning and a.valid and a.control and not a.player and not a.safetyCar and not a.finished
  local fuel=eligible and (a.fuel or -1)>=0 and (a.maxFuel or -1)>0


  if eligible and not (on and fuel) then learn(t,c,a,frame,now,false) end
  if on and fuel then
   learn(t,c,a,frame,now,true)
   local model=t.models[modelKey(c,frame,a)]
   local perLap=c.perLap>0 and c.perLap or model and model.perLap or a.fuelPerLap or 0
   local lapTime=c.lapTime>0 and c.lapTime or model and model.lapTime or 0
   local left=lapsLeft(frame,a,lapTime)
   if perLap>0 and left>=0 then
    local reserve=perLap*K.fuelReserveLaps
    if not frame.started then
     if mode=='plan' then
      local full=math.min(a.maxFuel,left*perLap*K.fuelMargin+reserve)
      if full>a.fuel+K.fuelStep then cmd.fuelSet=full end
     end
    elseif cmd.rulePit or cmd.weatherManaged and cmd.weatherPit then
     local laps=left
     if mode=='refuel' and not red then laps=stintLaps(p,lapTime,left) end

     if mode=='refuel' and not red and (cmd.stratLaps or 0)>0 then laps=math.min(left,cmd.stratLaps+math.ceil(p.strategyFuelMarginLaps or 0)) end
     local target=U.clamp(laps*perLap*K.fuelMargin+reserve,a.fuel,a.maxFuel)
     cmd.fuelTarget=target; cmd.fuelLaps=math.max(1,math.floor((target-reserve)/perLap))
    end
   end
  end
 end
end

function M.serialize(t,session)
 local rows={tostring(session)}
 for i=1,K.maxCars do local c=t.cars[i]; if c.identity~='' and c.windowStops>0 and c.identity:match('^[%w_%-]+$') then rows[#rows+1]=c.identity..','..c.windowStops end end

 if t.sprint~=nil then rows[#rows+1]=string.format('*sprint,%d,%.3f,%.3f,%d',t.sprint and 1 or 0,t.sprintKm,t.sprintLap,t.sprintSaid and 1 or 0) end

 if t.sprint==nil then rows[#rows+1]='*sprint,u' end
 return table.concat(rows,'\n')
end

function M.forget(t) t.restored={}; t.restoredUndecided=false; t.restoredSession=-1; t.restoredSprint=nil end
function M.restore(t,text,session)
 if type(text)~='string' or #text>K.maxZoneBytes or tonumber(text:match('^(%d+)'))~=session then return end
 t.restoredSession=session

 for identity,stops in text:gmatch('\n([%w_%-]+),(%d+)') do t.restored[identity]=math.min(1,tonumber(stops)) end

 local lifted,km,lap,said=text:match('\n%*sprint,([01]),(%-?[%d%.]+),([%d%.]+),([01])')
 t.restoredSprint=nil
 if lifted then t.restoredSprint=lifted=='1'; t.restoredSprintKm=tonumber(km) or -1; t.restoredSprintLap=tonumber(lap) or 0; t.restoredSprintSaid=said=='1' end


 t.restoredUndecided=text:find('\n*sprint,u',1,true)~=nil
end


function M.confirmSprint(t,m)
 if not t.sprintEmitted then return end
 t.sprintEmitted=false
 if not (m.messageKind=='pitSprint' and m.messageFrame==m.frameId) then t.sprintShow=true end
end




function M.releaseGuard(t,frame,cmds,now,log)
 if frame.length<=0 then return end
 local rel=t.release; if not rel then rel={}; t.release=rel end
 for i=1,frame.count do
  local a=frame.cars[i]; local cmd=cmds[i]
  local r=rel[i]; if not r then r={since=-1,readyAt=-1,logged=false}; rel[i]=r end
  if not (a.valid and a.inPitBox) then r.since=-1; r.readyAt=-1; r.logged=false
  elseif a.control and not a.player and not a.safetyCar and a.splineValid and not cmd.pitHold then



   if r.readyAt<0 and a.kmh>K.boxReleaseStill then r.readyAt=now end
   if r.readyAt>=0 and a.kmh<=K.boxReleaseCatch then
   local who=0
   for j=1,frame.count do
    local b=frame.cars[j]
    if j~=i and b.valid and b.pit and not b.inPitBox and b.splineValid and b.kmh>=K.boxLaneKmh then
     local d=U.spline(a.spline-b.spline)*frame.length
     if d>0 and d<=K.boxReleaseGap then who=j; break end
    end
   end
   if who>0 then
    if r.since<0 then r.since=now end
    if now-r.since<K.boxReleaseMax then
     cmd.pitHold=true
     if not r.logged then r.logged=true; U.log(log,now,'INFO',string.format('voie des stands: %s attend que %s passe avant de quitter son emplacement',a.name,frame.cars[who].name),i) end
    end
   else r.since=-1 -- Relecture 1.62 (S4) : personne dans la voie : la retenue suivante repart de zéro
   end
   end
  end
 end
end
return M










local C=require('src/config')
local K=C.K
local abs=math.abs
local M={}


function M.nose(a,b,long) return long+(b.length-a.length)*0.5 end

function M.behind(a,b,long) return M.nose(a,b,long)>K.cornerNoseMargin end


function M.cornerContext(a,p,ownBrake) return a.corner<p.cornerMin or (ownBrake or 0)>=K.passBrakeMax end


function M.commit(e,i,j,side,now)
 local s=e.states[i]
 if s.committed~=j then s.committed=j; s.commitAt=now end
 s.commitSide=side or 0
end

function M.release(e,i)
 local s=e.states[i]; local j=s.committed or 0
 if j>0 then local t=e.states[j]; if t and t.heldBy==i then t.heldBy=0; t.heldUntil=0 end end
 s.committed=0; s.commitSide=0
end
function M.committed(s,j) return (s.committed or 0)>0 and (j==nil or s.committed==j) end

function M.hold(e,j,i,untilTime) local t=e.states[j]; t.heldBy=i; t.heldUntil=untilTime end

function M.held(s,now) return (s.heldBy or 0)>0 and now<(s.heldUntil or 0) and s.heldBy or 0 end










local function grade(v) if v>=K.duelTolerance then return 'oui' elseif v<=-K.duelTolerance then return 'non' end return 'incertain' end
function M.duel(a,b,long,lat,turn,out)
 local nose=M.nose(a,b,long)
 out.mode='nez'; out.inside=0
 if nose>K.cornerNoseMargin then out.a='non'; out.b='oui' elseif nose<-K.cornerNoseMargin then out.a='oui'; out.b='non' else out.a='incertain'; out.b='incertain' end
 if not K.duelAxles or not a.axleKnown or not b.axleKnown then return out end
 if turn==0 then
  local ys=(a.yawRate or 0)+(b.yawRate or 0)
  if abs(ys)<K.duelYawMin then return out end
  turn=ys>0 and -1 or 1
 end
 local tx,tz=a.lx+b.lx,a.lz+b.lz; local n=math.sqrt(tx*tx+tz*tz)
 if n<1 then return out end
 local d=((b.x-a.x)*tx+(b.z-a.z)*tz)/n
 local aF,bF=a.axleFront,d+b.axleFront
 if lat*turn>0 then out.inside=2; out.b=grade(bF-(a.mirror)); out.a=grade(aF-bF)
 else out.inside=1; out.a=grade(aF-(d+b.mirror)); out.b=grade(bF-aF) end
 if a.offtrack then out.a='non' end
 if b.offtrack then out.b='non' end
 out.mode='axes'
 return out
end

function M.yields(out) return out.a=='non' and out.b=='oui' end






function M.gives(out,a,b,long)
 if M.nose(a,b,long)>K.cornerNoseMargin then return true,'nez' end
 if out.mode=='axes' and out.inside==1 and M.yields(out) then return true,'interieur' end
 return false,nil
end


local function slot(s,j,id)
 local r1,r2=s.duelRec1,s.duelRec2
 if not r1 then r1={other=0,id='',at=-math.huge,mine='',theirs='',mode=''}; r2={other=0,id='',at=-math.huge,mine='',theirs='',mode=''}; s.duelRec1=r1; s.duelRec2=r2 end
 if r1.other==j and r1.id==id then return r1 end
 if r2.other==j and r2.id==id then return r2 end
 return r1.at<=r2.at and r1 or r2
end
function M.record(s,j,id,out,now)
 local r=slot(s,j,id or '')
 r.other=j; r.id=id or ''; r.at=now; r.mine=out.a; r.theirs=out.b; r.mode=out.mode
end

local function find(s,j,id,now)
 if not s then return nil end
 for k=1,2 do
  local r=k==1 and s.duelRec1 or s.duelRec2
  if r and r.other==j and r.id==id and now-r.at<=K.duelRecordKeep and now>=r.at then return r end
 end
 return nil
end
function M.recorded(e,frame,i,j,now)
 local idI,idJ=frame.cars[i].identity or frame.cars[i].id or '',frame.cars[j].identity or frame.cars[j].id or ''
 local ri,rj=find(e.states[i],j,idJ,now),find(e.states[j],i,idI,now)

 if ri and (not rj or ri.at>=rj.at) then return ri.mine,ri.theirs,ri.mode end
 if rj then return rj.theirs,rj.mine,rj.mode end
 return nil
end

function M.rebase(s,amount)
 if s.commitAt then s.commitAt=s.commitAt-amount end

 if s.commitSeen then s.commitSeen=s.commitSeen-amount end
 if s.heldUntil and s.heldUntil>0 then s.heldUntil=s.heldUntil-amount end
 if s.duelRec1 then s.duelRec1.at=s.duelRec1.at-amount; s.duelRec2.at=s.duelRec2.at-amount end
end
return M

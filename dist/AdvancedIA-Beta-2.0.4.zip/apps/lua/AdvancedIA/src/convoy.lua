






















local U=require('src/util')
local K=require('src/config').K
local Grid=require('src/grid')
local M={}





local CK={gap=6,gridGap=1.5,decel=4,react=0.25,range=300,closeRate=0.25,brakeMargin=3,brakeScale=20,brakeMin=0.15,sideLat=0.8,gridFree=60,panic=1,gapMin=2,gapTime=0.5,
 stopKmh=3,nearGap=2,auditKmh=30}
M.CK=CK
function M.new() return {active=false,lap=false,near=0,nearOn={},closest=math.huge} end



function M.guard(v,gap)
 gap=gap or CK.gap
 return math.min(gap,CK.gapMin+(v or 0)*CK.gapTime)
end

function M.cap(vp,bumper,v,gap)
 gap=M.guard(v,gap)
 local room=bumper-gap-v*CK.react
 if room>0 then return math.sqrt(vp*vp+2*CK.decel*room) end
 return math.max(0,vp-CK.closeRate*math.max(0,gap-bumper))
end
local function counted(inc,b,j)
 if not (b.valid and not b.pit and b.splineValid and not b.offtrack) then return false end
 local c=inc.cars and inc.cars[j]
 return not (c and (c.incident or c.holding or c.parked or c.abortHold))
end

function M.ahead(e,frame,i,grid)
 local a=frame.cars[i]; local inc=e.incidents; local g=e.grid
 local own=grid and g and (g.slotOf[i] or 0)>0 and Grid.gap(g,frame,i) or math.huge
 local best,bestLong,tight=nil,CK.range,false
 for j=1,frame.count do
  local b=frame.cars[j]
  if j~=i and counted(inc,b,j) then
   local long=U.spline(b.spline-a.spline)*frame.length
   if long>0 and long<bestLong then
    local ok=true; local corridor=grid and (own<=CK.gridFree or g and g.held[j]) or false

    if corridor then
     local dx,dz=b.x-a.x,b.z-a.z
     ok=math.abs(dx*(-a.lz)+dz*a.lx)<((a.width or K.width)+(b.width or K.width))*0.5+CK.sideLat
    end
    if ok then best=j; bestLong=long; tight=corridor end
   end
  end
 end
 return best,bestLong,tight
end
local function report(t,e,now)
 if not t.lap then return end
 t.lap=false
 U.log(e.log,now,'INFO',string.format('tour de formation: file stricte, %d rapprochement(s) a moins de %d m de la voiture de devant, plus petit ecart %.1f m',t.near,CK.nearGap,t.closest<math.huge and t.closest or 0),-1)
end
function M.step(e,frame,now)
 local t=e.convoy; if not t then t=M.new(); e.convoy=t end
 local inc=e.incidents; local g=e.grid
 local grid=inc.standing=='grid' or inc.standing=='lights'
 local lap=inc.formation==true and not (inc.rollCall==true and K.rollPairs)
 local on=e.profile=='C' and not frame.online and not frame.replay and (lap or grid) and (frame.length or 0)>0
 if lap and not t.lap then t.lap=true; t.near=0; t.closest=math.huge; for i=1,K.maxCars do t.nearOn[i]=false end
 elseif not lap and t.lap then report(t,e,now) end
 t.active=on
 if not on then return end
 for i=1,frame.count do
  local a=frame.cars[i]; local c=inc.cars and inc.cars[i]
  if a.valid and a.control and not a.player and not a.pit and not a.finished and not a.safetyCar and a.splineValid and not a.offtrack
   and not (grid and g and g.held[i]) and not (c and (c.incident or c.holding)) then
   local j,long,tight=M.ahead(e,frame,i,grid)
   if j then
    local b=frame.cars[j]
    local bumper=long-((a.length or K.length)+(b.length or K.length))*0.5
    local vp=b.speed or 0
    local kmh=M.cap(vp,bumper,a.speed or 0,tight and CK.gridGap or CK.gap)*3.6
    local cmd=e.commands[i]
    cmd.speedLimit=math.min(cmd.speedLimit or K.unlimitedSpeed,math.max(kmh,K.gridCrawlKmh))
    local closing=(a.speed or 0)-vp
    if kmh<CK.stopKmh then cmd.brake=math.max(cmd.brake or 0,K.brakeMax)
    elseif a.kmh>kmh+CK.brakeMargin and closing>0 and bumper-M.guard(a.speed or 0,tight and CK.gridGap or CK.gap)<closing*CK.panic then
     cmd.brake=math.max(cmd.brake or 0,U.clamp((a.kmh-kmh)/CK.brakeScale,CK.brakeMin,K.brakeMax))
    end

    if lap and not grid and a.kmh>CK.auditKmh and not b.player then
     if bumper<t.closest then t.closest=bumper end
     if bumper<CK.nearGap then if not t.nearOn[i] then t.nearOn[i]=true; t.near=t.near+1 end else t.nearOn[i]=false end
    end
   end
  end
 end
end
return M

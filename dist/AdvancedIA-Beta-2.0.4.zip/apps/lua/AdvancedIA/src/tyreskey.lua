










local C=require('src/config')
local K=C.K
local M={}
local TK={period=0.5,refresh=5,bytes=160,nameChars=8}
M.K=TK
M.key='AdvancedIA.tyres'
local EMPTY={}

function M.new() return {at=-math.huge,writtenAt=-math.huge,body=nil} end


function M.clean(name)
 return (tostring(name or ''):sub(1,TK.nameChars):gsub('[;=,]','_'))
end




local function raceSession(frame) return frame~=nil and C.autoProfile(frame)=='C' end
M.raceSession=raceSession

function M.rule(e,frame)
 local p=e.run or EMPTY
 local pits=e.pits or EMPTY
 return e.profile=='C' and raceSession(frame) and p.pitCompoundChange==true and (p.mandatoryStops or 0)>0 and pits.waived~=true
end


function M.body(e,frame)
 local slot=frame.player or 0
 local rule=M.rule(e,frame)
 local names={}
 if e.profile=='C' and raceSession(frame) and slot>0 then
  local own=((e.pits or EMPTY).cars or EMPTY)[slot] or EMPTY
  local a=(frame.cars or EMPTY)[slot] or EMPTY
  local used=own.usedDry or EMPTY
  local tyreNames=a.tyreNames or EMPTY
  for index=0,K.maxTyreCompounds-1 do
   if used[index] then local n=M.clean(tyreNames[index] or tostring(index)); if n~='' then names[#names+1]=n end end
  end
 end
 local head='v=1;rule='..(rule and '1' or '0')..';used='

 local room=TK.bytes-#head-#';stamp=' - 12
 local list=''
 for _,n in ipairs(names) do
  local cand=list=='' and n or list..','..n
  if #cand>room then break end
  list=cand
 end
 return head..(list=='' and '-' or list)
end

function M.text(body,now) return body..';stamp='..string.format('%.1f',now) end


function M.step(s,e,frame,now)
 if now<s.at+TK.period and now>=s.at then return nil end
 s.at=now
 local body=M.body(e,frame)
 if body==s.body and now<s.writtenAt+TK.refresh and now>=s.writtenAt then return nil end
 s.body=body; s.writtenAt=now
 return M.text(body,now)
end


function M.closedText(now) return M.text('v=1;rule=0;used=-',now or 0) end
return M

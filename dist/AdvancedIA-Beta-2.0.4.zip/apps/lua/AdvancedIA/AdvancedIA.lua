




local okUpdate,Update=pcall(require,'src/update')
local okRemote,Remote=pcall(require,'src/remote')
local onRelease
local port

local portError
if okUpdate and okRemote and type(Update)=='table' and type(Remote)=='table' then
 local ok,made=pcall(Remote.new,function() if onRelease then onRelease() end end)
 if ok and type(made)=='table' then port=made elseif not ok then portError=made end
end
if not port then

 local function none() end
 local unread=(okUpdate and okRemote and (portError~=nil and 'port: '..tostring(portError) or 'port') or tostring(not okUpdate and Update or Remote)):sub(1,160)
 port={ready=false,work='',restart=none,log=none,bootOk=none,unreadable=unread}
 if not okUpdate or type(Update)~='table' then

  Update=setmetatable({new=function(version) return {phase='idle',installed=version,events={},serial=0,askedAt=0} end,
   view=function() return 'unchecked' end,take=function(_,out) return out end,page=''},{__index=function() return none end})


  local loaded=_G.package and _G.package.loaded
  if loaded then loaded['src/update']=Update end
 end
end
local recovered
do
 local ok,result=pcall(function() return port.ready and Update.recover(port) or nil end)

 if ok then recovered=result else recovered={outcome='failed',failed=tostring(result):sub(1,120),file=port.work} end
end

if recovered and port.ready then
 local okText,level,text=pcall(Update.recoverText,recovered)
 if okText and text then pcall(port.log,level..' '..text) end
end


if recovered and recovered.restart then
 local asked=false
 local function restartOnly() if not asked then asked=true; pcall(port.restart) end end
 function script.update() restartOnly() end
 function script.HUMANAI__UPDATE() restartOnly() end
 function script.HUMANAI__MAIN() end
 function script.HUMANAI__MENU() end
 function script.HUMANAI__HUD() end
 return
end


local oldTidied=false
do
 local okOld,Old=pcall(require,'src/oldinstall')
 local okApplier,Applier0=pcall(require,'src/applier')
 local okConfig,Config0=pcall(require,'src/config')
 if okOld and okApplier and Applier0.companionInstalled(Old.folder) then
  Old.run(script,Applier0,okConfig and Config0.release or '')
  return
 end


 if okOld and okApplier and type(Applier0.oldWorkLeftover)=='function' then local okTidy,done=pcall(Applier0.oldWorkLeftover,Old.folder,Old.oldWork); oldTidied=okTidy and done==true end
end
local Snapshot=require('src/snapshot')
local Applier=require('src/applier')
local Engine=require('src/engine')
local Pacemap=require('src/pacemap')
local Panel=require('src/panel')
local Director=require('src/director')
local Caps=require('src/caps')
local Calibration=require('src/calibration')
local Zones=require('src/zones')
local Dangerfile=require('src/dangerfile')
local UI=require('src/ui')
local U=require('src/util')
local Config=require('src/config')
local Lang=require('src/lang')
local Pits=require('src/pits')
local Cooldown=require('src/cooldown')
local Penalties=require('src/penalties')
local Strategy=require('src/strategy')
local Sanctions=require('src/sanctions')
local Journal=require('src/journal')
local Locale=require('src/locale')
local Lights=require('src/lights')
local Cspgui=require('src/cspgui')
local Bridge=require('src/bridge')
local SessionKey=require('src/sessionkey')
local TyresKey=require('src/tyreskey')
local K=Config.K



local jitlib=rawget(_G,'jit')
local jitTuned=type(jitlib)=='table' and type(jitlib.opt)=='table' and type(jitlib.opt.start)=='function' and pcall(jitlib.opt.start,'maxtrace=8000','maxmcode=16384')==true





local jitWide=jitTuned and pcall(jitlib.opt.start,'maxside=400','loopunroll=30','maxrecord=20000','maxirconst=2000','maxsnap=2000')==true
local previous=rawget(_G,'HUMANAI')
if previous and type(previous.release)=='function' then pcall(previous.release) end
local host=Applier.new()
local globals,profiles=Applier.openStore(host)

Locale.set(globals.language)
local engine=Engine.new(globals,profiles)


engine.batchCars=jitTuned
local frame=Snapshot.new()
local calibration=Calibration.new()
local initialized=false
local released=false
local loadedTrack=''
local dangerTrack=nil -- Correctif 1.63 : circuit dont les zones dangereuses gardées sont chargées

local function refusedAside(folder,key,what)
 local name=Applier.trackFileSetAside(folder,key)
 U.log(engine.log,engine.time,'WARN',name and string.format('%s: fichier refuse mis de cote (%s)',what,name) or string.format('%s: fichier refuse non deplace',what),-1)
end

local nativeFlag=nil
local nativeFlagNames={[0]='aucun',[1]='depart',[2]='jaune',[3]='glissant',[5]='noir',[8]='penalite',[12]='bleu',[13]='damier',[14]='dernier tour'}
local lastCheckpoint=0
local shownMessage=0




local silentKinds={scOut=true,scLeading=true,restartPlace=true,restartRetake=true,rollStart=true}
local function carName(value)
 local k=math.floor(tonumber(value) or -1)+1
 return frame and k>=1 and k<=frame.count and frame.cars[k].name or ''
end
local function announce()
 local t=engine.incidents
 if t.messageId==shownMessage then return end
 shownMessage=t.messageId
 local m=Lang.messages[t.messageKind]
 if m and silentKinds[t.messageKind] then
  local kind=t.messageKind; local text
  if kind=='scOut' then local who=carName(t.messageValue); text=who~='' and string.format(m[2],who) or Lang.messages.scOutAlone[2]
  elseif kind=='scLeading' or kind=='restartRetake' then text=string.format(m[2],carName(t.messageValue))
  elseif kind=='rollStart' then local who=carName(t.messageExtra); text=who~='' and string.format(m[2],t.messageValue,who) or string.format(Lang.messages.rollStartLead[2],t.messageValue)
  else local who=carName(t.messageExtra); text=who~='' and string.format(m[2],t.messageValue,who) or string.format(Lang.messages.restartPlaceSc[2],t.messageValue) end
  engine.ownTitle=m[1]; engine.ownText=text; engine.ownAi=false; return
 end


 local quiet=m and Panel.pitAnnounce(t,t.messageKind)
 if quiet then engine.ownTitle=m[1]; engine.ownText=quiet; engine.ownAi=false; return end
 if m then
  local text=t.messageText~='' and string.format(m[2],t.messageText) or string.format(m[2],t.messageValue,t.messageExtra)

  engine.ownTitle=m[1]; engine.ownText=text

  engine.ownAi=t.messageKind=='aiSanction' or t.messageKind=='aiBlackFlag'
  Applier.message(m[1],text)
 end
end
local function dirty()
 Applier.dirty(host,engine.time)
 if host.menuVisible then Applier.save(host,globals,profiles,engine.time,frame.replay,true) end
end

local messageListener,messageBlock=nil,nil
local messages
local panel=UI.new(engine,host,calibration,dirty)
messageListener=Applier.listenMessages(function(title,description,kind,time) if not released then pcall(Engine.message,engine,title,description,kind,time) end end)
host.note=engine.note



local cspPort=Applier.cspPort()
local csp=Cspgui.new()
Cspgui.start(csp,cspPort)
host.cspgui=csp; host.cspFrozen=function(key) return Cspgui.frozen(csp,key) end
local cspClock=0
local cspWant,cspEvents={},{}
local function cspLog()
 Cspgui.take(csp,cspEvents)
 for i=1,#cspEvents do local ev=cspEvents[i]; U.log(engine.log,engine.time or 0,ev[1],ev[2],-1); cspEvents[i]=nil end
end

local cspWatch=Applier.watchGui(function()
 if released then return end
 pcall(Cspgui.reloaded,csp,cspPort,cspClock); Applier.readFlagsHidden(host); cspLog()
end)
cspLog()


local bootWatched=false
if port.ready and type(port.boot)=='function' then local okBoot,version=pcall(port.boot); bootWatched=okBoot and version~=nil end
local function cspStep(dt)
 if U.finite(dt) and dt>0 then cspClock=cspClock+math.min(dt,1) end

 Cspgui.step(csp,cspPort,Cspgui.want(globals,engine.p,engine.panic,cspWant),cspClock)

 engine.cspHidingFlags=Cspgui.applied(csp,'HIDE_RACE_FLAGS')
 cspLog()
end

do local user,system,writable=Applier.floodRead(); Engine.floodInit(engine,user,system,writable); engine.floodWrite=Applier.floodWrite end

engine.pitSpinners=Applier.pitSpinners
if Applier.floodLeftover() then U.log(engine.log,0,'INFO','nettoyage: new_behaviour.ini.bak efface (reste d une version d avant la Beta 1.38)',-1) end
if oldTidied then U.log(engine.log,0,'INFO','nettoyage: cfg/extension/state/ACAdvancedIA-update efface (copie laissee par la mise a jour de l ancienne version ACAdvancedIA, desinstallee)',-1) end
host.oldSettings=Applier.oldSettings()
if host.oldSettings then U.log(engine.log,0,'WARN','reglages d ACAdvancedIA non repris (state/lua/app/ACAdvancedIA.ini present, AdvancedIA.ini absent) : voir A verifier',-1) end
if host.storageErrors>0 then U.log(engine.log,0,'WARN','invalid_storage:'..host.storageErrors,-1) end
U.log(engine.log,0,'INFO',jitTuned and 'compilateur JIT: cache agrandi (8000 traces, 16 Mo), voitures pilotees en un seul appel protege' or 'compilateur JIT: options indisponibles, voitures pilotees une par une',-1)
if jitTuned then U.log(engine.log,0,'INFO',jitWide and 'compilateur JIT: limites de trace relevees' or 'compilateur JIT: limites de trace par defaut (options refusees)',-1) end
if host.upgraded and #host.upgraded>0 then U.log(engine.log,0,'INFO','profils mis a jour vers les prereglages '..Config.release..': '..table.concat(host.upgraded,', '),-1) end
if host.signsRestored then U.log(engine.log,0,'INFO','sens lateral retabli: -1 / -1 (convention AC, mesure sur cette installation jusqu a la Beta 1.8 ; la mesure le confirmera)',-1) end
if host.firstInstall then U.log(engine.log,0,'INFO','premiere installation: prereglages recommandes et regles de base (essais, qualifications, course)',-1) end
local journal=Journal.new()






local prof={sum={0,0,0,0,0,0,0,0,0},cur={0,0,0,0,0,0,0,0},frames=0,at=nil,slowLogs=0,slowAt=-math.huge}


Snapshot.clock=function() return Applier.clock(host) end
local function mark(i)
 local at=prof.at; if not at then return end
 local now=Applier.clock(host); if not now then prof.at=nil; return end
 prof.cur[i]=prof.cur[i]+(now-at); prof.at=now
end
local function profLine()
 local s,n=prof.sum,math.max(1,prof.frames)
 local line=string.format('cout par poste (moyenne ms par image): lecture %.3f, moteur %.3f, fichiers %.3f, commandes %.3f, mise a jour %.3f, options CSP %.3f, pont %.3f, interface %.3f',
  s[1]*1000/n,s[2]*1000/n,s[3]*1000/n,s[4]*1000/n,s[5]*1000/n,s[6]*1000/n,s[7]*1000/n,(s[8]+s[9])*1000/n)
 local r=Snapshot.cost
 local detail=string.format('cout detaille (moyenne ms par image): lecture session %.3f, voitures %.3f, metadonnees %.3f, gommes %.3f, interface fenetre %.3f, overlay %.3f',
  r[1]*1000/n,r[2]*1000/n,r[3]*1000/n,r[4]*1000/n,s[8]*1000/n,s[9]*1000/n)
 for i=1,9 do s[i]=0 end; for i=1,4 do r[i]=0 end; prof.frames=0
 return line,detail
end
local function writeJournal(force)
 if not globals.journal then return end
 if not host.journalTried then
  host.journalTried=true
  if Applier.journalOpen(host) then Applier.journalWrite(host,'=== AdvancedIA '..Config.release..' : lancement '..Applier.clockText()..' ===\n') end
 end
 if not host.journalPath or not force and engine.time<journal.flushAt then return end
 journal.flushAt=engine.time+K.journalPeriod

 if engine.time>=journal.summaryAt or force and released and engine.time>journal.summaryAt-K.journalSummary+1 then journal.summaryAt=engine.time+K.journalSummary; U.log(engine.log,engine.time,'INFO',Journal.summary(engine),-1); if prof.frames>0 then local line,detail=profLine(); U.log(engine.log,engine.time,'INFO',line,-1); U.log(engine.log,engine.time,'INFO',detail,-1) end end
 Journal.collect(journal,engine.log,Applier.clockText())
 Applier.journalWrite(host,Journal.take(journal))
end

local function writeReport(lines)
 if not lines then return end
 local ok,info=Applier.reportWrite(host,lines)
 if ok then U.log(engine.log,engine.time,'INFO',string.format('rapport de course ecrit: %s (%d voitures)',info,math.max(0,#lines-2)),-1)
 else U.log(engine.log,engine.time,'WARN',string.format('rapport de course: ecriture impossible (%s)',info),-1) end
end
local function cancelProbe() if host.allowed then Caps.cancelProbe(host.caps,frame) end end


local cooling=Cooldown.new()
local function coolNote(level,text,index) U.log(engine.log,engine.time,level,text,index) end
local function coolStep(dt,allowed)
 local race=allowed and engine.profile=='C' and globals.enabled==true
 Cooldown.step(cooling,frame,engine.states,engine.delta and engine.delta.bins,race,dt,coolNote,engine.runtimeG)
 Applier.cooldown(host,frame,cooling,engine.runtimeG,engine.time)
end
local function syncRestored()
 for i=1,frame.count do
  local state=host.cars[i]
  if state.justRestored then
   Director.reset(engine.states[i],engine.time,false,true); engine.commands[i].active=false; engine.commands[i].offset=0
   state.justRestored=false
  end
 end
end

local function anyOwned()
 for i=1,frame.count do if host.cars[i].owned then return true end end
 return false
end

local function step(fn,...)
 local ok,err=pcall(fn,...)
 if not ok then host.errors=host.errors+1; U.log(engine.log,engine.time,'ERROR','stop:'..tostring(err):sub(1,200),-1) end
end


local function stop(final,keepParked)
 if host.allowed then step(cancelProbe); step(Calibration.cancel,calibration,frame,host.caps,globals) end
 step(Applier.restore,host,frame,false,engine.time,final,keepParked); step(syncRestored); step(Applier.checkpoint,host,frame)
end

local lastRaceSave=0
local function saveRace(force)
 if not force and engine.time-lastRaceSave<K.saveDelay then return end
 lastRaceSave=engine.time
 if engine.pits.dirty then engine.pits.dirty=false; Applier.storeText('humanai:pits',Pits.serialize(engine.pits,frame.session)) end
 if engine.penalties.dirty then engine.penalties.dirty=false; Applier.storeText('humanai:penalties',Penalties.serialize(engine.penalties,frame,frame.session)) end

 if engine.strategy.dirty then engine.strategy.dirty=false; Applier.storeText('humanai:strategy',Strategy.serialize(engine.strategy,frame.session)) end
 if engine.sanctions.dirty then engine.sanctions.dirty=false; Applier.storeText('humanai:sanctions',Sanctions.serialize(engine.sanctions,frame.session)) end
end


local bridge,bridgePort=nil,nil


local companion=K.companionNames[1]

local companionKey,companionWindow=companion..'.update','IMGUI_LUA_'..companion..'_main'
local companionPresent,companionAt=false,-math.huge

local setupLabPresent=false
local sessionKey=SessionKey.new()

local tyresKey=TyresKey.new()

local sePlanAt=-math.huge
local strategyPublished=''
local sidePublished={} -- Beta 1.61 : dernier texte écrit de chaque clé annexe (engine.sideText)
host.openCompanion=function() return Applier.openCompanion(companionWindow) end

local function seText(key,old) local text=Applier.loadText(key); if text==nil or text=='' then text=Applier.loadText(old) end return text end


local function bridgeShut()
 pcall(Bridge.close,bridge,bridgePort.hello); bridgePort=nil
 if sessionKey.logged then pcall(Applier.storeText,SessionKey.key,SessionKey.closedText) end
 if tyresKey.body then pcall(Applier.storeText,TyresKey.key,TyresKey.closedText(engine.time or 0)) end
end
local function release()
 if released then return end
 if bridgePort then bridgeShut() end


 released=true; pcall(Snapshot.read,frame,K.dtMax,engine.time); pcall(saveRace,true); Applier.access(host); stop(true); Applier.unregister(host)
 pcall(Applier.reportCaps,host)

 pcall(UI.restoreNative,panel); pcall(messages,false); Applier.dispose(messageListener); messageListener=nil



 local up=host.updater; local back=up~=nil and up.after=='rollback'
 local force=back and (not Update.version(up.afterVersion) or Update.newer('Beta 1.40',up.afterVersion))
 pcall(Cspgui.release,csp,cspPort,cspClock,force); Applier.dispose(cspWatch); cspWatch=nil; cspLog()

 pcall(function() writeReport(engine.reportLines or Sanctions.flushReport(engine.sanctions,engine,frame)); engine.reportLines=nil end)
 pcall(writeJournal,true); Applier.journalWrite(host,'=== fin : '..Applier.clockText()..' ===\n')
end



local updater=Update.new(Config.release)
local updateEvents={}
local function updateLog()
 Update.take(updater,updateEvents)
 for i=1,#updateEvents do local ev=updateEvents[i]; U.log(engine.log,engine.time,ev[1],ev[2],-1); updateEvents[i]=nil end
end
onRelease=function() updateLog(); release() end
host.updater=updater; host.updatePort=port; host.updateStopped=false; host.updateNow=0
local updateClock,updateAsked,updateNoticed=0,false,false

local updateNow,updateCounter=0,nil

if port.ready then Update.start(updater,port,recovered) end
updateLog()





local probe,unblockable=nil,false
local probeHide,hideProbed=false,false
local function startProbe(hide) engine.probeSeen=false; probe=Config.K.probeFrames; probeHide=hide; Applier.probeMessage(Config.K.messageProbe) end
messages=function(block,hide)
 if unblockable then block=false end
 if block and not messageBlock then
  messageBlock=Applier.blockMessages() or false
  if messageBlock and probe==nil then startProbe(hide==true) end
 elseif not block and messageBlock~=nil then Applier.dispose(messageBlock); messageBlock=nil end
 if hide and not hideProbed and type(probe)~='number' then startProbe(true) end
 if probe then
  if engine.probeSeen then
   probe=false; if probeHide then hideProbed=true end
   U.log(engine.log,engine.time or 0,'INFO','messages d AC: affichage d origine masque, messages repris sur l overlay'..(probeHide and ' (option de CSP comprise)' or ''),-1)
  else
   probe=probe-1
   if probe<=0 then
    probe=false
    if messageBlock then
     unblockable=true; Applier.dispose(messageBlock); messageBlock=nil
     U.log(engine.log,engine.time or 0,'WARN','messages d AC: les messages masques n arrivent plus a l overlay, masquage leve jusqu au prochain lancement',-1)
    end
    if probeHide then
     hideProbed=true; globals.cspMessagesLost=true; dirty()
     U.log(engine.log,engine.time or 0,'WARN',csp.owned.HIDE_SYSTEM_MESSAGES~=nil and 'messages d AC: masques par l option de CSP, ils n arrivent plus a l overlay: option rendue'
      or 'messages d AC: masques par l option de CSP, ils n arrivent plus a l overlay: decochez Hide system messages (CSP)',-1)
    end
   end
  end
 end
end
local raceKeys={'humanai:pits','humanai:penalties','humanai:strategy','humanai:sanctions'}
local function session()
 if released then return end
 Engine.reset(engine,engine.time,true); engine.session=-1; calibration.attempted=false; Pits.forget(engine.pits); Strategy.forget(engine.strategy); engine.penalties.pending=nil

 if engine.sanctions then engine.sanctions.pending=nil end




 engine.pits.dirty=false; engine.penalties.dirty=false; engine.strategy.dirty=false; if engine.sanctions then engine.sanctions.dirty=false end
 for _,key in ipairs(raceKeys) do Applier.storeText(key,'') end
 host.session=nil -- Un redémarrage garde le même indice : les écritures suivies sont resynchronisées.
end


local function lightsCheck()
 if host.trackLightsFor==frame.track then return end
 local lights=Applier.trackLights(host,frame.track)

 engine.grid.nodes=Applier.gridNodes(host,frame.track)


 engine.pitEntry=Applier.pitEntry(host,frame.track)
 U.log(engine.log,engine.time,'INFO',lights==true and 'panneaux lumineux du circuit: detectes ('..host.trackLightsSource..')' or lights==false and 'panneaux lumineux du circuit: non detectes'..(host.trackLightsDetail or '') or 'panneaux lumineux du circuit: configuration illisible',-1)
end
local capsReported,menuClock=0,0
local function update(dt)
 if released then return end
 local valid=U.finite(dt) and dt>0 and dt<=K.dtMax




 local quiet=not globals.enabled
 if not quiet then
  quiet=true; for _,p in pairs(profiles) do if Config.any(p) then quiet=false; break end end
 end
 if quiet then
  if calibration.index>0 or host.caps.probeIndex>0 or host.flagOverride or host.drsAny or host.drsRelease or host.blackFlag or host.flagLeftover then quiet=false end
  if quiet and anyOwned() then quiet=false end
 end

 Snapshot.sideWanted=(globals.offsetSign or 0)==0 or (globals.sideSign or 0)==0 or globals.signProvisional==true or calibration.index>0
 local read=Snapshot.read(frame,valid and dt or K.dtMax,engine.time,quiet)
 mark(1)


 frame.flagOwned=Applier.flagMine(host,frame)
 if read and not frame.flagOwned and frame.flag~=nativeFlag then
  if nativeFlag~=nil or frame.flag~=K.flagNone then U.log(engine.log,engine.time,'INFO',string.format('drapeau d AC: %d (%s)',frame.flag,nativeFlagNames[frame.flag] or 'autre'),-1) end
  nativeFlag=frame.flag
 end

 if U.finite(dt) and dt>0 then menuClock=menuClock+math.min(dt,1) end
 if read then Applier.menu(host,frame.menu,menuClock) else Applier.menu(host,Snapshot.menu(),menuClock) end

 if companionPresent and menuClock>=companionAt then companionAt=menuClock+K.companionUpdatePeriod; host.companionUpdate=Applier.companionUpdate(companionKey) end
 if companionPresent and menuClock>=sePlanAt then
  sePlanAt=menuClock+K.sePlanPeriod
  local plan=engine.sePlan; if not plan then plan={}; engine.sePlan=plan end
  plan.raw=seText(K.sePlanKey,K.sePlanKeyOld)


  local advice=engine.seStrategy; if not advice then advice={}; engine.seStrategy=advice end
  advice.raw=seText(K.seStrategyKey,K.seStrategyKeyOld)
  local text=engine.pitloss.text
  if text~='' and text~=strategyPublished then strategyPublished=text; Applier.storeText(K.strategyPubKey,text) end



  if not (engine.run and engine.run.classNuance) then engine.sideText['AdvancedIA.traffic']=nil end
  for key,side in pairs(engine.sideText) do if side~='' and side~=sidePublished[key] then sidePublished[key]=side; Applier.storeText(key,side) end end
  for key,was in pairs(sidePublished) do
   if was and (engine.sideText[key]==nil or engine.sideText[key]=='') then
    local stamp=math.floor(math.max(0,engine.time))
    local final=key=='AdvancedIA.traffic' and 'v=1;blue=none;stage=none;car=-1;gap=0;closing=0;count=0;stamp='..stamp
     or 'v=1;wet=0.00;rain=0.00;water=0.00;trend=off;eta=-1;next=none;forecast=unknown;forecastIn=-1;aiDry=0;aiRain=0;stamp='..stamp
    sidePublished[key]=false; Applier.storeText(key,final)
   end
  end
 end
 if not initialized then

  initialized=true; host.session=frame.session; Applier.recover(host,frame)
  Pits.restore(engine.pits,Applier.loadText('humanai:pits'),frame.session)
  Penalties.restore(engine.penalties,Applier.loadText('humanai:penalties'),frame.session)
  Strategy.restore(engine.strategy,Applier.loadText('humanai:strategy'),frame.session)
  Sanctions.restore(engine.sanctions,Applier.loadText('humanai:sanctions'),frame.session)

  do local key=Applier.loadText('humanai:presetsession'); if type(key)=='string' and #key<=256 and not key:find('%c') then engine.presetSession=key end end
  Applier.register(host,function() local ok=pcall(release); if not ok then host.errors=host.errors+1 end end,
   function() local ok=pcall(session); if not ok then host.errors=host.errors+1 end end)
 end
 Applier.baselines(host,frame)

 engine.gridCaps=host.caps.stop.available and host.caps.speed.available and host.caps.offset.available

 engine.stopCap=host.caps.stop.available==true
 engine.pitCap=host.caps.pit.available==true

 engine.teleportCap=host.caps.teleport.available==true

 engine.penaltyWritten=host.penaltyWritten or 0; engine.penaltyCap=host.caps.penalty.available==true
 local ready=Engine.step(engine,frame,dt)
 mark(2)

 Snapshot.wxWanted=engine.run~=nil and engine.run.weatherLive==true


 local memory=engine.pacemap

 if engine.trackForgetAsk then engine.trackForgetAsk=nil; memory.forgetWanted=engine.runtimeG.trackMemory==true end
 if memory.ioRead then
  local key=memory.ioRead; memory.ioRead=nil; local text,place=Applier.trackFileRead(K.paceFolder,key,K.paceMapMaxBytes)

  if Pacemap.loaded(memory,engine,text,place)==false and (text~=nil or place=='big') then refusedAside(K.paceFolder,key,'memoire du circuit') end
 end
 if memory.ioWrite then
  local text,key=memory.ioWrite,memory.ioKey; memory.ioWrite=nil; memory.ioKey=nil
  local place,ms=Applier.trackFileWrite(K.paceFolder,key,text)
  Pacemap.written(memory,engine,place,ms,#text)
 end
 if engine.reportLines then local lines=engine.reportLines; engine.reportLines=nil; writeReport(lines) end
 if engine.presetSessionDirty then engine.presetSessionDirty=false; Applier.storeText('humanai:presetsession',engine.presetSession) end

 if host.caps.failureCount~=capsReported then capsReported=host.caps.failureCount; Applier.reportCaps(host) end
 if engine.settingsChanged then engine.settingsChanged=false; dirty() end
 writeJournal(false)
 mark(3)
 if engine.rebaseDelta>0 then
  Applier.rebase(host,engine.rebaseDelta); calibration.startAt=calibration.startAt-engine.rebaseDelta

  if U.finite(calibration.retryAt) then calibration.retryAt=calibration.retryAt-engine.rebaseDelta end
  if U.finite(engine.panel.updateUntil) then engine.panel.updateUntil=engine.panel.updateUntil-engine.rebaseDelta end
  frame.metaAt=frame.metaAt-engine.rebaseDelta; frame.playerDamageAt=frame.playerDamageAt-engine.rebaseDelta
  if frame.conflictAt then frame.conflictAt=frame.conflictAt-engine.rebaseDelta end
  lastCheckpoint=lastCheckpoint-engine.rebaseDelta; lastRaceSave=lastRaceSave-engine.rebaseDelta
  journal.flushAt=journal.flushAt-engine.rebaseDelta; journal.summaryAt=journal.summaryAt-engine.rebaseDelta
 end
 if host.session~=frame.session then Applier.nextSession(host,frame) end
 if not valid or frame.online or frame.replay or frame.paused then return end

 if not ready then lightsCheck() end
 if not ready and not engine.recalibrateRequested and calibration.index==0 and host.caps.probeIndex==0 then

  if not anyOwned() then
   if (host.flagOverride or host.flagLeftover) and Applier.access(host) then Applier.flag(host,frame,false,nil,nil,nil,engine.time) end

   if (host.drsAny or host.drsRelease) and Applier.access(host) then Applier.drs(host,frame,nil,engine.time); Applier.checkpoint(host,frame) end

   if not globals.enabled and host.blackFlag and Applier.access(host) then
    Applier.releaseBlackFlag(host); if not host.blackFlag then engine.penalties.disqualified=false; engine.penalties.kind='slow' end
   end
   Applier.save(host,globals,profiles,engine.time,frame.replay); return
  end
 end
 local access=Applier.access(host)
 if not access then engine.guard='access'; return end
 if engine.recalibrateRequested then
  stop()
  if calibration.index>0 or anyOwned() then calibration.phase='waiting_reset'; return end


  if K.signProvisional then globals.offsetSign=-1; globals.sideSign=-1; globals.signProvisional=true else globals.offsetSign=0; globals.sideSign=0 end
  calibration.attempted=false; calibration.phase='waiting'
  engine.recalibrateRequested=false; Engine.reset(engine,engine.time,false); dirty()
 end
 if not ready then
  stop(false,engine.guard=='finished'); coolStep(dt,engine.guard=='finished')
  Applier.save(host,globals,profiles,engine.time,frame.replay); return
 end
 if loadedTrack~=frame.track then
  loadedTrack=frame.track; engine.zones={}; engine.zoneStart=-1; local data=Snapshot.zones(frame.track)
  lightsCheck()
  if data then
   local zones,err=Zones.parse(data)
   if zones then engine.zones=zones; U.log(engine.log,engine.time,'INFO','zones_loaded',-1)
   else U.log(engine.log,engine.time,'WARN','zones_rejected:'..err,-1) end
  end


  local key=frame.trackKey or ''
  if key~='' then
   local text,why=Applier.trackFileRead(K.zoneFolder,key,K.maxZoneBytes)
   if text then
    local decoded,reason=Zones.decode(text,frame.track,frame.layout,frame.length)
    if decoded then
     local fromFile=#engine.zones
     engine.zones=Zones.merge(engine.zones,decoded)
     U.log(engine.log,engine.time,'INFO',string.format('zones: %d du fichier, %d du pilote, %d apprises (%s)',fromFile,#decoded.user,#decoded.learnt,key),-1)
     if decoded.ignored>0 then U.log(engine.log,engine.time,'WARN',string.format('zones: %d zone(s) ignoree(s) (%s)',decoded.ignored,key),-1) end
     if not decoded.lengthOK then U.log(engine.log,engine.time,'WARN',string.format('zones: longueur du circuit changee, zones apprises ecartees (%s)',key),-1) end
    else U.log(engine.log,engine.time,'WARN',string.format('zones: fichier refuse (%s)',reason),-1); refusedAside(K.zoneFolder,key,'zones') end
   elseif why=='big' then U.log(engine.log,engine.time,'WARN','zones: fichier refuse (taille)',-1); refusedAside(K.zoneFolder,key,'zones') end
  end
 end


 if dangerTrack~=frame.track then
  dangerTrack=frame.track
  local key=frame.trackKey or ''
  local list,junction=nil,-1
  if key~='' and frame.length>0 then
   local text,why=Applier.trackFileRead(Dangerfile.DF.folder,key,Dangerfile.DF.maxBytes)
   if text then
    local decoded,reason=Dangerfile.decode(text,frame.track,frame.layout,frame.length)
    if decoded then list=decoded; junction=reason
    else U.log(engine.log,engine.time,'WARN',string.format('zones dangereuses: fichier refuse (%s)',tostring(reason)),-1); refusedAside(Dangerfile.DF.folder,key,'zones dangereuses') end
   elseif why=='big' then U.log(engine.log,engine.time,'WARN','zones dangereuses: fichier refuse (taille)',-1); refusedAside(Dangerfile.DF.folder,key,'zones dangereuses') end
  end
  local n=Dangerfile.loaded(engine.danger,list,key,junction)

  if n>0 or junction>=0 then U.log(engine.log,engine.time,'INFO',string.format('zones dangereuses connues: %d',n),-1) end
  if engine.danger.dirty then engine.dangerSaveAsk=true end
 end
 engine.dangerDate=engine.dangerDate or Applier.clockText():sub(1,10)
 if engine.dangerSaveAsk then
  engine.dangerSaveAsk=nil
  local key=frame.trackKey or ''
  if key~='' and frame.length>0 then
   local text=Dangerfile.encode(engine.danger,{track=frame.track,layout=frame.layout,length=frame.length})
   if #text<=Dangerfile.DF.maxBytes and Applier.trackFileWrite(Dangerfile.DF.folder,key,text) then engine.danger.dirty=false
   else U.log(engine.log,engine.time,'WARN','zones dangereuses: enregistrement impossible',-1) end
  end
 end


 if engine.zoneSaveAsk then
  local ask=engine.zoneSaveAsk; engine.zoneSaveAsk=nil
  local key=frame.trackKey or ''


  local zones=engine.zones
  local userCount=0; for _,z in ipairs(zones) do if z.source=='user' then userCount=userCount+1 end end
  local nothing=ask=='forget' and #(zones.learnt or {})==0 or ask=='user' and userCount==0 and not engine.runtimeG.trackMemory
  if nothing then U.log(engine.log,engine.time,'INFO','zones: rien a enregistrer',-1) end
  if not nothing and key~='' and frame.length>0 and (ask~='learn' or engine.runtimeG.trackMemory) then
   if ask=='forget' then
    local n=#(zones.learnt or {})
    zones.learnt={}; Zones.index(zones)
    U.log(engine.log,engine.time,'INFO',string.format('zones: %d zone(s) apprise(s) oubliee(s) a la demande (%s)',n,key),-1)
   end
   local text,count=Zones.encode(zones,{track=frame.track,layout=frame.layout,length=frame.length,serial=zones.serial or 0})
   if #text<=K.maxZoneBytes and Applier.trackFileWrite(K.zoneFolder,key,text) then
    zones.dirty=nil
    U.log(engine.log,engine.time,'INFO',string.format('zones: fichier enregistre (%d zones, %s)',count,key),-1)
   else U.log(engine.log,engine.time,'WARN','zones: enregistrement impossible',-1) end
  end
 end
 Applier.restore(host,frame,true,engine.time)
 syncRestored()
 local probeBefore=host.caps.probeIndex
 if Config.on(engine.p,'general') then Caps.probe(host.caps,frame,engine.time,engine.runtimeG)
 else cancelProbe(); Caps.mode(host.caps,engine.runtimeG) end
 local levelReport=Caps.report(host.caps,engine.runtimeG)
 if levelReport then U.log(engine.log,engine.time,'INFO',levelReport,-1) end
 if probeBefore==0 and host.caps.probeIndex>0 then
  local index=host.caps.probeIndex; local s=host.cars[index]; local car=frame.cars[index]
  if not s.owned then s.owned=true; s.id=car.identity or car.id; s.originalLevel=host.caps.probeOriginal; s.originalAggression=car.aiAggression end
  s.level=K.probeLevel; host.recoveryDirty=true; Applier.checkpoint(host,frame)
 elseif probeBefore>0 and host.caps.probeIndex==0 then

  local s=host.cars[probeBefore]
  if s.owned and s.level~=nil then s.level=host.caps.probeOriginal; s.levelAt=engine.time end
 end
 local signBefore,sideBefore=globals.offsetSign,globals.sideSign
 if Config.needsOffset(engine.run,engine.profile) then -- Beta 1.62 : la défense ne compte qu'en course

  if calibration.index>0 or globals.offsetSign==0 or globals.sideSign==0 or globals.signProvisional then
   for i=1,frame.count do
    local state=engine.states[i]
    frame.cars[i].calibrationBlocked=state.state~='DRIVE' or state.excluded or engine.commands[i].active~=true
   end
  end
  Calibration.step(calibration,frame,host.caps,globals,engine.time)



 elseif calibration.index>0 then step(Calibration.cancel,calibration,frame,host.caps,globals) end
 if (signBefore~=globals.offsetSign or sideBefore~=globals.sideSign) and globals.offsetSign~=0 then U.log(engine.log,engine.time,'INFO',string.format('sens lateral mesure: %d / %d',globals.offsetSign,globals.sideSign),-1); calibration.confirmed=false end

 if calibration.confirmed then calibration.confirmed=false; U.log(engine.log,engine.time,'INFO',string.format('sens lateral provisoire confirme par la mesure: %d / %d',globals.offsetSign,globals.sideSign),-1); dirty() end
 if signBefore~=globals.offsetSign or sideBefore~=globals.sideSign or engine.settingsChanged then engine.settingsChanged=false; dirty() end
 if calibration.index>0 then
  local index=calibration.index; engine.commands[index].active=false
  local s=host.cars[index]; local car=frame.cars[index]
  if not s.owned then s.owned=true; s.id=car.identity or car.id; s.originalLevel=car.aiLevel; s.originalAggression=car.aiAggression end
  s.offset=K.calibrationOffset
  s.offsetReset=false
  if engine.time==calibration.startAt then host.recoveryDirty=true; Applier.checkpoint(host,frame) end
 end


 local rg=engine.runtimeG
 if rg.offsetSign~=globals.offsetSign or rg.sideSign~=globals.sideSign then Config.effectiveGlobals(globals,engine.p,rg) end
 host.calibrationIndex=calibration.index

 Applier.rejoin(host,frame,engine.incidents,engine.commands)
 Applier.apply(host,frame,engine.commands,engine.runtimeG,engine.time)
 coolStep(dt,true)


 local lightsOn=Config.on(engine.run,'lights') and host.trackLights==true
 local flagValue,flagReason=Lights.output(engine.lights,engine.incidents,lightsOn)
 Applier.flag(host,frame,flagValue,flagReason,lightsOn and engine.time or nil,engine.run.lightsHold,engine.time)
 Applier.penalty(host,frame,engine.penalties)

 local muted=globals.appSounds==false
 Applier.beep(host,frame,engine.drs,muted)
 Applier.deltaBeep(host,frame,engine.deltaBeep,muted)
 Applier.drs(host,frame,engine.commands,engine.time)
 announce()
 local periodic=engine.time-lastCheckpoint>=K.saveDelay
 if host.recoveryDirty or periodic then lastCheckpoint=engine.time; Applier.checkpoint(host,frame,periodic) end
 saveRace(false)
 Applier.save(host,globals,profiles,engine.time,frame.replay)
end


local function updateTick(dt)
 if not port.ready then return end
 local step=U.finite(dt) and dt>0 and dt<=K.dtMax and dt or 0
 if U.finite(dt) and dt>0 and dt<=K.dtMax then updateClock=updateClock+dt end
 local counter=Applier.clock(host)
 if counter and updateCounter and counter>updateCounter then step=math.max(step,counter-updateCounter) end
 updateCounter=counter; updateNow=updateNow+math.min(step,1); host.updateNow=updateNow

 if released then if updater.phase=='restarting' then Update.tick(updater,port,false,updateNow); updateLog() end; return end

 local slot=frame.player>0 and frame.player or frame.lightPlayer or 0
 local player=slot>0 and frame.cars[slot] or nil
 host.updateStopped=Update.stopped(frame,player)
 Update.tick(updater,port,host.updateStopped,updateNow)
 if not updateAsked and globals.updateCheck and updateClock>=K.updateDelay and updater.phase=='idle' then updateAsked=true; Update.check(updater,port,updateNow) end
 local pit=player~=nil and player.pit==true and not frame.paused
 local panelState=engine.panel
 if pit and not updateNoticed and Update.offered(updater) then
  updateNoticed=true; panelState.updateUntil=engine.time+K.updateNotice; panelState.updateVersion=updater.release.version
 elseif not pit then panelState.updateUntil=-math.huge end
 updateLog()
end
local function protect(fn,arg)
 local ok,err=pcall(fn,arg)
 if not ok then
  engine.errors=engine.errors+1; engine.panic=true
  U.log(engine.log,engine.time,'ERROR',tostring(err):sub(1,256),-1)
  pcall(stop)
 end
 return ok
end



local booted=false
local bootEngine,bootUI=0,0
if port.unreadable then U.log(engine.log,0,'ERROR','mise a jour: module illisible, app chargee sans mise a jour ('..port.unreadable..')',-1) end
HUMANAI={engine=engine,host=host,release=release,updater=updater,port=port,panel=panel}





for _,name in ipairs(K.companionNames) do if Applier.companionInstalled(name) then companion=name; companionPresent=true; break end end
companionKey,companionWindow=companion..'.update','IMGUI_LUA_'..companion..'_main'
setupLabPresent=Applier.companionInstalled('SetupLab')

local superHudPresent=Applier.companionInstalled('SuperHUD')
if companionPresent then



 local version=Applier.companionVersion(companion)
 if version then
  host.companionVersionText=string.format('%d.%d.%d',version[1],version[2],version[3])
  host.companionOldStart=Applier.versionBelow(version,{K.seStartMinMajor,K.seStartMinMinor,K.seStartMinPatch})
  U.log(engine.log,0,'INFO',string.format('pont des apps compagnes: %s version %s%s',companion,host.companionVersionText,host.companionOldStart and ' (tour de formation et depart lance inconnus avant la '..string.format('%d.%d.%d',K.seStartMinMajor,K.seStartMinMinor,K.seStartMinPatch)..')' or ''),-1)
 else U.log(engine.log,0,'INFO','pont des apps compagnes: version de '..companion..' illisible',-1) end
end
if companionPresent or setupLabPresent or superHudPresent then
 local why
 bridge=Bridge.new(Config.release)
 bridgePort,why=Applier.bridgeOpen(Bridge.layout)
 U.log(engine.log,0,'INFO',bridgePort and string.format('pont des apps compagnes: ouvert (version %d)',Bridge.layout.version) or 'pont des apps compagnes: indisponible ('..tostring(why)..')',-1)
 if setupLabPresent then U.log(engine.log,0,'INFO','pont des apps compagnes: SetupLab present, cle '..SessionKey.key..' publiee',-1) end
 if superHudPresent then U.log(engine.log,0,'INFO','pont des apps compagnes: SuperHUD present',-1) end
else
 U.log(engine.log,0,'INFO','pont des apps compagnes: '..companion..' absent, pont inactif',-1)
end

local function bridgeWork()
 Bridge.beat(bridge,bridgePort.hello); Bridge.publish(bridge,bridgePort.data,engine,frame)

 if setupLabPresent then
  local text=SessionKey.step(sessionKey,engine,frame,engine.time or 0)
  if text then
   Applier.storeText(SessionKey.key,text)
   if not sessionKey.logged then sessionKey.logged=true; U.log(engine.log,engine.time or 0,'INFO','cle de session pour SetupLab: premiere ecriture',-1) end
  end
 end

 if companionPresent then
  local text=TyresKey.step(tyresKey,engine,frame,engine.time or 0)
  if text then Applier.storeText(TyresKey.key,text) end
 end
end
local function bridgeStep()
 if released or not bridgePort then return end
 local ok,err=pcall(bridgeWork)
 if not ok then
  bridgeShut()
  U.log(engine.log,engine.time or 0,'ERROR','pont des apps compagnes coupe: '..tostring(err):sub(1,200),-1)
 end
end

HUMANAI.bridgePort=function() return bridgePort end
local costFrames=0
function script.HUMANAI__UPDATE(dt)
 local before=Applier.clock(host)
 prof.at=before; local cur=prof.cur; for i=1,7 do cur[i]=0 end
 local ran=protect(update,dt)
 mark(4)
 if ran and not booted then
  bootEngine=bootEngine+1

  if bootEngine>=K.bootFrames and bootUI>=K.bootUIFrames then booted=true; bootWatched=false; pcall(port.bootOk); if port.ready then pcall(Update.tidy,updater,port); updateLog() end end
 end
 local ok,err=pcall(updateTick,dt)
 if not ok then host.errors=host.errors+1; U.log(engine.log,engine.time,'ERROR','mise a jour: '..tostring(err):sub(1,200),-1) end
 mark(5)

 if not released and csp.writable and not bootWatched then
  local okCsp,errCsp=pcall(cspStep,dt)
  if not okCsp then csp.writable=false; host.errors=host.errors+1; U.log(engine.log,engine.time,'ERROR','options CSP: '..tostring(errCsp):sub(1,200),-1) end
 end
 mark(6)
 bridgeStep()
 mark(7)
 local after=before and Applier.clock(host)
 prof.at=nil
 if after then
  local cost=math.max(0,after-before)*1000
  for i=1,7 do prof.sum[i]=prof.sum[i]+cur[i] end; prof.frames=prof.frames+1

  if cost>K.slowFrameMs and prof.slowLogs<K.slowFrameLogs and menuClock-prof.slowAt>=K.slowFrameGap then
   prof.slowLogs=prof.slowLogs+1; prof.slowAt=menuClock
   U.log(engine.log,engine.time,'WARN',string.format('image lente: %.0f ms (lecture %.1f, moteur %.1f, fichiers %.1f, commandes %.1f, mise a jour %.1f, options CSP %.1f, pont %.1f)',
    cost,cur[1]*1000,cur[2]*1000,cur[3]*1000,cur[4]*1000,cur[5]*1000,cur[6]*1000,cur[7]*1000),-1)
  end


  if costFrames>0 then engine.maxFrame=math.max(engine.maxFrame,cost) end


  costFrames=math.min(costFrames+1,K.performanceWindow)
  engine.meanFrame=engine.meanFrame+(cost-engine.meanFrame)/costFrames
 end
end

function script.update(dt) script.HUMANAI__UPDATE(dt) end
function script.HUMANAI__MENU() if not released then Applier.menu(host,Snapshot.menu()) end end

local lastUIError=''
local function protectUI(fn,arg)
 local ok,err=pcall(fn,arg)
 if ok then
  if not booted then bootUI=bootUI+1 end
 else
  host.errors=host.errors+1
  local text=tostring(err):sub(1,200)
  if text~=lastUIError then lastUIError=text; U.log(engine.log,engine.time,'ERROR','ui:'..text,-1) end
 end
end



local slowSeen,slowCount,slowWarm={},0,{}
local Widgets=require('src/widgets'); local missingNoted=false
local function timedUI(fn,place)
 local started=Applier.clock(host)
 protectUI(fn,panel)
 local ended=started and Applier.clock(host)
 local spent=ended and ended-started or 0
 local slot=place=='overlay' and 9 or 8
 prof.sum[slot]=prof.sum[slot]+spent
 local window=place or 'main'
 local limit=slowWarm[window] and K.uiSlowFrame or K.uiSlowFirst; slowWarm[window]=true
 if spent>limit and slowCount<K.uiSlowLogs then
  local where=place or UI.where(panel)
  if not slowSeen[where] then
   slowSeen[where]=true; slowCount=slowCount+1
   U.log(engine.log,engine.time,'WARN',string.format('interface lente: %s, %.0f ms',where,spent*1000),-1)
  end
 end

 if Widgets.missing and not missingNoted then missingNoted=true; U.log(engine.log,engine.time,'WARN','interface: texte absent ('..Widgets.missing..')',-1) end
end

local function windowScaleCheck()
 if host.windowScaleSeen==nil then host.windowScaleSeen=globals.windowScale
 elseif host.windowScaleSeen~=globals.windowScale then host.windowScaleSeen=globals.windowScale; Applier.scaleWindow(host,UI.scaledSize(globals.windowScale),globals.windowScale) end
end
function script.HUMANAI__MAIN()
 script.HUMANAI__MENU()
 if host.menuVisible then
  panel.ingame=false; panel.ingameFull=false

  if not globals.windowCompacted and Applier.compactWindow(host,UI.compactSize()) then globals.windowCompacted=true; dirty() end

  windowScaleCheck()
  timedUI(UI.main)


 elseif Applier.windowOpenInGame(host) then
  panel.ingame=true
  windowScaleCheck()
  timedUI(UI.main)
 end
end




HUMANAI.drawFlags=function() if not released then protectUI(UI.flags,panel) end end

function script.HUMANAI__HUD()
 if released then return end
 timedUI(UI.hud,'overlay')

 local shown=globals.overlayEnabled~=false
 pcall(messages,globals.overlayMessages and globals.overlayBlockMessages and globals.enabled and shown,globals.overlayMessages and globals.enabled and shown and Cspgui.applied(csp,'HIDE_SYSTEM_MESSAGES'))
end











local U=require('src/util')
local C=require('src/config')
local Perception=require('src/perception')
local Priority=require('src/priority')
local Sanctions=require('src/sanctions')
local K=C.K
local abs,max,huge=math.abs,math.max,math.huge
local M={}

local SAMPLES=8
local CASES=24
local function case() return {firstLap=false,open=false,i=0,j=0,key=0,at=0,dueAt=0,fault=0,situation='',diff=0,lostI=false,lostJ=false,placeI=0,placeJ=0,waiting=false,outAll=true,idI='',idJ=''} end
function M.new()
 local t={session=-1,raceGen=nil,sampleAt=-huge,head=0,filled=0,lat={},mid={},off={},rejoinAt={},hitAt={},hitBy={},cases={},open=0,pairUntil={},
  rel={index=0,long=0,lat=0,gap=0,sa=0,ttc=huge,same=false,alongside=false}}
 for i=1,K.maxCars do
  t.off[i]=false; t.rejoinAt[i]=-huge; t.hitAt[i]=-huge; t.hitBy[i]=0
  for k=1,SAMPLES do t.lat[(i-1)*SAMPLES+k]=huge; t.mid[(i-1)*SAMPLES+k]=huge end
 end
 for k=1,CASES do t.cases[k]=case() end
 return t
end
local function clear(t)
 for i=1,K.maxCars do
  t.off[i]=false; t.rejoinAt[i]=-huge; t.hitAt[i]=-huge; t.hitBy[i]=0
  for k=1,SAMPLES do t.lat[(i-1)*SAMPLES+k]=huge; t.mid[(i-1)*SAMPLES+k]=huge end
 end
 for k=1,CASES do t.cases[k].open=false end
 for key in pairs(t.pairUntil) do t.pairUntil[key]=nil end
 t.open=0; t.head=0; t.filled=0; t.sampleAt=-huge
end
function M.reset(t) t.session=-1; t.raceGen=nil; clear(t) end -- (t,now)
function M.rebase(t,amount)
 t.sampleAt=t.sampleAt-amount
 for i=1,K.maxCars do t.rejoinAt[i]=t.rejoinAt[i]-amount; t.hitAt[i]=t.hitAt[i]-amount end
 for key,v in pairs(t.pairUntil) do t.pairUntil[key]=v-amount end
 for k=1,CASES do local c=t.cases[k]; c.at=c.at-amount; c.dueAt=c.dueAt-amount end
end


function M.active(e)
 local p=e.run; local profile=e.profile
 return p~=nil and (p.sanContact==true or p.sanPlayerContact==true and profile=='C') and (profile=='C' or profile=='P' or profile=='Q')
end
local active=M.active


local function moved(t,i)
 local back=math.ceil(K.blameCutTime/K.blameSample)
 if t.filled<=back or back>=SAMPLES then return nil end
 local base=(i-1)*SAMPLES
 local newest=t.lat[base+t.head]; local oldest=t.lat[base+(t.head-back-1)%SAMPLES+1]
 if newest==huge or oldest==huge then return nil end



 local midNew=t.mid[base+t.head]; local midOld=t.mid[base+(t.head-back-1)%SAMPLES+1]
 if midNew==huge or midOld==huge or abs(midNew-midOld)>K.blameMoveMin*0.5 then return nil end
 return newest-oldest
end

local function wrecked(e,frame,i)
 local a=frame.cars[i]; local ic=e.incidents.cars[i]
 return ic~=nil and ic.incident==true or a.offtrack==true or a.kmh<(e.run.obstacleSpeedKmh or 25)
end
local function lost(e,frame,i)
 local a=frame.cars[i]; local ic=e.incidents.cars[i]
 return ic~=nil and ic.incident==true or a.offtrack==true
end
local function name(a) return a.name~='' and a.name or a.id or '?' end


local function judge(t,e,frame,i,j,now)
 local a,b=frame.cars[i],frame.cars[j]; local p=e.run; local inc=e.incidents
 local rel=Perception.relative(a,b,frame.length,t.rel)
 local side=abs(rel.lat)>=(a.width+b.width)*0.5

 local rear,front=i,j
 if rel.long<0 then rear,front=j,i end
 local diff=abs(a.kmh-b.kmh)
 if inc.red or inc.neutral then return 0,'indetermine' end



 local starting=e.profile=='C' and (not frame.started or now-max(e.startedAt,e.launchAt or -huge)<K.blameStartGrace or inc.standing~=nil and inc.standing~='none' and inc.standing~='go')
 if starting and (side or diff<=K.blameStartKmh) then return 0,'depart' end


 local chainI=now-t.hitAt[i]<=K.blameChain and t.hitBy[i]~=j and t.hitBy[i]~=0
 local chainJ=now-t.hitAt[j]<=K.blameChain and t.hitBy[j]~=i and t.hitBy[j]~=0
 if wrecked(e,frame,i) or wrecked(e,frame,j) or not rel.same or chainI or chainJ then return 0,'voiture accidentee' end

 local backI,backJ=now-t.rejoinAt[i]<=K.blameRejoin,now-t.rejoinAt[j]<=K.blameRejoin
 if backI and backJ then return 0,'indetermine' end
 if backI then return i,'retour en piste' end
 if backJ then return j,'retour en piste' end




 local yawA,yawB=abs(a.yawRate or 0),abs(b.yawRate or 0)
 local curve=1-yawA/p.cornerYawRef<p.cornerMin or yawA*a.speed>=K.blameCornerG or 1-yawB/p.cornerYawRef<p.cornerMin or yawB*b.speed>=K.blameCornerG
 local si,sj=e.states[i],e.states[j]
 local yellowZone=si~=nil and si.yellow==true or sj~=nil and sj.yellow==true
 local corner=curve or not yellowZone and ((a.brake or 0)>=K.passBrakeMax or (b.brake or 0)>=K.passBrakeMax)
 local movedI,movedJ=moved(t,i),moved(t,j)
 if not side then

  local sf=e.states[front]
  if sf~=nil and sf.abnormal==true then return 0,'voiture accidentee' end
  if curve then return rear,'virage nez derriere' end



  local mf=front==i and movedI or movedJ; local mr=rear==i and movedI or movedJ
  if not (mf and mr) then return 0,'indetermine' end
  if abs(mf)>=K.blameMoveMin and abs(mf)>=K.blameMoveRatio*abs(mr) then return front,'ligne droite changement de ligne' end
  return rear,'ligne droite choc par l arriere'
 end
 if corner then




  local ri,rj,mode=Priority.recorded(e,frame,i,j,now)
  if not ri then return 0,'virage sans duel enregistre' end
  local axes=mode=='axes'
  if ri=='non' and rj=='oui' then return i,axes and 'virage sans droit a l espace' or 'virage nez derriere' end
  if rj=='non' and ri=='oui' then return j,axes and 'virage sans droit a l espace' or 'virage nez derriere' end
  return 0,axes and 'droit a l espace incertain' or 'nez a egalite'
 end



 if not (a.trackLatValid and b.trackLatValid and movedI and movedJ) then return 0,'indetermine' end
 local towards=b.trackLat>=a.trackLat and 1 or -1
 local mi,mj=movedI*towards,-movedJ*towards
 local heldI,heldJ=Priority.held(e.states[i],now)==j,Priority.held(e.states[j],now)==i
 local faultI=mi>=K.blameMoveMin and (heldI or mi>=K.blameMoveRatio*max(0,mj))
 local faultJ=mj>=K.blameMoveMin and (heldJ or mj>=K.blameMoveRatio*max(0,mi))
 if faultI and not faultJ then return i,'ligne droite changement de ligne' end
 if faultJ and not faultI then return j,'ligne droite changement de ligne' end
 return 0,'indetermine'
end
function M.contact(t,e,frame,i,j,now)
 if not active(e) then return end
 local a,b=frame.cars[i],frame.cars[j]

 if a.pit or b.pit or a.safetyCar or b.safetyCar or a.finished or b.finished then return end

 if not e.run.sanContact and not (a.player or b.player) then return end
 local key=i<j and i*K.maxCars+j or j*K.maxCars+i
 local busy=t.pairUntil[key]
 if busy and now<busy and busy-now<=K.blameOutcome+K.blamePairGap then

  t.pairUntil[key]=max(busy,now+K.blamePairGap); t.hitAt[i]=now; t.hitAt[j]=now
  return
 end
 local slot=nil
 for k=1,CASES do if not t.cases[k].open then slot=t.cases[k]; break end end
 local fault,situation=judge(t,e,frame,i,j,now)
 t.hitAt[i]=now; t.hitBy[i]=j; t.hitAt[j]=now; t.hitBy[j]=i
 t.pairUntil[key]=now+K.blameOutcome
 if not slot then return end
 slot.open=true; slot.i=i; slot.j=j; slot.key=key; slot.at=now; slot.dueAt=now+K.blameOutcome; slot.fault=fault; slot.situation=situation
 slot.diff=abs(a.kmh-b.kmh); slot.lostI=false; slot.lostJ=false; slot.placeI=a.position or 0; slot.placeJ=b.position or 0; slot.waiting=false; slot.outAll=true
 slot.idI=a.identity or a.id or ''; slot.idJ=b.identity or b.id or ''

 local si,sj=e.states[i],e.states[j]
 slot.firstLap=e.profile=='C' and (si~=nil and (si.flW or 0)>0 or sj~=nil and (sj.flW or 0)>0)
 t.open=t.open+1
end
function M.sample(t,e,frame,now)
 if not active(e) then
  if t.open>0 or t.filled>0 then clear(t) end
  return
 end

 if t.session~=frame.session or t.raceGen~=e.raceGen then clear(t); t.session=frame.session; t.raceGen=e.raceGen end
 if now-t.sampleAt<K.blameSample and now>=t.sampleAt then return end
 t.sampleAt=now
 t.head=t.head%SAMPLES+1; if t.filled<SAMPLES then t.filled=t.filled+1 end
 for i=1,math.min(frame.count,K.maxCars) do
  local a=frame.cars[i]
  local known=a.valid and a.trackLatValid==true and not a.teleport
  t.lat[(i-1)*SAMPLES+t.head]=known and a.trackLat or huge

  t.mid[(i-1)*SAMPLES+t.head]=known and (a.leftWidth or 0)>0 and (a.rightWidth or 0)>0 and (a.rightWidth-a.leftWidth)*0.5 or huge
  if a.teleport or not a.valid then t.off[i]=false; t.rejoinAt[i]=-huge; for k=1,SAMPLES do t.lat[(i-1)*SAMPLES+k]=huge; t.mid[(i-1)*SAMPLES+k]=huge end
  else
   local off=a.offtrack==true and not a.pit
   if t.off[i] and not off and not a.pit then t.rejoinAt[i]=now end
   t.off[i]=off
  end
 end

 if t.open>0 then
  for k=1,CASES do
   local c=t.cases[k]
   if c.open then
    if lost(e,frame,c.i) then c.lostI=true end
    if lost(e,frame,c.j) then c.lostJ=true end
    if c.waiting then
     local victim=c.fault==c.i and c.j or c.i
     if not wrecked(e,frame,victim) then c.outAll=false end
    end
   end
  end
 end
end
local function close(t,c) c.open=false; c.waiting=false; t.open=max(0,t.open-1) end
local function incident(t,e,frame,c,situation,now)
 e.stats.blameJudged=(e.stats.blameJudged or 0)+1; e.stats.blameIncident=(e.stats.blameIncident or 0)+1
 U.log(e.log,now,'INFO',string.format('incident de course: contact %s / %s (%s)',name(frame.cars[c.i]),name(frame.cars[c.j]),situation),c.i)
 close(t,c)
end
function M.settle(t,e,frame,now)
 if t.open==0 then return end
 if not active(e) then return end
 for k=1,CASES do
  local c=t.cases[k]
  if c.open and (now>=c.dueAt or c.dueAt-now>K.blameOutcome+K.blameOutTime) then
   local a,b=frame.cars[c.i],frame.cars[c.j]

   if c.i>frame.count or c.j>frame.count or not a.valid or not b.valid or (a.identity or a.id or '')~=c.idI or (b.identity or b.id or '')~=c.idJ then close(t,c)
   elseif c.diff<K.blameMinKmh and not c.lostI and not c.lostJ then incident(t,e,frame,c,'contact leger',now)



   elseif not c.lostI and not c.lostJ and (c.diff<K.blameNudgeKmh or c.firstLap and c.diff<=K.blameStartKmh) then
    e.stats.blameLenient=(e.stats.blameLenient or 0)+1; incident(t,e,frame,c,c.firstLap and 'premier tour' or 'touchette',now)
   elseif c.fault==0 then incident(t,e,frame,c,c.situation,now)
   else
    local fault=c.fault; local victim=fault==c.i and c.j or c.i
    local fa=frame.cars[fault]; local va=frame.cars[victim]

    local judged
    if fa.player then judged=e.run.sanPlayerContact==true and e.profile=='C' else judged=e.run.sanContact==true and fa.control==true end
    if not judged then incident(t,e,frame,c,'non juge',now)
    else
     local before=victim==c.i and c.placeI or c.placeJ; local after=va.position or 0
     local victimLost=victim==c.i and c.lostI or victim==c.j and c.lostJ
     local serious=victimLost or before>0 and after>0 and after-before>=K.blamePlaces
     if serious and not c.waiting and wrecked(e,frame,victim) and now-c.at<K.blameOutTime then


      c.waiting=true; c.outAll=true; c.dueAt=c.at+K.blameOutTime
     else
      local out=serious and c.waiting and c.outAll and wrecked(e,frame,victim)
      e.stats.blameJudged=(e.stats.blameJudged or 0)+1; e.stats.blameFault=(e.stats.blameFault or 0)+1
      U.log(e.log,now,'INFO',string.format('responsabilite: contact %s / %s, %s : %s en tort (%s)',name(a),name(b),c.situation,name(fa),serious and 'grave' or 'leger'),fault)
      close(t,c)
      Sanctions.contact(e.sanctions,e,frame,fault,serious,out,now)
     end
    end
   end
  end
 end
end
return M

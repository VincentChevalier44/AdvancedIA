




local M={}
M.sections={
 general={{'generalPace',{'levelPct','aggressionPct','caution','brakeZonePct'}},
  {'generalSpread',{'paceSpreadPct','aggrSpreadPct','cautSpreadPct'}},
  {'generalStart',{'pitExitSpread','spawnMode','spawnMinCars','spawnPitPct','spawnGapVariation','floodRangeKm'}}},
 human={{'humanReact',{'reactMin','reactMax','awMin','awMax'}},
  {'humanLine',{'paceDriftPct','personalLineJitter','laneBiasEnabled','laneBiasMax'}},
  {'humanLapse',{'lapseEnabled','lapseIntervalMin','lapseIntervalMax','lapseDurMin','lapseDurMax','lapseDropMin','lapseDropMax'}},
  {'humanMistakes',{'mistakesEnabled','mistakeRate','fineInputs'}},
  {'humanMood',{'dynamicPersona'}}},
 lateral={{'lateralSpeed',{'rampSpeed','rampAccel','lowPassTau'}},
  {'lateralLimits',{'maxSideOffset','cornerMin','cornerYawRef','lateralCooldown','emergencyReleaseFactor'}},
  {'lateralRear',{'rearAwareness'}},
  {'lateralSignals',{'aiTurnSignals'}}},
 start={{'startStanding',{'startDelay','startCautionMult','startAggrMult','startRelax','startLaneHold','firstLapCare'}},
  {'startProcedure',{'raceStart','startRealism'}}},
 yield={{'yieldOrdinary',{'yieldEnabled','yieldSide','yieldOffset','yieldDetectBehind','yieldBehindMargin','yieldHorizon','confirmTime'}},
  {'yieldHold',{'yieldHoldMin','yieldHoldAfterMin','yieldHoldAfterMax','yieldMaxHold'}},
  {'yieldSlow',{'yieldSlowdownPct','inviteSlowdownPct'}},
  {'yieldPressure',{'pressureEnabled','pressureGap','pressureTime'}},
  {'yieldQuali',{'qualiTraffic','qualiCoolLaps','qualiRuns'}}},
 blue={{'blueFlags',{'blueFlagEnabled','blueFlagRange','blueFlagSide','classNuance'}}},
 flash={{'flashPlayer',{'flashMode','flashRange','flashMinAdvantage','flashCloseAdvantage','flashRequestTTL'}},
  {'flashAI',{'flashObliviousPct','flashMaxReactors','hornEnabled','aiFlashEnabled'}}},
 overtake={{'overtakeTrigger',{'overtakeEnabled','overtakeSide','overtakeDetectAhead','overtakeAheadMargin','overtakeHorizon','stuckTime','stuckPaceRatio'}},
  {'overtakeMove',{'overtakeOffset','pullOutGapBase','pullOutGapPerMps','overtakeClearMargin','overtakeRestTime','overtakeChain','slipstreamEnabled','passAid'}},
  {'overtakeDefense',{'defenseEnabled','defenseMaxOffset','defenseCooldown','defenseTriggerGap'}},
  {'overtakeAero',{'towBreakEnabled','towBreakRange','towBreakStraight','dirtyAirEnabled','dirtyAirGap','dirtyAirLiftPct'}},
  {'overtakeFinal',{'finalLapsEnabled','finalLaps','finalAggressionPct','finalDefensePct'}}},
 traffic={{'trafficGap',{'trafficGapSeconds','trafficDensityGain','trafficVariation','trafficMaxReduction'}}},
 accidents={{'accObstacles',{'obstacleEnabled','obstacleSpeedKmh','obstacleDetect','obstacleLevelDrop','obstacleCautionMult'}},
  {'accInvolved',{'avoidOffset','contactRecovery','incidentStop','incidentStopMin','incidentStopMax','rejoinGap','damagePit'}},
  {'accYellow',{'yellowEnabled','yellowBefore','yellowAfter','yellowHold','yellowDecel'}},
  {'accDouble',{'zoneDeltaPct','slowZoneKmh','yellowSpeedKmh'}},
  {'accPlayer',{'yellowHud','flagPanel','yellowMessage','deltaBeeps'}},
  {'accPenalties',{'playerPenalties','deltaTolerance','penaltySeconds','penaltyDisqualify','aiPenalties'}}},
 endurance={{'endOverlay',{'enduranceOverlay','stintLevelSwing','stintDegradationPct'}},
  {'endClasses',{'multiClass','classGapPct','classYieldMargin'}}},
 weather={{'weatherRain',{'weatherAdaptation','weatherTyresEnabled','rainGripBoostPct','weatherLive'}},
  {'weatherOutLap',{'outLapEnabled','outLapLevelPct'}},
  {'weatherWear',{'lockWearEnabled','lockWearGain','lockFlatSpotKm','wearPace'}},
  {'weatherMessages',{'weatherMessage'}}},

 strategy={{'strategyPlan',{'strategyEnabled','strategyTyreWearPct','strategyFuelMarginLaps','strategyUndercut','strategyStartVariety','strategySmart'}},
  {'strategyCharacter',{'strategyRiskPct','strategySpreadPct'}},
  {'strategyFailures',{'failuresEnabled','failureRate','failureLossPct'}}},
 sanctions={{'sanctionsTrack',{'sanTrackLimits','sanTrackWarnings','sanCutPenalty','sanCutSeconds'}},
  {'sanctionsProcedure',{'sanJumpStart','sanPitSpeed','sanPitExit','sanProcedureKind'}},
  {'sanctionsFlags',{'sanWrongWay','sanWrongWaySeconds','sanServeLaps'}},
  {'sanctionsServe',{'sanStopGoSeconds','sanTimeSeconds','sanUnservedTime','sanGiveBack','sanGiveBackSeconds'}},
  {'sanctionsDisplay',{'sanMessages','sanReport'}},

  {'sanctionsEscalation',{'sanEscalation','sanEscalationStep','sanEscalationMax'}},
  {'sanctionsPlayer',{'sanPlayerTrackLimits','sanPlayerSession','sanPlayerPenalty','sanPlayerContact'}},
  {'sanctionsContact',{'sanContact'}}},

 lights={{'lightsColours',{'lightsYellow','lightsRed','lightsBlue','lightsWhite','lightsOrange','lightsGreen'}},
  {'lightsDurations',{'lightsGreenTime','lightsHold'}}},

 rules_all={{'rulesCommon',{'noMoveBraking','neutralization','majorIncidentTime','neutralizationHold'}},
  {'rulesNeutral',{'fcyDeltaPct','fcySpeedKmh','vscDeltaPct'}},
  {'rulesRed',{'redFlagEnabled','redFlagCars','redDeltaPct','redFlagSpeedKmh','redFlagHold','redFlagWork','redRestart'}},
  {'rulesF1',{'overtakeMode','overtakeModeGap','overtakeModeBoostPct'}},
  {'rulesDrs',{'drsAssist','rulesDrs','rulesDrsLaps','aiDrs','drsBeepVolume'}},
  {'rulesGT',{'bopEnabled','bopStrengthPct','proAmEnabled'}},
  {'rulesEndurance',{'predictableSlowClass'}}},


 rules_stops={{'stopsWindow',{'pitWindowOpenPct','pitWindowClosePct','pitMessage'}},
  {'stopsEach',{'pitTyres','pitRepair','pitCompoundChange','minPitTime','maxStintMin'}},
  {'stopsFuel',{'pitFuel','pitsClosed'}}},
 rules_safety={{'safetyOut',{'safetyCarEscalation','restartOvertake'}}}}


M.hidden={lightsYellow=true}

for key in pairs(require('src/config').pendingKeys) do M.hidden[key]=true end


local built={}
function M.build(section,controls)
 local key=section
 local hit=built[key]
 if hit and hit.source==controls then return hit.list end
 local byKey={}; for _,control in ipairs(controls) do byKey[control.schema.key]=control end
 local used={}; local list={}
 for _,entry in ipairs(M.sections[section] or {}) do
  local group={id=entry[1],controls={}}
  for _,k in ipairs(entry[2]) do local control=byKey[k]; if control and not used[k] and not M.hidden[k] then used[k]=true; group.controls[#group.controls+1]=control end end
  if #group.controls>0 then list[#list+1]=group end
 end
 local rest={id='other',controls={}}
 for _,control in ipairs(controls) do local k=control.schema.key; if not used[k] and not M.hidden[k] then rest.controls[#rest.controls+1]=control end end
 if #rest.controls>0 then list[#list+1]=rest end
 built[key]={source=controls,list=list}
 return list
end
return M








local U=require('src/util')
local C=require('src/config')
local K=C.K
local L=require('src/lang')
local Locale=require('src/locale')
local Pits=require('src/pits')

local Pitloss=require('src/pitloss')
local Wear=require('src/wear')
local floor,max,min,abs=math.floor,math.max,math.min,math.abs
local M={}
local function car()
 return {identity='',lap=-1,lapWear=-1,wearRate=0,wearLaps=0,lastWear=0,planned=false,stops=-1,nextLap=-1,limit='',planLoggedAt=-math.huge,
  shift=0,reaction=false,wanted=false,cause='',wantSince=0,visit=-1,inLane=false,replan=false,retryAt=0,
  boxSeen=false,outLap=false,outFrom=0,outLap0=-1,outEnd=-math.huge,outLogged=false,
  failState=0,failKind='',failAt=0,failRamp=0,failLoss=0,failChecks=0,failNext=0,failVisit=-1,failRepair=0,failAsked=false,
  wearSeen=0,rivalLane=false,


  mandShiftLap=false,mandatoryReq=false,


  called=false,serving=false,servedVisit=-1,stopWear=-1,stopFuel=-1,stopCause='',stopLimit='',checkAfter=false,checkAt=0,
  noTyreStop=false,noFuelStop=false,kersSeen=false,critical=false,hardTyres=false,deferLogged=false,wearLow=-1,wearLowLap=-1,blockOut=false,


  probeFrom=-1,lastVisit=-1,stopTarget=-1,stopRed=false,



  room=0,rejoinDelay=0,rejoinEval=-1,rejoinHold=-1,scCand=false,scAt=0,lapForm=false}
end
local function clear(list) for k=#list,1,-1 do list[k]=nil end end
function M.new()
 local t={cars={},rows={},events={},head=0,lang='',dirty=false,resetAt=0,outCount=0,outSummary=false,neutralWas=false,wearTrust='unknown'}
 for i=1,K.maxCars do t.cars[i]=car() end
 for k=1,K.strategyRows do t.events[k]={what='',kind='soft',args={},text=''} end
 return t
end

function M.reset(t,now)
 for i=1,K.maxCars do t.cars[i]=car() end
 clear(t.rows); t.head=0; for k=1,K.strategyRows do t.events[k].what='' end
 t.dirty=false; t.resetAt=now; t.outCount=0; t.outSummary=false; t.neutralWas=false; t.lastFailAt=nil

 if t.wearTrust~='trusted' then t.wearTrust='unknown' end
end

function M.forget(t) t.restored=nil; t.restoredSession=-1 end
function M.rebase(t,amount)
 if t.resetAt then t.resetAt=t.resetAt-amount end
 if t.lastFailAt then t.lastFailAt=t.lastFailAt-amount end
 for i=1,K.maxCars do
  local c=t.cars[i]
  c.planLoggedAt=c.planLoggedAt-amount; c.wantSince=c.wantSince-amount; c.outFrom=c.outFrom-amount; c.retryAt=c.retryAt-amount
  c.failAt=c.failAt-amount; c.failNext=c.failNext-amount; c.checkAt=c.checkAt-amount; c.scAt=c.scAt-amount

  if U.finite(c.outEnd) then c.outEnd=c.outEnd-amount end
 end
end


local function render(ev)
 local T=L.strategyTexts; local X=T; local a=ev.args
 if ev.what=='plan' then ev.text=a[2]>0 and string.format(T.plan,a[1],a[2],a[3]) or string.format(X.planNone,a[1])
 elseif ev.what=='stop' then ev.text=string.format(T.stop,a[1],X.causes[a[2]] or T.causes[a[2]] or a[2])
 elseif ev.what=='failure' then ev.text=string.format(T.failure,a[1],T.kinds[a[2]] or a[2])
 elseif ev.what=='repaired' then ev.text=string.format(X.repaired,a[1]) end
end
local function rebuild(t)
 clear(t.rows)
 for k=0,K.strategyRows-1 do
  local ev=t.events[(t.head-k-1)%K.strategyRows+1]
  if ev.what~='' then t.rows[#t.rows+1]=ev end
 end
end
local function event(t,what,a1,a2,a3)
 t.head=t.head%K.strategyRows+1
 local ev=t.events[t.head]; ev.what=what; ev.args[1]=a1; ev.args[2]=a2; ev.args[3]=a3
 ev.kind=what=='failure' and 'warn' or what=='repaired' and 'text' or 'soft'
 render(ev); rebuild(t)
end
local function relang(t)
 if t.lang==Locale.current then return end
 t.lang=Locale.current
 for k=1,K.strategyRows do local ev=t.events[k]; if ev.what~='' then render(ev) end end
end

local function wearOf(a)
 if not a.wearKnown or not a.tyreWear then return -1 end
 local w=a.tyreWear; return max(w[1] or 0,w[2] or 0,w[3] or 0,w[4] or 0)
end
local function name(a) return a.name or ('#'..tostring(a.index or '?')) end




local function wearUse(t,a) if t.wearTrust~='trusted' then return -1 end return wearOf(a) end
local function probe(t,e,a,c,i,now)
 if t.wearTrust=='trusted' then return end
 local w=wearOf(a); if w<0 then return end
 local lap=a.lap or 0

 if c.probeFrom<0 then c.probeFrom=lap end
 if w<=K.wearTrustLow and (c.wearLow<0 or w<c.wearLow) then c.wearLow=w; c.wearLowLap=lap end
 if c.wearLow>=0 and w>=c.wearLow+K.wearTrustRise and lap>c.wearLowLap then
  t.wearTrust='trusted'
  U.log(e.log,now,'INFO',string.format('usure des pneus: echelle verifiee sur %s (%.1f %% a %.1f %% en %d tour(s))',name(a),c.wearLow*100,w*100,lap-c.wearLowLap),i)
 elseif t.wearTrust=='unknown' and lap-c.probeFrom>=K.wearProbeLaps then
  t.wearTrust='unreliable'
  U.log(e.log,now,'INFO',string.format('usure des pneus non fiable ici (%s : %.1f %% apres %d tours) : ni arret pour les pneus, ni blocages lies a l usure',name(a),w*100,lap),i)
 end
end


local function lapsLeft(e,frame,a,i)
 if frame.sessionLaps>0 and not frame.timedRace then return max(0,frame.sessionLaps-(a.lap or 0)) end

 local pc=i and e.pits.cars[i]
 if pc and (pc.lapTime or 0)>0 and frame.sessionMinutes>0 then return Pits.lapsLeft(frame,a,pc.lapTime) end
 return e.race.known and e.race.lapsLeft+1 or -1
end
M.lapsLeft=lapsLeft


local function plan(t,c,e,frame,a,p,i,risk)
 local left=lapsLeft(e,frame,a,i)
 local wear=c.noTyreStop and -1 or wearUse(t,a)
 local threshold=U.clamp(p.strategyTyreWearPct/100*(1+(risk-0.5)*K.strategyRiskWear),K.strategyWearMin,K.strategyWearMax)
 local tyreLaps,fullTyre,tyreHard=math.huge,math.huge,math.huge
 if wear>=0 and c.wearRate>0 then tyreLaps=(threshold-wear)/c.wearRate; fullTyre=threshold/c.wearRate; tyreHard=(K.strategyWearMax-wear)/c.wearRate end
 local pc=e.pits.cars[i]


 local perLap=max(pc and pc.perLap or 0,a.fuelPerLap or 0)
 if (frame.fuelRate or 1)<=0 or c.noFuelStop then perLap=0 end
 local margin=p.strategyFuelMarginLaps*(1-(risk-0.5)*K.strategyRiskFuel)
 local fuelLaps,fullFuel=math.huge,math.huge
 if perLap>0 and (a.fuel or -1)>=0 and (a.maxFuel or 0)>0 then
  fuelLaps=a.fuel/perLap-K.fuelReserveLaps-margin; fullFuel=a.maxFuel/perLap-K.fuelReserveLaps-margin
 end
 local laps=min(tyreLaps,fuelLaps)
 c.limit=tyreLaps<=fuelLaps and 'tyres' or 'fuel'


 local raw=perLap>0 and (a.fuel or -1)>=0 and a.fuel/perLap or math.huge
 c.critical=left>=0 and raw<K.strategyCriticalFuel and raw<left
 c.hardTyres=tyreHard<=1
 c.room=min(tyreHard,raw-K.fuelReserveLaps)
 if laps==math.huge or left<0 then c.stops=-1; c.nextLap=-1; c.planned=false; return left,laps,threshold end





 local endRun=left<=K.strategyLastLaps
 local finishFuel=perLap>0 and (a.fuel or -1)>=0 and a.fuel/perLap-(endRun and K.strategyEndReserve or K.fuelReserveLaps) or math.huge
 if finishFuel>=left and (endRun or tyreHard>=left and tyreLaps+K.strategyStretchLaps*(0.5+risk)>=left) then
  c.stops=0; c.nextLap=-1; c.planned=true; return left,laps,threshold
 end

 if c.shift~=0 then laps=min(laps+c.shift,fuelLaps,tyreHard) end
 local stint=max(1,min(fullTyre,fullFuel))
 if laps>=left then c.stops=0; c.nextLap=-1
 else
  local rest=left-max(0,laps)
  c.stops=1+max(0,math.ceil(rest/stint)-1)
  c.nextLap=(a.lap or 0)+max(0,floor(laps))
 end
 c.planned=true
 return left,laps,threshold
end
local function eligible(a,s,e,i)
 return a.valid and a.control and not a.player and not a.finished and not a.safetyCar and not s.disqualified and not (e.penalties.ai.dq and e.penalties.ai.dq[i])
end



local function want(t,e,c,a,i,cause,now,text,mandatory)
 if c.wanted then return end
 c.wanted=true; c.cause=cause; c.wantSince=now; c.visit=e.pits.cars[i].visit; c.mandatoryReq=mandatory==true
 c.stopWear=wearOf(a); c.stopFuel=a.fuel or -1; c.stopLimit=c.limit; c.stopTarget=-1; c.stopRed=false
 U.log(e.log,now,'INFO',text or string.format('strategie: %s arret demande (%s)',name(a),cause=='tyres' and string.format('pneus %.0f %%',max(0,wearOf(a))*100) or K.strategyCauseLog[cause] or cause),i)
 event(t,'stop',name(a),cause)
end






local function earlyInWindow(e)
 local t=e.pits; if not t or t.position==nil or t.open==nil or t.close==nil then return false end
 local span=t.close-t.open
 return span>0 and t.position<t.close-span*K.strategyWindowMargin
end
local function mandatoryDue(e,i,p)
 local pits=e.pits; local pc=pits and pits.cars[i]

 return (p.mandatoryStops or 0)>0 and pits~=nil and pits.state=='open' and pc~=nil and pc.windowStops<p.mandatoryStops
end


local function near(e,frame,i,j,r,a,p)
 if p.strategySmart then local g=Pitloss.gap(e,frame,i,j); if g then return abs(g)<=K.smartRivalGap end end
 return r.gap<=K.strategyRivalGap*max(K.strategyRivalMinSpeed,a.speed or 0)
end



local function smartUndercut(e,frame,i,j,p)
 local lapTime=Pitloss.lapTimeOf(e,i)
 local gain=nil
 local loss=Wear.lossOf(e.wear,i)
 if loss>0 and lapTime>0 then
  gain=lapTime*(loss-(p.outLapEnabled and p.outLapLevelPct/100 or 0)/max(1,K.strategyUndercutLaps))
  if gain<=0 then return false end
 end
 if Pitloss.rejoin(e.pitloss,e,frame,i)==true then return false end
 return true,Pitloss.gap(e,frame,i,j),gain
end


local function rejoinWait(e,frame,c,a,i,now)
 local lap=a.lap or 0
 if c.rejoinHold==lap then return true end
 if c.rejoinEval==lap or c.rejoinDelay>=K.rejoinDelayMax or c.critical or c.hardTyres or c.room<2 then return false end
 c.rejoinEval=lap
 local traffic,j,gap=Pitloss.rejoin(e.pitloss,e,frame,i)
 if not traffic then return false end
 c.rejoinDelay=c.rejoinDelay+1; c.rejoinHold=lap
 U.log(e.log,now,'INFO',string.format('strategie: %s arret retarde d un tour (trafic a la sortie : %s a %.1f s)',name(a),j>0 and name(frame.cars[j]) or 'une file',gap),i)
 return true
end





local function smartStop(t,e,frame,c,a,i,p,now,neutral,neutralStart,hold,stintLeft,risk)
 local inc=e.incidents
 if neutralStart then c.scCand=true; c.scAt=now+K.scDecideDelay elseif not neutral then c.scCand=false end
 if hold then return end
 if c.scCand and not inc.pitsClosed then
  local saving=Pitloss.neutralSaving(e.pitloss,e,Pitloss.lapTimeOf(e,i))
  local w=c.noTyreStop and -1 or wearUse(t,a)
  local need=c.limit=='fuel' or w>=K.scMinWear*U.clamp(p.strategyTyreWearPct/100,0,1)
  if saving<K.scGainMin or not need then c.scCand=false; return end
  if risk>=K.strategyBoldRisk and stintLeft>K.scStayOutLaps then
   if now<c.scAt then return end
   local ahead,called=0,0
   for j=1,frame.count do
    local b=frame.cars[j]
    if j~=i and b.valid and not b.safetyCar and not b.finished and (b.lap or 0)==(a.lap or 0) and (b.spline or 0)>(a.spline or 0) then
     ahead=ahead+1
     if t.cars[j].wanted or e.commands[j].rulePit or b.pit then called=called+1 end
    end
   end
   if ahead>0 and called/ahead>=K.scStayOutShare then
    c.scCand=false
    U.log(e.log,now,'INFO',string.format('strategie: %s reste en piste sous neutralisation (position en piste)',name(a)),i)
    return
   end
  end
  c.scCand=false
  want(t,e,c,a,i,'neutral',now,string.format('strategie: %s arret sous neutralisation (gain %.0f s)',name(a),saving))
  return
 end
 if not neutral and stintLeft==1 and c.rejoinEval~=(a.lap or 0) and not c.critical then
  c.rejoinEval=a.lap or 0
  local traffic,_,_,behind=Pitloss.rejoin(e.pitloss,e,frame,i)
  if traffic==false and behind<=K.rejoinAhead then want(t,e,c,a,i,c.limit,now,string.format('strategie: %s arret avance (piste libre a la sortie)',name(a))) end
 end
end
local function rivals(t,e,frame,j,now,p)
 local row=e.perception.rows[j]; if not row then return end
 local b=frame.cars[j]
 local sj=e.sanctions and e.sanctions.cars[j]

 if b.safetyCar or b.finished or e.commands[j].penaltyPass or sj and sj.asked and sj.pending~='' or e.states[j].disqualified or e.penalties.ai.dq[j] or t.cars[j].failState==1 then return end

 local pj=e.pits.cars[j]
 if e.commands[j].recover or pj and pj.towedAt and now>=pj.towedAt and now-pj.towedAt<=K.towWindow then return end
 for k=1,row.count do
  local r=row.neighbors[k]; local i=r.index; local a=frame.cars[i]; local c=t.cars[i]
  if a and i~=j and c.planned and not c.reaction and not c.wanted and eligible(a,e.states[i],e,i) and not a.pit
   and abs((a.lap or 0)+(a.spline or 0)-(b.lap or 0)-(b.spline or 0))<K.strategyRivalLap and near(e,frame,i,j,r,a,p) then
   local risk=e.states[i].persona.strategyRisk or 0.5
   local w=wearUse(t,a)

   local owed=mandatoryDue(e,i,p)
   local onlyMandatory=owed and not (c.stops>0 and c.nextLap>=0)
   if r.long<0 and c.stops>0 and w>=0 and w<U.clamp(p.strategyTyreWearPct/100,0,1)*K.strategyOvercutWear then

    c.shift=K.strategyOvercutLaps; c.reaction=true
    U.log(e.log,now,'INFO',string.format('strategie: %s reste dehors (overcut sur %s)',name(a),name(b)),i)
   elseif r.long<0 and onlyMandatory and w>=0 and w<U.clamp(p.strategyTyreWearPct/100,0,1)*K.strategyOvercutWear and not (e.pits.cars[i] and e.pits.cars[i].wanted) then


    c.mandShiftLap=(a.lap or 0)+K.strategyOvercutLaps; c.reaction=true
    U.log(e.log,now,'INFO',string.format('strategie: %s arret obligatoire retarde (overcut sur %s)',name(a),name(b)),i)
   elseif r.long>=0 and (c.stops>0 and c.nextLap>=0 and c.nextLap-(a.lap or 0)<=K.strategyCoverLaps or owed) and risk<K.strategyBoldRisk
    and w>=U.clamp(p.strategyTyreWearPct/100,0,1)*K.strategyCoverWear then

    c.reaction=true
    if onlyMandatory then if earlyInWindow(e) then want(t,e,c,a,i,'cover',now,string.format('strategie: %s arret obligatoire avance (couverture de %s)',name(a),name(b)),true)
    end else want(t,e,c,a,i,'cover',now) end
   end
  end
 end
end


local function outLap(t,e,frame,a,c,i,p,now)
 local inLane=a.pit==true


 local pc=e.pits.cars[i]
 local towed=pc.towedAt~=nil and now>=pc.towedAt and now-pc.towedAt<=K.towWindow
 if a.teleport or towed or inLane and e.incidents.red then c.blockOut=true end

 if inLane and a.inPitBox and (a.kmh or 0)<=K.tyreStopSpeed and (e.profile~='C' or frame.started and (a.lap or 0)>=1) and not e.commands[i].noOutLap then c.boxSeen=true end
 if c.inLane and not inLane then
  if c.boxSeen and not c.blockOut and p.outLapEnabled and p.outLapLevelPct>0 then
   c.outLap=true; c.outFrom=now; c.outLap0=a.lap or 0; c.outEnd=-math.huge
   if now-t.resetAt<K.outLapSummaryTime then t.outCount=t.outCount+1
   else U.log(e.log,now,'INFO',string.format('tour de sortie: %s pneus a chauffer (niveau -%.0f %%)',name(a),p.outLapLevelPct),i) end
  end
  c.boxSeen=false; c.blockOut=false
 elseif not inLane and not a.teleport and not towed then c.blockOut=false end
 c.inLane=inLane
 if not c.outLap then return 1 end
 if not p.outLapEnabled then c.outLap=false; return 1 end

 if not U.finite(c.outEnd) then
  local warm=false
  if a.wearKnown and a.tyreTemp and a.tyreOptimum and (a.tyreOptimum[1] or 0)>0 then
   warm=true
   for w=1,4 do if (a.tyreTemp[w] or 0)<(a.tyreOptimum[w] or 0)-K.outLapTempMargin then warm=false end end
  end
  if (a.lap or 0)>c.outLap0 or warm or now-c.outFrom>=K.outLapMax then c.outEnd=now end
 end
 local drop=p.outLapLevelPct/100
 if U.finite(c.outEnd) then
  local f=(now-c.outEnd)/K.outLapRelease
  if f>=1 then c.outLap=false; return 1 end
  drop=drop*(1-f)
 end
 return 1-drop
end



local kindsHybrid={'leak','battery','overheat','puncture'}
local kindsPlain={'leak','overheat','puncture'}
local function failure(t,e,frame,a,c,i,p,now,seed,racing,cmd)
 local inc=e.incidents
 if c.failState==0 then
  if not (racing and p.failuresEnabled and p.failureRate>0) then return end
  if now<c.failNext then return end
  c.failNext=now+K.failureCheck
  local progress=e.race.progress
  if (a.lap or 0)<1 or progress<0 or progress>=K.failureLateRace or a.pit or inc.red or inc.neutral or (a.kmh or 0)<K.failureMinKmh then return end

  if now-(t.lastFailAt or -math.huge)<K.failureGap then return end
  c.failChecks=c.failChecks+1

  local salt=K.failureSalt+(frame.session or 0)*K.failureSessionSalt
  if U.unit(seed,i,salt+c.failChecks)>=p.failureRate/3600*K.failureCheck then return end
  local kinds=c.kersSeen and kindsHybrid or kindsPlain
  c.failKind=kinds[min(#kinds,floor(U.unit(seed,i,salt+K.counterMax)*#kinds)+1)]
  c.failState=1; c.failAt=now; c.failAsked=false; c.failVisit=e.pits.cars[i].visit; t.lastFailAt=now
  c.failRamp=U.lerp(K.failureRampMin,K.failureRampMax,U.unit(seed,i,salt+K.counterMax+1))
  c.failLoss=p.failureLossPct/100*U.lerp(K.failureLossMin,1,U.unit(seed,i,salt+K.counterMax+2))
  c.failRepair=U.lerp(K.failureRepairMin,K.failureRepairMax,U.unit(seed,i,salt+K.counterMax+3))
  U.log(e.log,now,'INFO',string.format('panne: %s %s (perte %.0f %% sur %.0f s), retour aux stands',name(a),K.failureKindLog[c.failKind] or c.failKind,c.failLoss*100,c.failRamp),i)
  event(t,'failure',name(a),c.failKind)
  t.dirty=true
 end
 if c.failState~=1 or not racing then return end

 local pc=e.pits.cars[i]
 if a.inPitBox and pc.visit~=c.failVisit then
  cmd.pitHold=true
  if now-pc.boxSince>=c.failRepair then
   c.failState=2; t.dirty=true
   U.log(e.log,now,'INFO',string.format('panne: %s reparee aux stands',name(a)),i)
   event(t,'repaired',name(a))
   return
  end
 end
 local f=U.clamp((now-c.failAt)/max(1,c.failRamp),0,1)
 local loss=c.failLoss*f
 cmd.levelScale=cmd.levelScale*(1-loss)
 c.failCeil=max(K.failureThrottleMin,1-loss*K.failureThrottleShare); c.failCeilAt=now
 cmd.throttleLimit=min(cmd.throttleLimit,c.failCeil)
 if racing and now-c.failAt>=K.failurePitDelay and not a.pit and not inc.red and not inc.pitsClosed then
  if not c.wanted then want(t,e,c,a,i,'failure',now) end
  c.failAsked=true
 end
end

function M.update(t,e,frame,now,_dt)
 local p=e.run; local profile=e.profile
 relang(t)
 for i=1,frame.count do local cmd=e.commands[i]; cmd.stratLaps=0; cmd.stratPlanAt=-1 end
 if frame.online or frame.replay then for i=1,frame.count do e.commands[i].stratCalled=false end return end
 local inc=e.incidents
 local racing=profile=='C' and frame.started==true and not frame.finished
 local active=racing and p.strategyEnabled and not inc.red
 local seed=e.runtimeG.seed

 local neutral=inc.neutral and not inc.red
 local neutralStart=neutral and not t.neutralWas; t.neutralWas=neutral

 e.pits.neutral=inc.neutral or inc.red


 local requested=0

 for i=1,frame.count do local a=frame.cars[i]; local c=t.cars[i]; if not a.pit and (e.commands[i].rulePit or c.called and c.wanted or e.commands[i].sanCalled or e.commands[i].slowCalled) then requested=requested+1 end end
 for i=1,frame.count do
  local a=frame.cars[i]; local c=t.cars[i]; local cmd=e.commands[i]; local s=e.states[i]
  local identity=a.identity or a.id or ''
  if c.identity~=identity then
   local fresh=car(); for k,v in pairs(fresh) do c[k]=v end; c.identity=identity; c.failNext=now+K.failureCheck*i/max(1,frame.count)

   c.wearSeen=cmd.wearId or 0
   if t.restored and t.restoredSession==frame.session and t.restored[identity] then c.failState=2 end
  end
  if eligible(a,s,e,i) then
   if (a.kers or 0)>K.kersSeenMin then c.kersSeen=true end


   local visitNow=e.pits.cars[i].visit
   if visitNow~=c.lastVisit then if c.lastVisit>=0 then c.rejoinDelay=0; c.scCand=false end; if c.lastVisit>=0 then c.shift=0; c.reaction=false; c.mandShiftLap=false end; c.lastVisit=visitNow end
   probe(t,e,a,c,i,now)

   if inc.formation then c.lapForm=true end

   if (cmd.wearId or 0)~=c.wearSeen then
    c.wearSeen=cmd.wearId or 0
    local m=e.mistakes.cars[i]
    if (cmd.wearKm or 0)>0 and m then U.log(e.log,now,'INFO',string.format('usure: %s blocage, pneu %s +%.1f km (usure %.0f %%, asymetrie %.0f %%)',name(a),K.wheelNames[(cmd.wearWheel or 0)+1] or '?',cmd.wearKm,(m.lockWear or 0)*100,(m.lockAsym or 0)*100),i) end
   end
   local scale=outLap(t,e,frame,a,c,i,p,now)
   if scale<1 then cmd.levelScale=cmd.levelScale*scale end
   failure(t,e,frame,a,c,i,p,now,seed,racing,cmd)
   if active then


    local retry=not c.planned and now>=c.retryAt
    if ((a.lap or 0)~=c.lap or c.replan or retry) and not a.pit then
     c.replan=false; c.retryAt=now+K.strategyRetry

     local wear=wearOf(a)
     local sameLap=(a.lap or 0)==c.lap
     if not sameLap and c.lap>=0 and (a.lap or 0)==c.lap+1 and c.lapWear>=0 and wear>=c.lapWear and not a.pit and not c.lapForm then
      local rate=wear-c.lapWear
      if rate>0 and rate<K.strategyWearRateMax then c.wearRate=c.wearLaps>0 and c.wearRate+(rate-c.wearRate)*K.strategyWearAlpha or rate; c.wearLaps=c.wearLaps+1 end
     end
     if not sameLap or c.lapWear<0 then c.lap=a.lap or 0; c.lapWear=wear end
     if not sameLap then c.lapForm=false end
     local risk=s.persona.strategyRisk or 0.5
     local before=c.stops
     local left=plan(t,c,e,frame,a,p,i,risk)
     if c.planned and c.stops~=before and now-c.planLoggedAt>=K.strategyPlanLogGap then
      c.planLoggedAt=now

      if c.stops>0 then
       U.log(e.log,now,'INFO',string.format('strategie: %s plan %d arret(s), prochain vers le tour %d (%s), risque %.0f %%',name(a),c.stops,c.nextLap,c.limit=='tyres' and 'pneus' or 'carburant',risk*100),i)
       event(t,'plan',name(a),c.stops,c.nextLap)
      else
       U.log(e.log,now,'INFO',string.format('strategie: %s plan 0 arret(s), aucun arret prevu, risque %.0f %%',name(a),risk*100),i)
       event(t,'plan',name(a),0,-1)
      end
     end


     if p.strategyUndercut and c.planned and not c.reaction and not c.wanted and risk>=K.strategyBoldRisk
      and (c.stops>0 and c.nextLap-(a.lap or 0)<=K.strategyUndercutLaps or mandatoryDue(e,i,p)) then
      local row=e.perception.rows[i]
      local r=row and row.front>0 and row.neighbors[row.front]
      local b=r and frame.cars[r.index]
      local go,gapS,gainS=true,nil,nil
      if b and not b.pit and p.strategySmart then go,gapS,gainS=smartUndercut(e,frame,i,r.index,p) end
      if b and not b.pit and go and near(e,frame,i,r.index,r,a,p) and abs((a.lap or 0)+(a.spline or 0)-(b.lap or 0)-(b.spline or 0))<K.strategyRivalLap then



       c.reaction=true
       if not (c.stops>0 and c.nextLap-(a.lap or 0)<=K.strategyUndercutLaps) then if earlyInWindow(e) then want(t,e,c,a,i,'undercut',now,string.format('strategie: %s arret obligatoire avance (undercut)',name(a)),true) end
       elseif gapS and gainS then want(t,e,c,a,i,'undercut',now,string.format('strategie: %s undercut sur %s (ecart %.1f s, gain estime %.2f s par tour)',name(a),name(b),abs(gapS),gainS))
       else want(t,e,c,a,i,'undercut',now) end
      end
     end
     if left>=0 and left<=K.strategyLastLaps then c.shift=0 end
    end

    if c.planned and not c.wanted and not a.pit then
     local stintLeft=c.nextLap>=0 and c.nextLap-(a.lap or 0) or math.huge


     local pc=e.pits.cars[i]




     local hold=p.mandatoryStops>0 and e.pits.state=='pending' and (e.pits.position or -1)<(e.pits.open or 0) and pc.windowStops<p.mandatoryStops and not c.critical and not c.hardTyres
      and not (p.pitCompoundChange and e.pits.neutralCount==true)


     if c.serving or c.checkAfter then
     elseif c.critical then want(t,e,c,a,i,'fuel',now)
     elseif c.stops>0 and stintLeft<=0 and not hold and p.strategySmart and not mandatoryDue(e,i,p) and rejoinWait(e,frame,c,a,i,now) then

     elseif c.stops>0 and stintLeft<=0 then
      if not hold then want(t,e,c,a,i,c.limit,now)
      elseif not c.deferLogged then c.deferLogged=true; U.log(e.log,now,'INFO',string.format('strategie: %s arret retenu jusqu a l ouverture de la fenetre obligatoire',name(a)),i) end
     elseif neutralStart and not hold and c.stops>0 and stintLeft<=K.strategyNeutralLaps*(0.5+(s.persona.strategyRisk or 0.5)) and not inc.pitsClosed then want(t,e,c,a,i,'neutral',now)
     elseif p.strategySmart and c.stops>0 and not inc.formation and not inc.relaunch then smartStop(t,e,frame,c,a,i,p,now,neutral,neutralStart,hold,stintLeft,s.persona.strategyRisk or 0.5) end
    end
   end

   if c.wanted then
    local pc=e.pits.cars[i]

    if a.pit and (cmd.fuelTarget or -1)>c.stopTarget then c.stopTarget=cmd.fuelTarget end


    local stale=not a.pit and not c.called and c.cause~='failure' and not c.critical
     and (c.cause=='neutral' and not inc.neutral or c.cause=='fuel' and c.noFuelStop or c.cause=='tyres' and c.noTyreStop or c.planned and c.stops==0)

     and not (c.mandatoryReq and mandatoryDue(e,i,p))
    if pc.visit~=c.visit then
     c.wanted=false; c.called=false; c.shift=0; c.reaction=false; c.lap=-1; c.lapWear=-1; c.replan=true
     c.serving=true; c.servedVisit=pc.visit; c.stopCause=c.cause; c.deferLogged=false
    elseif not (active or c.failState==1 and racing) or inc.red then c.wanted=false; c.called=false
    elseif stale then
     c.wanted=false
     U.log(e.log,now,'INFO',string.format('strategie: %s arret retire (plus necessaire)',name(a)),i)
    elseif not a.pit and inc.pitsClosed and not c.critical then

    elseif a.pit or c.called or requested<K.pitConcurrent or c.cause=='failure' or c.critical then
     if not c.called and not a.pit then requested=requested+1 end
     c.called=true
     cmd.rulePit=true
    end
   end



   if c.serving then
    if a.inPitBox and inc.red then c.stopRed=true end
    if a.inPitBox and p.pitTyres and (not inc.red or p.redFlagWork) and (cmd.pitCompound or -1)<0 and e.pits.cars[i].visit==c.servedVisit and (e.pits.cars[i].laneVisit==nil or e.pits.cars[i].laneVisit==c.servedVisit) then cmd.pitCompound=Pits.compound(a,cmd,p,e.pits.cars[i].usedDry,e.pits.cars[i].usedCount) end
    if not a.pit then c.serving=false; c.checkAfter=true; c.checkAt=now+K.strategyCheckDelay end
   end
   if c.checkAfter and now>=c.checkAt and not a.pit then
    c.checkAfter=false
    local w=wearOf(a)
    if c.stopCause~='fuel' and not c.stopRed and not c.noTyreStop and t.wearTrust=='trusted' and c.stopWear>=K.strategyTyreCheckMin and w>=0 and w>c.stopWear-K.lockWearReset then
     c.noTyreStop=true; c.replan=true
     U.log(e.log,now,'INFO',string.format('strategie: %s pneus non changes a l arret (usure %.0f %%) : plus d arret pour les pneus',name(a),w*100),i)
    end


    if (c.stopCause=='fuel' or c.stopTarget>c.stopFuel+K.strategyFuelGainMin) and not c.noFuelStop and c.stopFuel>=0 and (a.fuel or -1)>=0 and a.fuel<c.stopFuel+K.strategyFuelGainMin then
     c.noFuelStop=true; c.replan=true
     U.log(e.log,now,'INFO',string.format('strategie: %s pas de carburant ajoute a l arret : plus d arret pour le carburant',name(a)),i)
    end
   end

   if active and c.planned and c.stops>0 and c.nextLap>=0 then
    local left=lapsLeft(e,frame,a,i)
    local total=(a.lap or 0)+max(0,left)





    local fuelOnly=c.limit=='fuel' and p.pitFuel~='ac' and mandatoryDue(e,i,p)
    if total>0 and not fuelOnly then
     local at=c.nextLap



     if c.limit~='fuel' and p.pitFuel~='ac' and mandatoryDue(e,i,p) then at=max((a.lap or 0)+1,at-(i%(K.planSpreadLaps+1))) end
     cmd.stratPlanAt=at/total
    end
    cmd.stratLaps=max(1,floor(min(left,c.stops>1 and math.ceil(max(1,left)/(c.stops)) or left)))
   end


   if active and c.mandShiftLap and not (c.stops>0 and c.nextLap>=0) and mandatoryDue(e,i,p) then
    local left=lapsLeft(e,frame,a,i)
    local total=(a.lap or 0)+max(0,left)
    if total>0 and left>=0 then cmd.stratPlanAt=c.mandShiftLap/total end
   end
  else
   if c.wanted then c.wanted=false end
   c.called=false; c.serving=false; c.checkAfter=false
  end
  cmd.stratCalled=c.called and c.wanted and not a.pit
 end


 for j=1,frame.count do
  local b=frame.cars[j]; local cj=t.cars[j]
  if active and p.strategyUndercut and b.pit and not cj.rivalLane and b.valid and (b.lap or 0)>=1 then rivals(t,e,frame,j,now,p) end
  cj.rivalLane=b.pit==true
 end

 if not t.outSummary and now-t.resetAt>=K.outLapSummaryTime then
  t.outSummary=true
  if t.outCount>0 then U.log(e.log,now,'INFO',string.format('tour de sortie: %d IA pneus a chauffer au depart des stands (niveau -%.0f %%)',t.outCount,p.outLapLevelPct),-1) end
 end
end


function M.dueWithin(t,i,lap,laps)
 local c=t.cars and t.cars[i]
 return c~=nil and c.planned==true and c.nextLap>=0 and c.nextLap-(lap or 0)<=laps
end
function M.serialize(t,session)
 local rows={tostring(session)}
 for i=1,K.maxCars do local c=t.cars[i]; if c.identity~='' and c.failState>0 and c.identity:match('^[%w_%-]+$') then rows[#rows+1]=c.identity..','..c.failState end end
 if #rows==1 then return '' end
 return table.concat(rows,'\n')
end

function M.restore(t,text,session)
 if type(text)~='string' or #text>K.maxZoneBytes or tonumber(text:match('^(%d+)'))~=session then return end
 t.restored={}; t.restoredSession=session
 for identity,state in text:gmatch('\n([%w_%-]+),(%d+)') do t.restored[identity]=tonumber(state) end
 for i=1,K.maxCars do local c=t.cars[i]; if c.identity~='' and t.restored[c.identity] then c.failState=2 end end
end
return M

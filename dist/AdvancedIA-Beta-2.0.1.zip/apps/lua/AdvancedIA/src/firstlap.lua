











local U=require('src/util')
local K=require('src/config').K
local Zones=require('src/zones')
local max,abs=math.max,math.abs
local M={}
function M.new() return {on=false,forced=false,age=0,kind='',armed=0,why={ligne=0,etire=0,delai=0,stands=0,virage=0},points={},count=0,restartSerial=0} end
function M.reset(fl) fl.on=false; fl.forced=false; fl.age=0; fl.kind=''; fl.armed=0; fl.count=0; for k in pairs(fl.why) do fl.why[k]=0 end end



function M.arm(e,frame,now,kind,force)
 local fl=e.fl
 if not force then
 if not e.run.firstLapCare then return false end
 end
 if e.profile~='C' then return false end
 M.reset(fl); fl.on=true; fl.kind=kind; fl.forced=force==true and not e.run.firstLapCare
 for i=1,frame.count do
  local a=frame.cars[i]; local s=e.states[i]
  s.flOn=false; s.flW=0; s.flCare=0; s.flApproach=false; s.flBrakeWas=false; s.flT1=false
  if a.valid and a.control and not a.player and not a.safetyCar and not a.pit and not a.finished then
   s.flOn=true; s.flW=1; s.flLap=a.lap or 0; s.flAge=0; s.flSpread=0; fl.armed=fl.armed+1
  end
 end
 if fl.armed==0 then fl.on=false; return false end
 U.log(e.log,now,'INFO',string.format('premier tour: mode attentif pour %d IA (%s) : ecart en temps, anticipation des freinages, radar en levee de pied, ni defense ni depassement au freinage',fl.armed,kind),-1)
 return true
end
local function finish(fl,s,why) s.flOn=false; fl.why[why]=fl.why[why]+1 end

local function addPoint(fl,spline,length)
 local merge=K.firstLapPointMerge/max(1,length)
 for j=1,fl.count do if abs(U.spline(fl.points[j]-spline))<=merge then return end end
 if fl.count>=K.firstLapPoints then return end
 fl.count=fl.count+1; fl.points[fl.count]=spline
end


function M.nextPoint(fl,a,length)
 if not a.splineValid or length<=0 then return math.huge end
 local best=math.huge
 for j=1,fl.count do local d=((fl.points[j]-a.spline)%1)*length; if d<best then best=d end end
 if fl.known then local d=Zones.ahead(fl.known,a.spline); if d and d*length<best then best=d*length end end
 return best
end

function M.braking(a,s)
 local own=a.brake>(s.appBrake or 0)+K.brakeEcho and a.brake or 0
 return own>K.ruleBrake
end


function M.freePoint(a,row)
 if not (a.kmh>=K.firstLapPointKmh and (a.cornerYaw or a.corner or 1)>=K.firstLapPointCorner and a.splineValid) then return false end
 for j=1,row.count do local r=row.neighbors[j]; if r.long>0 and abs(r.lat)<=K.latPass and M.headway(r.gap,a.speed)<K.firstLapPointFree then return false end end
 return true
end

function M.headway(gap,speed) return gap/max(speed,K.firstLapSpeedMin) end

function M.update(e,frame,now,dt)
 local fl=e.fl
 if not fl.on then return end
 fl.age=fl.age+dt
 local rows=e.perception.rows
 local alive=false
 for i=1,frame.count do
  local a=frame.cars[i]; local s=e.states[i]
  if s.flOn then
   s.flAge=s.flAge+dt
   if not a.valid or a.pit then finish(fl,s,'stands')
   elseif (a.lap or 0)>s.flLap then
    if s.flAge<K.firstLapLineGrace then s.flLap=a.lap else finish(fl,s,'ligne') end
   elseif s.flAge>=K.firstLapMax then finish(fl,s,'delai')
   elseif fl.forced and s.flT1 then finish(fl,s,'virage')
   elseif fl.forced and s.flAge>=K.rollT1Max then finish(fl,s,'delai')
   else
    local row=rows[i]; local spread=true
    for j=1,row.count do local r=row.neighbors[j]; if r.gap<K.firstLapSpread*max(a.speed,K.firstLapSpeedMin) then spread=false; break end end
    s.flSpread=spread and s.flSpread+dt or 0
    if s.flSpread>=K.firstLapSpreadTime then finish(fl,s,'etire') end
   end
  end
  if not s.flOn and s.flW>0 then s.flW=max(0,s.flW-dt/K.firstLapRelease); if s.flW==0 then s.flApproach=false; s.flCare=0 end end
  if s.flOn or s.flW>0 then
   alive=true


   local braking=M.braking(a,s)
   if braking and not s.flBrakeWas and M.freePoint(a,rows[i]) then addPoint(fl,a.spline,frame.length) end
   if fl.forced and s.flOn and s.flBrakeWas and not braking and s.flAge>=K.rollT1Min then s.flT1=true end
   s.flBrakeWas=braking
  end
 end
 if not alive and fl.forced then
  fl.forced=false; fl.on=false
  U.log(e.log,now,'INFO',string.format('depart lance: fin du premier virage attentif apres %.0f s (%d IA : premier freinage fait %d, delai %d, ligne franchie %d, peloton etire %d, stands %d)',
   fl.age,fl.armed,fl.why.virage,fl.why.delai,fl.why.ligne,fl.why.etire,fl.why.stands),-1)
  return
 end
 if not alive then
  fl.on=false
  U.log(e.log,now,'INFO',string.format('premier tour: fin du mode attentif apres %.0f s (%d IA : ligne franchie %d, peloton etire %d, delai %d, stands %d ; %d point(s) de freinage appris)',
   fl.age,fl.armed,fl.why.ligne,fl.why.etire,fl.why.delai,fl.why.stands,fl.count),-1)
 end
end
return M











local Trackfile=require('src/trackfile')
local M={}
local DF={folder='danger',kind='danger',maxBytes=16384,maxZones=12,lower=3,drop=5,mergeMeters=150,title='AdvancedIA - zones dangereuses du circuit'}
M.DF=DF


function M.new() return {zones={},n=0,key='',loaded=false,dirty=false,lines=0,junction=-1} end

function M.decode(text,track,layout,length)
 local doc,why=Trackfile.parse(text,DF.maxBytes,DF.maxZones)
 if not doc then return nil,why end
 local ok,lengthOK=Trackfile.check(doc,DF.kind,track,layout,length)
 if not ok then return nil,lengthOK end
 if not lengthOK then return {},-1 end
 local out={}
 local junction=Trackfile.number(doc.head.junction,0,1) or -1
 for _,section in ipairs(doc.sections) do
  local v=section.values
  local spline=Trackfile.number(v.spline,0,1)
  local level=Trackfile.integer(v.level,1,2)
  if spline and level then
   out[#out+1]={spline=spline%1,level=level,count=Trackfile.integer(v.count,0,1e6) or 0,sessions=Trackfile.integer(v.sessions,0,1e6) or 0,
    quiet=Trackfile.integer(v.quiet,0,1e6) or 0,kmh=Trackfile.number(v.kmh,0,1000) or 0,date=Trackfile.text(v.date,32) or ''}
  end
 end
 return out,junction
end

function M.encode(t,head)
 local sections={}
 for k=1,t.n do
  local z=t.zones[k]
  sections[k]={name='zone'..k,spline=math.floor(z.spline*1e6+0.5)/1e6,level=z.level,count=z.count,sessions=z.sessions,quiet=z.quiet,
   kmh=math.floor((z.kmh or 0)*10+0.5)/10,date=z.date or ''}
 end
 local h={kind=DF.kind,track=head.track,layout=head.layout,length=head.length,serial=0}
 if (t.junction or -1)>=0 then h.junction=math.floor(t.junction*1e6+0.5)/1e6 end
 return Trackfile.build(DF.title,h,sections)
end


function M.loaded(t,list,key,junction)
 for k=#t.zones,1,-1 do t.zones[k]=nil end
 t.n=0; t.key=key or ''; t.loaded=true; t.junction=junction or -1
 for _,z in ipairs(list or {}) do
  z.sessions=z.sessions+1; z.quiet=z.quiet+1
  if z.quiet>=DF.drop then t.dirty=true
  else
   if z.level>1 and z.quiet>=DF.lower then z.level=1 end
   t.n=t.n+1; t.zones[t.n]=z
   if t.n>=DF.maxZones then break end
  end
 end
 table.sort(t.zones,function(a,b) return a.spline<b.spline end)
 if t.n>0 or (list and #list>0) then t.dirty=true end
 return t.n
end


function M.junctionSeen(t,spline,length)
 if spline<0 or length<=0 then return false end
 if (t.junction or -1)>=0 and math.abs(((spline-t.junction+0.5)%1)-0.5)*length<=DF.mergeMeters then return false end
 t.junction=spline; t.dirty=true
 return true
end


function M.armed(t,spline,length,level,kmh,date)
 if length<=0 then return end
 for k=1,t.n do
  local z=t.zones[k]
  local d=math.abs(((spline-z.spline+0.5)%1)-0.5)*length
  if d<=DF.mergeMeters then
   z.count=math.min(1e6,z.count+1)
   if z.quiet>0 or z.sessions>0 then z.level=2 end
   z.level=math.max(z.level,level or 1); z.quiet=0
   if kmh and kmh>0 then z.kmh=kmh end
   z.date=date or z.date; t.dirty=true
   return z
  end
 end
 if t.n>=DF.maxZones then return nil end
 t.n=t.n+1
 local z={spline=spline%1,level=level or 1,count=1,sessions=0,quiet=0,kmh=kmh or 0,date=date or ''}
 t.zones[t.n]=z; t.dirty=true
 table.sort(t.zones,function(a,b) return a.spline<b.spline end)
 return z
end



function M.cut(t,spline,length,before,after,pct)
 local cut,kmh,at=0,0,0
 if t.n==0 or length<=0 then return 0,0,0 end
 for k=1,t.n do
  local z=t.zones[k]
  local ahead=(((z.spline-spline)+0.5)%1-0.5)*length
  if ahead<=before and ahead>=-after then
   local p=pct[z.level] or pct[1]
   if p>cut then cut=p; kmh=z.kmh or 0; at=ahead end
  end
 end
 return cut,kmh,at
end
return M

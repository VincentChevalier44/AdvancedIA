




local U=require('src/util')
local K=require('src/config').K
local max,min,floor=math.max,math.min,math.floor
local M={}
local function accumulator() return {on=false,kind='',delta=0,last=-1,sector=-1,pit=false} end
function M.new()
 local lists={}; for class=1,K.classMax do lists[class]={} end
 return {course=accumulator(),zone=accumulator(),fleet={},fleetNext=1,bins=K.paceBins,lists=lists,counts={},value=nil,kind='',infraction=false,
  infractionKind='',infractionValue=0,onsetAt=-math.huge,onsetKmh=0,signalAt=-math.huge,signalKmh=0,zoneSlot=0,
  inside=false,wasZone=false}
end
function M.reset(d)
 d.course=accumulator(); d.zone=accumulator(); d.value=nil; d.kind=''; d.infraction=false; d.inside=false; d.wasZone=false
 for _,f in pairs(d.fleet) do for b=1,#f do f[b]=0 end end
end
function M.rebase(d,amount)
 if U.finite(d.onsetAt) then d.onsetAt=d.onsetAt-amount end
 if U.finite(d.signalAt) then d.signalAt=d.signalAt-amount end
end

local function bin(spline,count) count=count or K.paceBins; return min(count,floor((spline%1)*count)+1) end
M.bin=bin




function M.size(d,length)
 local bins=length>0 and U.clamp(math.ceil(length/K.paceBinMeters),K.paceBins,K.paceBinsMax) or K.paceBins
 if bins==d.bins then return false end
 d.bins=bins; d.fleetNext=1; d.fleet={}
 return true
end


function M.refresh(d,frame,states,multi)
 local classes=multi and K.classMax or 1
 local lists,counts=d.lists,d.counts

 for _=1,math.ceil(K.fleetBinsPerFrame*d.bins/K.paceBins) do
  local b=d.fleetNext; d.fleetNext=b%d.bins+1
  for class=1,classes do counts[class]=0 end

  for i=1,frame.count do
   local a=frame.cars[i]; local s=states[i]
   local class=multi and s.class or 1
   if a.valid and not a.player and not a.safetyCar and s.paceCount>=K.paceMinBins then
    local v=s.pace[b]
    if v>0 then

     local list=lists[class]; local count=counts[class]
     local at=count; while at>=1 and list[at]>v do list[at+1]=list[at]; at=at-1 end
     list[at+1]=v; counts[class]=count+1
    end
   end
  end
  for class=1,classes do
   local f=d.fleet[class]
   if not f then f={}; for j=1,d.bins do f[j]=0 end; d.fleet[class]=f end
   local count=counts[class]
   f[b]=count>0 and lists[class][floor(count/2)+1] or 0
  end
 end
end


function M.pace(d,states,i,b,multi)
 local s=states[i]
 local own=s.paceCount>=K.paceMinBins and s.pace[b] or 0
 local f=d.fleet[multi and s.class or 1]

 if s.priorMap then local v=max(own,f and f[b] or 0); if v==0 then v=s.priorMap[b] or 0 end return v end
 return max(own,f and f[b] or 0)
end


function M.reference(d,states,i,b,multi,pct,fallbackKmh)
 local pace=M.pace(d,states,i,b,multi)
 local v=pace>0 and pace/(1+pct/100) or (fallbackKmh or 0)/3.6
 if v<=0 then return 0 end
 return max(K.deltaMinKmh/3.6,v)
end



function M.zoneReference(d,states,i,b,multi,p,fallbackKmh)
 if p.slowZoneKmh>0 then return max(K.deltaMinKmh,p.slowZoneKmh)/3.6 end
 return M.reference(d,states,i,b,multi,p.zoneDeltaPct,fallbackKmh or p.yellowSpeedKmh)
end


local function regime(inc,frame,p,a)

 local pc=frame.player>0 and inc.cars and inc.cars[frame.player]; if pc and pc.scFree==true then return '' end
 if inc.red then if a.pit then return '' end; return 'red',p.redDeltaPct,p.redFlagSpeedKmh end
 if not inc.neutral then return '' end

 if inc.formation then return '' end
 local mode=inc.neutralMode
 if mode=='vsc' then return 'vsc',p.vscDeltaPct,p.fcySpeedKmh end
 if mode=='sc' then
  local merging=inc.safetyPhase=='call' or inc.safety>0 and frame.cars[inc.safety].pit

  if inc.scFinal==true then return 'sc',K.scCatchPct,K.scNominalKmh+K.scCatchUp end
  if merging then return 'scCall',p.fcyDeltaPct,p.fcySpeedKmh end


  return 'sc',K.scCatchPct,K.scNominalKmh+K.scCatchUp
 end
 return 'fcy',p.fcyDeltaPct,p.fcySpeedKmh
end

local chained={scCall=true,sc=true,fcy=true}
local function sectors(length) return U.clamp(floor(length/K.miniSectorLength+0.5),K.miniSectorsMin,K.miniSectorsMax) end


local function advance(acc,a,length,dt,vref,count)
 local crossed=false
 if acc.last>=0 and vref>0 then
  local ds=U.spline(a.spline-acc.last)*length
  if ds>=0 and ds<=K.deltaJump then acc.delta=min(K.deltaCap,acc.delta+dt-ds/vref)
  elseif ds<0 and ds>-K.deltaJump then acc.delta=min(K.deltaCap,acc.delta+dt) end
 end
 acc.last=a.spline
 local s=floor((a.spline%1)*count)
 if acc.sector>=0 and s~=acc.sector then crossed=true end
 acc.sector=s
 return crossed
end

local function brakeFloor(kmh,since,decel) return kmh/3.6-decel*max(0,since-K.penaltyBrakeMargin) end
local function zoneExists(inc,slot)
 for z=1,inc.zoneCount do if inc.zones[z].slot==slot then return true end end
 return false
end

function M.update(d,frame,p,inc,states,now,dt,queued)
 d.infraction=false; d.value=nil; d.kind=''
 local i=frame.player
 if i==0 or frame.length<=0 then d.course.on=false; d.zone.on=false; d.inside=false; d.wasZone=false; return end
 local a=frame.cars[i]
 local multi=p.multiClass==true
 local count=sectors(frame.length)
 local b=bin(a.spline,d.bins)
 local tolerance=p.deltaTolerance

 local c=d.course
 local kind,pct,fallback=regime(inc,frame,p,a)
 if kind~=c.kind then
  if kind=='' then c.on=false
  elseif not (c.on and chained[c.kind] and chained[kind]) then
   c.on=true; c.delta=K.deltaStart; c.last=-1; c.sector=-1; c.pit=false; d.onsetAt=now; d.onsetKmh=a.kmh
  end
  c.kind=kind
 end
 if c.on then
  if a.pit or not a.valid or not a.splineValid then c.pit=true; c.last=-1; c.sector=-1
  else

   if c.pit then c.pit=false; c.delta=K.deltaStart; d.onsetAt=now; d.onsetKmh=a.kmh end
   if kind=='sc' and queued then
    c.delta=max(c.delta,K.deltaStart); c.last=a.spline; c.sector=floor((a.spline%1)*count)
   else
    local vref=M.reference(d,states,i,b,multi,pct,fallback)
    if kind=='scCall' then vref=min(vref,(K.scNominalKmh-K.scMergeMargin)/3.6) end
    vref=max(vref,brakeFloor(d.onsetKmh,now-d.onsetAt,p.yellowDecel))
    if advance(c,a,frame.length,dt,vref,count) and c.delta<-tolerance then
     d.infraction=true; d.infractionKind=kind; d.infractionValue=c.delta
    end
   end
  end
 end


 local z=d.zone

 if inc.formation and not inc.red then
  z.on=false; d.inside=false; d.wasZone=inc.playerZone
  if c.on and not c.pit then d.value=c.delta; d.kind=c.kind end
  return
 end
 if inc.playerZone and not d.wasZone then d.signalAt=now; d.signalKmh=a.kmh end
 d.wasZone=inc.playerZone
 local inside=inc.playerInside and not a.pit and a.valid and a.splineValid
 if inside and not d.inside then
  d.zoneSlot=inc.playerZoneSlot
  if inc.playerZoneDouble then z.on=true; z.kind='zone'; z.delta=0; z.last=-1; z.sector=-1 end
 elseif inside and not z.on and inc.playerZoneDouble then


  d.signalAt=now; d.signalKmh=a.kmh; z.on=true; z.kind='zone'; z.delta=0; z.last=-1; z.sector=-1
 elseif not inside and d.inside then

  if z.on and zoneExists(inc,d.zoneSlot) and z.delta<-tolerance and not d.infraction then
   d.infraction=true; d.infractionKind='zone'; d.infractionValue=z.delta
  end
  z.on=false
 end
 d.inside=inside

 if inside and inc.playerZoneSlot>0 then d.zoneSlot=inc.playerZoneSlot end
 if z.on then
  local vref=M.zoneReference(d,states,i,b,multi,p)
  vref=max(vref,brakeFloor(d.signalKmh,now-d.signalAt,p.yellowDecel))
  if advance(z,a,frame.length,dt,vref,count) and z.delta<-tolerance and not d.infraction then
   d.infraction=true; d.infractionKind='zone'; d.infractionValue=z.delta
  end
  d.value=z.delta; d.kind='zone'
 elseif c.on and not c.pit then d.value=c.delta; d.kind=c.kind end
end

function M.penalized(d)
 d.course.delta=max(d.course.delta,K.deltaStart); d.zone.delta=max(d.zone.delta,K.deltaStart)
end
return M

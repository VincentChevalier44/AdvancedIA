
















local U=require('src/util')
local K=require('src/config').K
local Antics=require('src/antics')
local max=math.max
local M={}







local GK={stillMax=10,lightsMargin=0.5,creepZone=25,creepKmh=5,creepSpread=25,stillMaxGuarded=40,waitFirstGuarded=30,





 stallGuarded=20,fillGuarded=60,missMax=6,fillTarget=20,


 approachKmh=120,approachDecel=2.5,

 movingKmh=3}
M.GK=GK








M.retireGuard=false
local function stillMax() return M.retireGuard and GK.stillMaxGuarded or GK.stillMax end
function M.new()
 return {phase='none',slots={},slotOf={},held={},pit={},order={},source='',since=0,lightsAt=0,outAt=0,goUntil=-math.huge,
  ref=0,refSet=false,jump=false,count=0,heldCount=0,nodes=nil,timedOut=false,woke=false,aiRef={},aiJump={},aiJumpAt={},



  aiRelease={},aiReleased={},aiJumpGrade={},realism=false,jumpMoved=0,jumpKmh=0,jumpLead=0,jumpSlot=0,


  heldAt={},lost={},firstHeldAt=nil,burstDone={},burstUntil={},


  from='',

  hit={}}
end
local function clearCars(g) for i=1,K.maxCars do g.slotOf[i]=0; g.held[i]=false; g.pit[i]=false; g.aiRef[i]=nil; g.aiJumpAt[i]=nil; g.aiRelease[i]=nil; g.aiReleased[i]=nil; g.heldAt[i]=nil; g.lost[i]=nil; g.burstDone[i]=nil; g.burstUntil[i]=nil end; g.firstHeldAt=nil; g.lastHeldAt=nil; g.aiReadyAt=nil end
local function clearPlayer(t) t.gridPlaced=false; t.gridPassed=false end
function M.reset(g)
 g.guardLogged=false; g.phase='none'; g.source=''; g.since=0; g.lightsAt=0; g.outAt=0; g.goUntil=-math.huge; g.ref=0; g.refSet=false; g.jump=false
 g.count=0; g.heldCount=0; g.timedOut=false; g.movingAt=nil; clearCars(g)
 for i=1,K.maxCars do g.aiJump[i]=nil; g.aiJumpAt[i]=nil end
 for i=1,K.maxCars do g.aiJumpGrade[i]=nil end
 g.jumpGrade=nil; g.jumpMoved=0; g.jumpKmh=0; g.jumpLead=0; g.jumpSlot=0; g.jumpLaunchAt=nil
 g.from=''
end
function M.rebase(g,amount)
 g.since=g.since-amount; g.lightsAt=g.lightsAt-amount; g.outAt=g.outAt-amount
 if U.finite(g.goUntil) then g.goUntil=g.goUntil-amount end

 for i=1,K.maxCars do if g.aiJumpAt[i] then g.aiJumpAt[i]=g.aiJumpAt[i]-amount end end

 if g.firstHeldAt then g.firstHeldAt=g.firstHeldAt-amount end
 if g.lastHeldAt then g.lastHeldAt=g.lastHeldAt-amount end
 if g.aiReadyAt then g.aiReadyAt=g.aiReadyAt-amount end
 if g.movingAt then g.movingAt=g.movingAt-amount end
 for i=1,K.maxCars do if g.heldAt[i] then g.heldAt[i]=g.heldAt[i]-amount end; if g.burstUntil[i] then g.burstUntil[i]=g.burstUntil[i]-amount end end
end


local sortCars
local function byPosition(x,y)
 local px,py=sortCars[x].position or 0,sortCars[y].position or 0
 if px<1 then px=math.huge end; if py<1 then py=math.huge end
 if px~=py then return px<py end
 return x<y
end
local sortRank
local function byRank(x,y)
 local rx,ry=sortRank[x],sortRank[y]
 if rx and ry then return rx<ry end
 if rx or ry then return rx~=nil end
 return byPosition(x,y)
end
function M.sortByRank(list,n,cars,rank)
 for k=#list,n+1,-1 do list[k]=nil end
 sortCars=cars; sortRank=rank; table.sort(list,byRank); sortCars=nil; sortRank=nil
end
function M.sortByPosition(list,n,cars)
 for k=#list,n+1,-1 do list[k]=nil end
 sortCars=cars; table.sort(list,byPosition); sortCars=nil
end










function M.before(spline,length)
 local d=((-spline)%1)*length
 if d>length*0.5 then d=d-length end
 return d
end
local function refused(k,before,lat,last)
 if not before then return string.format('noeud %d incoherent : abscisse inconnue',k) end
 if before>K.gridNodeRange then return string.format('noeud %d incoherent : %.0f m avant la ligne',k,before) end
 if before<-K.gridNodeAfter then return string.format('noeud %d incoherent : %.0f m apres la ligne',k,-before) end
 if before<last-K.gridSideBySide then return string.format('noeud %d incoherent : devant le precedent',k) end
 return string.format('noeud %d incoherent : lateral %s',k,U.finite(lat) and string.format('%.2f',lat) or 'inconnu')
end
function M.resolve(nodes,length,count,out)
 if not U.finite(length) or length<=0 or count<1 then return nil,'','' end
 out=out or {}
 local why='aucun noeud'
 if type(nodes)=='table' and #nodes>=count then
  local good=true; local last=-math.huge
  for k=1,count do
   local n=nodes[k]; local before=U.finite(n.spline) and M.before(n.spline,length) or nil
   if not (before and before<=K.gridNodeRange and before>=-K.gridNodeAfter and before>=last-K.gridSideBySide and U.finite(n.lateral) and math.abs(n.lateral)<=K.gridNodeLatMax) then
    good=false; why=refused(k,before,n.lateral,last); break
   end
   last=math.max(last,before)
  end
  if good then
   for k=1,count do local s=out[k] or {}; out[k]=s; s.spline=nodes[k].spline; s.lateral=U.clamp(nodes[k].lateral,-K.gridLatClamp,K.gridLatClamp) end
   for k=#out,count+1,-1 do out[k]=nil end
   return out,'AC_START',''
  end
 elseif type(nodes)=='table' then why=string.format('%d noeuds pour %d voitures',#nodes,count) end
 for k=1,count do
  local s=out[k] or {}; out[k]=s
  s.spline=((-(K.gridFirst+(k-1)*K.gridPitch))/length)%1; s.lateral=k%2==1 and -K.gridColumn or K.gridColumn
 end
 for k=#out,count+1,-1 do out[k]=nil end
 return out,'calculees',why
end


local function toBack(g,t,frame,order,n,rank,bySince,now,log)
 local back=g.back or {}; g.back=back; local nb=0; local keep=0
 for k=1,n do
  local i=order[k]; local ri=rank[i]; local pi=frame.cars[i].position or 0; local lost=false
  local ci=t.cars and t.cars[i]; local delayed=ci~=nil and (ci.abortMark or bySince and (ci.since or 0)~=0 and (ci.since or 0)>=(t.formationAt or math.huge))
  if ri and pi>=1 and delayed then
   for m=1,n do local j=order[m]; local rj=rank[j]; local pj=frame.cars[j].position or 0; if rj and rj>ri and pj>=1 and pj<pi and (ci.abortMark or not frame.cars[j].player) then lost=true; break end end
  end
  if lost then nb=nb+1; back[nb]=i else keep=keep+1; order[keep]=i end
 end
 for m=1,nb do local i=back[m]; order[keep+m]=i; U.log(log,now,'INFO',string.format('grille: %s part de l arriere de la grille (%s)',frame.cars[i].name,t.cars[i].abortMark and 'depart avorte' or 'place perdue pendant le tour de formation'),i) end
 g.backN=nb
end



local function redBack(t,back,nb)
 local N=t.redOrderN or 0; local k=0
 for r=1,N do
  local i=t.redOrder[r]; local out=false
  for m=1,nb do if back[m]==i then out=true; break end end
  if i and not out then k=k+1; t.redOrder[k]=i end
 end
 for m=1,nb do local i=back[m]; if t.redRank[i] then k=k+1; t.redOrder[k]=i end end
 for r=1,k do t.redRank[t.redOrder[r]]=r end
end


function M.start(g,t,frame,now,log)
 clearCars(g); clearPlayer(t)
 local from=t.startAbortFrom; t.startAbortFrom=nil
 if g.hit then for i=1,K.maxCars do g.hit[i]=nil end end
 local order=g.order; local n=0
 for i=1,frame.count do
  local a=frame.cars[i]
  if a.valid and not a.finished and not a.safetyCar and (a.control or a.player) then
   if a.pit then g.pit[i]=true elseif a.splineValid then n=n+1; order[n]=i end
  end
 end

 if (t.redOrderN or 0)>0 then M.sortByRank(order,n,frame.cars,t.redRank)

  if (t.abortMarks or 0)>0 then toBack(g,t,frame,order,n,t.redRank,false,now,log) end
  if (t.abortMarks or 0)>0 and (g.backN or 0)>0 then redBack(t,g.back,g.backN) end
 elseif (t.formationRankN or 0)>0 and t.formationRank then




  M.sortByRank(order,n,frame.cars,t.formationRank)
  toBack(g,t,frame,order,n,t.formationRank,true,now,log)
  t.formationRankN=0
 else M.sortByPosition(order,n,frame.cars) end


 if (t.abortMarks or 0)>0 and t.cars then for i=1,#t.cars do local c=t.cars[i]; if c.abortMark then c.lastCrash=-math.huge end; c.abortMark=false; c.abortHold=false end; t.abortMarks=0; t.abortHolds=0 end
 local slots,source,why=M.resolve(g.nodes,frame.length,n,g.slots)
 if not slots then return false end
 g.slots=slots; g.source=source
 for k=1,n do g.slotOf[order[k]]=k end
 g.phase='grid'; g.since=now; g.count=n; g.heldCount=0; g.jump=false; g.refSet=false; g.timedOut=false
 g.jumpGrade=nil; g.jumpMoved=0; g.jumpKmh=0; g.jumpLead=0; g.jumpSlot=0; g.jumpLaunchAt=nil
 t.standing='grid'
 g.from=from or ''
 U.log(log,now,'INFO',string.format('grille: formation, %d voitures, %s',n,source=='AC_START' and string.format('%d places (AC_START)',#g.nodes) or 'places calculees ('..why..')'),-1)
 return true
end


local function gap(g,frame,i)
 local s=g.slots[g.slotOf[i]]
 if not s then return 0 end
 local ahead=((s.spline-frame.cars[i].spline)%1)*frame.length
 local past=frame.length-ahead
 if ahead>0 and past<=K.gridOvershoot then return -past end
 return ahead
end
M.gap=gap



local function approach(g,frame,i,cmd,offsetSign,still,now)
 local a=frame.cars[i]; local d=gap(g,frame,i)
 if not g.held[i] and (still or d<=K.gridHoldDistance or a.kmh<K.gridStillKmh and d<=K.gridSlotRadius) then
  g.held[i]=true; g.heldCount=g.heldCount+1; g.heldAt[i]=now; if now and not g.firstHeldAt then g.firstHeldAt=now end; if now then g.lastHeldAt=now end
 end
 cmd.noRetire=true
 local cap=M.retireGuard and U.clamp(math.sqrt(2*GK.approachDecel*math.max(0,d-K.gridHoldDistance))*3.6,K.gridCrawlKmh,GK.approachKmh)
  or U.clamp(math.sqrt(2*K.gridApproachDecel*math.max(0,d-K.gridHoldDistance))*3.6,K.gridCrawlKmh,K.gridApproachKmh)



 if g.realism and now and not g.held[i] and not g.burstDone[i] and d<=K.formBurstFrom and d>=K.formBurstTo then g.burstDone[i]=true; g.burstUntil[i]=now+K.formBurstTime end
 if g.realism and now and now<(g.burstUntil[i] or -math.huge) and not g.held[i] then cap=math.min(cap+K.formBurstKmh,math.sqrt(2*K.formBurstDecel*math.max(0,d-K.gridHoldDistance))*3.6) end

 if g.creep and not g.held[i] and d<=GK.creepZone and d>K.gridHoldDistance then cap=math.min(cap,GK.creepKmh) end
 cmd.speedLimit=math.min(cmd.speedLimit or K.unlimitedSpeed,g.held[i] and K.gridCrawlKmh or cap)
 if g.held[i] then cmd.stopHold=true
 elseif d<K.gridBrakeFrom and a.kmh>cmd.speedLimit+K.gridBrakeMargin then cmd.brake=math.max(cmd.brake or 0,U.clamp((a.kmh-cmd.speedLimit)/K.gridBrakeScale,K.gridBrakeMin,K.brakeMax)) end

 if d<K.gridColumnFrom then local lat=g.slots[g.slotOf[i]].lateral; cmd.offset=offsetSign<0 and -lat or lat end
end


local function pitStarter(a,cmd)
 if a.player or not a.valid then return end
 cmd.noRetire=true
 if a.pit then cmd.pitHold=true else cmd.stopHold=true; cmd.speedLimit=math.min(cmd.speedLimit or K.unlimitedSpeed,K.gridCrawlKmh) end
end


local function release(g,frame,commands,offsetSign,states)
 for i=1,frame.count do
  if g.slotOf[i]>0 or g.pit[i] then commands[i].gridWake=true; g.woke=true end
  commands[i].noRetire=false -- Affinage 1.63 : protection levée à l'extinction (ou à l'annulation)
  local k=g.slotOf[i]; local s=states and states[i]


  if k>0 and s and not frame.cars[i].player and g.slots[k] and g.held[i] and not frame.cars[i].pit and gap(g,frame,i)<K.gridColumnFrom then
   local lat=g.slots[k].lateral; local o=offsetSign<0 and -lat or lat
   s.offset=o; s.filtered=o; s.velocity=0; commands[i].offset=o
  end
 end
 clearCars(g)
end


local function expected(g,frame,dq)
 local n,held=0,0
 for i=1,frame.count do
  if g.slotOf[i]>0 then
   local a=frame.cars[i]
   if not a.player and a.valid and not a.pit and not g.lost[i] and not (dq and dq[i]) then n=n+1; if g.held[i] then held=held+1 end end
  end
 end
 return n,held
end



local function lostCars(g,frame,now,log)
 for i=1,frame.count do
  if g.slotOf[i]>0 and not g.pit[i] and not g.lost[i] then
   local a=frame.cars[i]
   if not a.player and a.valid and a.pit then
    g.lost[i]=true; g.pit[i]=true
    U.log(log,now,'WARN',string.format('grille: %s ramenee aux stands par AC (%s), part de la voie des stands',a.name,g.heldAt[i] and string.format('a l arret depuis %.0f s',now-g.heldAt[i]) or 'pas encore en place'),i)
   end
  end
 end
end


local function early(g,frame,i,commands,now,log)
 local lead=g.aiRelease[i]
 if not lead or now<g.outAt-lead then return false end
 if not g.aiReleased[i] then
  g.aiReleased[i]=true; commands[i].gridWake=true; g.woke=true
  if not g.aiJump[i] then
   g.aiJump[i]=true; g.aiJumpGrade[i]=Antics.grade(0,0,g.outAt-now,false,true)
   U.log(log,now,'WARN',string.format('faux depart IA: %s, %s (%.1f m, %.1f s avant l extinction)',frame.cars[i].name,g.aiJumpGrade[i]=='flagrant' and 'faux depart flagrant' or 'faux depart',0,g.outAt-now),i)
  end
 end
 return true
end

local function firstStill(g,frame)
 local first=nil
 for i=1,frame.count do
  local at=g.heldAt[i]
  if at and g.held[i] and g.slotOf[i]>0 and not g.lost[i] and not frame.cars[i].pit and not frame.cars[i].player and (not first or at<first) then first=at end
 end
 return first
end
M.firstStill=firstStill

local function farthest(g,frame,dq)
 local far=0
 for i=1,frame.count do
  local a=frame.cars[i]
  if g.slotOf[i]>0 and not g.held[i] and not a.player and a.valid and not a.pit and not g.lost[i] and not (dq and dq[i]) then local d=gap(g,frame,i); if d>far then far=d end end
 end
 return far
end

function M.rolling(g,frame,dq)
 for i=1,frame.count do
  local a=frame.cars[i]
  if g.slotOf[i]>0 and not g.held[i] and not a.player and a.valid and not a.pit and not g.lost[i] and not (dq and dq[i]) and (a.kmh or 0)>GK.movingKmh then return true end
 end
 return false
end

local missBuf={}
function M.missing(g,frame,now,log,dq)
 local m=0; local total=0
 for i=1,frame.count do
  local a=frame.cars[i]
  if g.slotOf[i]>0 and not g.held[i] and not a.player and a.valid and not a.pit and not g.lost[i] and not (dq and dq[i]) then
   total=total+1
   if m<GK.missMax then m=m+1; missBuf[m]=string.format('%s (place %d, %.0f m, %.0f km/h)',a.name,g.slotOf[i],gap(g,frame,i),a.kmh or 0) end
  end
 end
 for k=#missBuf,m+1,-1 do missBuf[k]=nil end
 if total>0 then U.log(log,now,'INFO',string.format('grille: %d IA pas en place aux feux : %s%s',total,table.concat(missBuf,', '),total>m and ', ...' or ''),-1) end
end
local function placedPlayer(g,frame,player)
 local a=frame.cars[player]
 return math.abs(gap(g,frame,player))<=K.gridSlotRadius and a.kmh<K.gridStillKmh
end


function M.abortMarks(g,t,frame)
 t.startAborts=(t.startAborts or 0)+1; t.startAbortPending=g.from; t.abortMarks=0
 for i=1,frame.count do
  local c=t.cars[i]; c.abortSlot=g.slotOf[i] or 0
  if c.since>=g.since and c.incident then c.abortMark=true; t.abortMarks=t.abortMarks+1 end

  if c.abortMark and g.hit and g.hit[i] then c.abortMark=false; t.abortMarks=t.abortMarks-1 end


  if not c.abortMark and (c.lastCrash or -math.huge)>=g.since then c.lastCrash=-math.huge end
 end
end


local function passed(t,frame,i)
 local pi=frame.cars[i].position or 0; local si=t.cars[i].abortSlot or 0
 if pi<1 or si<=0 then return false end
 for j=1,frame.count do
  local b=frame.cars[j]; local cj=t.cars[j]
  if j~=i and not cj.abortMark and (cj.abortSlot or 0)>si and b.valid and not b.pit and not b.finished and (b.position or 0)>pi then return false end
 end
 return true
end



function M.holdBack(g,t,frame,commands,now,log)
 local n=0; local live=t.neutral and t.relaunch and not t.red
 for i=1,frame.count do
  local c=t.cars[i]
  if c.abortHold then
   local a=frame.cars[i]; local why=nil
   if not live or not a.valid or a.pit or a.finished then why='retenue annulee'
   elseif passed(t,frame,i) then why='peloton passe'
   elseif not c.incident then why='incident termine'
   elseif now-c.abortHoldAt>=(M.retireGuard and K.startBackHold or K.startBackHoldBare) then why='attente maximale' end



   if why=='attente maximale' and c.abortTraffic and now-c.abortHoldAt<(M.retireGuard and K.gridMax or K.startBackHoldBareMax) then why=nil end
   if why then
    c.abortHold=false
    if a.valid and not a.pit then commands[i].gridWake=true; g.woke=true end

    if a.valid and not a.pit then commands[i].recover=false; c.still=0; c.stuckFor=0; c.anchorX=a.x; c.anchorZ=a.z end
    U.log(log,now,'INFO',string.format('depart retarde: %s repart derriere le peloton apres %.0f s (%s)',a.name,now-c.abortHoldAt,why),i)
   else
    local cmd=commands[i]; n=n+1
    cmd.noRetire=true; cmd.stopHold=true; cmd.recover=false; cmd.speedLimit=math.min(cmd.speedLimit or K.unlimitedSpeed,K.gridCrawlKmh)
   end
  end
 end
 t.abortHolds=n
end


function M.step(g,t,frame,now,commands,offsetSign,seed,log,states,dq)

 if g.woke then for i=1,K.maxCars do commands[i].gridWake=false end; g.woke=false end

 for i=1,K.maxCars do commands[i].noRetire=false end

 if (t.abortHolds or 0)>0 then M.holdBack(g,t,frame,commands,now,log) end
 if t.standing=='none' then if g.phase~='none' then M.reset(g); clearPlayer(t) end; return nil end
 if t.standing=='grid' and g.phase=='none' and not M.start(g,t,frame,now,log) then
  t.standing='none'; t.greenUntil=now+K.greenShow; U.log(log,now,'INFO','relance arretee indisponible (grille): depart lance',-1); return nil
 end
 local player=frame.player

 if g.phase=='grid' or g.phase=='lights' then

  local hit=g.hit; if hit then for i=1,frame.count do if g.held[i] and (frame.cars[i].collidedWith or -1)>=1 then hit[i]=true end end end
  for i=1,frame.count do
   local c=t.cars[i]
   if c.incident and c.since>=g.since then
    U.log(log,now,'INFO','depart arrete annule: nouvel incident',i)
    if g.from~='' and not t.red then M.abortMarks(g,t,frame) end
    release(g,frame,commands,offsetSign,states); M.reset(g); t.standing='none'; t.gridLit=0; clearPlayer(t); return nil
   end
  end
 end
 local slotted=player>0 and g.slotOf[player]>0 and not g.pit[player]
 if g.phase=='grid' then
  local timeout=now-g.since>=K.gridMax
  lostCars(g,frame,now,log)
  g.creep=not M.retireGuard and farthest(g,frame,dq)>GK.creepSpread
  for i=1,frame.count do
   local a=frame.cars[i]
   if g.slotOf[i]>0 and not a.player and a.valid and not a.pit and not g.lost[i] then approach(g,frame,i,commands[i],offsetSign,timeout,now)
   elseif g.pit[i] then pitStarter(a,commands[i]) end
  end
  local n,held=expected(g,frame,dq)

  if not g.guardLogged then g.guardLogged=true; U.log(log,now,'INFO',string.format(M.retireGuard and 'grille: %d IA protegees du renvoi aux stands, tenue sans limite de temps' or 'grille: %d IA sans protection du renvoi aux stands, attente bornee',n),-1) end
  if timeout and not g.timedOut then g.timedOut=true; U.log(log,now,'INFO',string.format('grille: delai maximal, %d IA retenues sur place',n-held),-1) end
  local placed=not slotted or frame.cars[player].pit or placedPlayer(g,frame,player)






  if M.retireGuard and M.rolling(g,frame,dq) then g.movingAt=now end
  local stallFrom=M.retireGuard and g.lastHeldAt~=nil and max(g.lastHeldAt,g.movingAt or g.lastHeldAt) or g.lastHeldAt
  local waited=stallFrom~=nil and now-stallFrom>=(M.retireGuard and GK.stallGuarded or K.gridWaitMax) or g.firstHeldAt~=nil and now-g.firstHeldAt>=(M.retireGuard and GK.fillGuarded or K.gridWaitFirstMax)



  local aiReady=held>=n or waited
  if aiReady and not g.aiReadyAt then g.aiReadyAt=now end
  local playerLate=aiReady and not placed and g.aiReadyAt~=nil and now-g.aiReadyAt>=K.gridPlayerWait

  local seq=K.lightStep*(K.gridLights-1)+K.lightsOutMin
  local first=firstStill(g,frame)

  local due=not M.retireGuard and first~=nil and now-first>=stillMax()-seq-GK.lightsMargin
  if aiReady and (placed or playerLate) or due or timeout then
   if not timeout and not (placed and held>=n) then
    U.log(log,now,'INFO',string.format('grille: feux apres %.0f s de grille, premiere IA immobile depuis %.1f s (%d / %d IA en place%s)',now-g.since,first and now-first or 0,held,n,placed and '' or ', joueur pas en place'),-1)
   end
   g.phase='lights'; g.lightsAt=now; t.standing='lights'; g.creep=false

   g.outAt=now+K.lightStep*(K.gridLights-1)+K.lightsOutMin+U.unit(seed or 0,(t.reds or 0)+(t.startAborts or 0)*K.startAbortSalt,K.lightsOutSalt)*(K.lightsOutMax-K.lightsOutMin)

   if first and not M.retireGuard then g.outAt=max(now+seq,math.min(g.outAt,first+stillMax())) end
   if held<n then M.missing(g,frame,now,log,dq) end
   U.log(log,now,'INFO',string.format('feux: allumage (%d / %d IA en place)',held,n),-1)
  end
 end
 if g.phase=='lights' then
  lostCars(g,frame,now,log)

  if now>=g.outAt then
   U.log(log,now,'INFO',string.format('feux eteints apres %.1f s: depart',now-g.lightsAt),-1)

   if g.realism then
    local pa=player>0 and frame.cars[player] or nil


    local lead=g.jump and g.jumpLaunchAt and g.outAt-g.jumpLaunchAt or 0
    local grade=Antics.grade(g.jumpMoved,g.jumpKmh,lead,pa~=nil and pa.kmh<K.gridStillKmh,g.jump)
    g.jumpGrade=grade~='none' and grade or nil
   else g.jumpGrade=g.jump and 'jump' or nil end
   g.jumpSlot=player>0 and g.slotOf[player] or 0
   local jumped=g.jump
   release(g,frame,commands,offsetSign,states); g.phase='go'; g.goUntil=now+K.goShow; t.standing='go'; t.gridLit=0; t.greenUntil=now+K.greenShow
   clearPlayer(t)
   return jumped and 'jump' or 'go'
  end
  for i=1,frame.count do
   local a=frame.cars[i]
   if g.slotOf[i]>0 and not a.player and a.valid and not a.pit and not g.lost[i] then


    if not early(g,frame,i,commands,now,log) then approach(g,frame,i,commands[i],offsetSign,gap(g,frame,i)<=K.gridLateRoll,now) end


    if g.held[i] and a.splineValid and not g.aiJump[i] then
     local ref=g.aiRef[i]
     if not ref then if a.kmh<K.gridStillKmh then g.aiRef[i]=a.spline end
     else
      local moved=U.spline(a.spline-ref)*frame.length


      local moving=moved>math.max(K.jumpDistance,K.aiJumpMinMove) or a.kmh>K.jumpSpeed and moved>K.aiJumpMinMove
      if not moving then g.aiJumpAt[i]=nil elseif not g.aiJumpAt[i] then g.aiJumpAt[i]=now end
      if moving and now-g.aiJumpAt[i]>=K.aiJumpDwell then g.aiJump[i]=true; U.log(log,now,'WARN',string.format('faux depart IA: %s, %.1f m, %.0f km/h, %.1f s avant l extinction',a.name,moved,a.kmh,g.outAt-now),i) end


      if g.realism and g.aiJump[i]==true and not g.aiJumpGrade[i] then g.aiJumpGrade[i]=Antics.grade(moved,a.kmh,a.kmh>K.jumpSpeed and g.outAt-now or 0,false,true) end
     end
    end
   elseif g.pit[i] then pitStarter(a,commands[i]) end
  end
  t.gridLit=math.min(K.gridLights,1+math.floor((now-g.lightsAt)/K.lightStep))


  local a=slotted and frame.cars[player] or nil
  if a and a.valid and not a.pit and a.splineValid and (not g.jump or g.realism) then
   if not g.refSet then
    if placedPlayer(g,frame,player) then g.ref=a.spline; g.refSet=true



    elseif g.phase=='lights' and now<g.outAt and gap(g,frame,player)<=0 and a.kmh>K.jumpSpeed then
     g.ref=a.spline; g.refSet=true; g.jump=true; g.jumpLead=g.outAt-now
     if g.realism then g.jumpMoved=max(g.jumpMoved,K.jumpDistance+1); g.jumpKmh=max(g.jumpKmh,a.kmh); g.jumpLaunchAt=g.jumpLaunchAt or now end
     U.log(log,now,'WARN',string.format('faux depart du joueur: %.1f m, %.0f km/h, %.1f s avant l extinction',-gap(g,frame,player),a.kmh,g.outAt-now),player)
    end
   else
    local moved=U.spline(a.spline-g.ref)*frame.length
    if g.realism then g.jumpMoved=max(g.jumpMoved,moved); g.jumpKmh=max(g.jumpKmh,a.kmh); if a.kmh>K.jumpSpeed and not g.jumpLaunchAt and now<g.outAt then g.jumpLaunchAt=now end end
    if g.jump then -- déjà relevé : seule l'avance est encore suivie (grade jugé à l'extinction)
    elseif moved>K.jumpDistance or a.kmh>K.jumpSpeed and moved>0 then g.jump=true; g.jumpLead=g.outAt-now; U.log(log,now,'WARN',string.format('faux depart du joueur: %.1f m, %.0f km/h, %.1f s avant l extinction',moved,a.kmh,g.outAt-now),player) end
   end
  end
 end
 if g.phase=='go' and now>=g.goUntil then g.phase='none'; t.standing='none' end

 if (g.phase=='grid' or g.phase=='lights') and player>0 then
  local k=g.slotOf[player]
  t.gridSlot=k; t.gridPit=k==0 or g.pit[player] or frame.cars[player].pit==true
  local d=k>0 and gap(g,frame,player) or 0

  local back=d<0 and -d or 0
  if k>0 and d>0 and frame.length-d<=K.gridPassedShow then back=frame.length-d end
  t.gridPlaced=k>0 and not t.gridPit and placedPlayer(g,frame,player)
  t.gridPassed=k>0 and not t.gridPit and back>K.gridSlotRadius
  local shown=t.gridPassed and back or math.max(0,d)
  t.gridGap=shown<K.gridGapFine and math.floor(shown) or math.floor(shown/K.gridGapStep+0.5)*K.gridGapStep
 end
 return nil
end
return M



local C=require('src/config')
local K=C.K
local P=require('src/perception')
local Delta=require('src/delta')
local Incidents=require('src/incidents')
local abs,max=math.abs,math.max
local M={}
function M.new()
 return {lastAt=-math.huge,requestId=0,seconds=0,reason='',count=0,ahead={},regime=false,passedUnder=false,passMade=false,
  redBefore=false,redPending=false,stopPending=false,jumpPending=false,waiting={},regimeAt=-math.huge,whole=false,wholeAt=-math.huge,giveBack=0,giveBackUntil=0,deltaKind='',deltaValue=0,passed=0,kind='slow',disqualified=false,
  ai={count={},slowUntil={},slowKmh={},slowFrom={},slowAt={},dq={},ahead={},regime={},passed={},lastAt={},waiting={},giveBack={},giveFrom={},giveAt={},owe={},oweUntil={},oweLate={},notes={}},
  retake={},rel={index=0,long=0,lat=0,gap=0,sa=0,ttc=math.huge,same=false,alongside=false}}
end
local function clear(map) for k in pairs(map) do map[k]=nil end end


local function grant(t,victim,passer) local m=t.retake[victim]; if not m then m={}; t.retake[victim]=m end; m[passer]=true end
local function entitled(t,x,y) local m=t.retake[x]; return m~=nil and m[y]==true end
function M.reset(t)
 t.count=0; t.disqualified=false; t.kind='slow'
 for _,map in pairs(t.ai) do clear(map) end
 t.lastAt=-math.huge; t.regime=false; t.whole=false; t.passedUnder=false; t.passMade=false; clear(t.ahead); clear(t.waiting); t.giveBack=0; t.dirty=true
 t.redBefore=false; t.redPending=false; t.stopPending=false; t.jumpPending=false; clear(t.retake)
end
function M.rebase(t,amount)
 if t.lastAt>-math.huge then t.lastAt=t.lastAt-amount end

 if t.regimeAt>-math.huge then t.regimeAt=t.regimeAt-amount end
 for j,v in pairs(t.waiting) do t.waiting[j]=v-amount end
 for _,pend in pairs(t.ai.waiting) do for j,v in pairs(pend) do pend[j]=v-amount end end
 if t.wholeAt>-math.huge then t.wholeAt=t.wholeAt-amount end
 for i,v in pairs(t.ai.giveAt) do t.ai.giveAt[i]=v-amount end
 for i,v in pairs(t.ai.slowUntil) do t.ai.slowUntil[i]=v-amount end
 for i,v in pairs(t.ai.lastAt) do t.ai.lastAt[i]=v-amount end
 for i,v in pairs(t.ai.slowAt) do t.ai.slowAt[i]=v-amount end
 for i,v in pairs(t.ai.oweUntil) do t.ai.oweUntil[i]=v-amount end
end





local function passable(b,c,p,now) return not b.valid or b.pit or b.offtrack or c.incident or c.holding or c.trouble==true or c.scFree==true or now-c.clearedAt<math.max(p.yellowHold,K.passAfterIncident) or now-c.lastCrash<K.passAfterIncident or b.kmh<p.obstacleSpeedKmh end
M.passable=passable

local function serving(t,j,now,player)
 return now<(t.ai.slowUntil[j] or 0) or j==player and (t.disqualified or t.kind=='slow' and now<t.lastAt+t.seconds)
end



function M.mayPass(t,i,j,now,player,neutral)
 return (t.ai.waiting[j] and t.ai.waiting[j][i] or 0)>now or j==player and (t.waiting[i] or 0)>now or not neutral and serving(t,j,now,player) or entitled(t,i,j)
end

local function decide(t,reason,seconds,now,p)
 t.requestId=t.requestId%K.counterMax+1; t.reason=reason; t.count=t.count+1; t.lastAt=now; t.dirty=true


 if t.race==false then t.kind='slow'; t.seconds=seconds; return reason end
 if t.count>p.penaltyDisqualify then t.kind='dq'; t.disqualified=true; t.seconds=0 else t.kind='slow'; t.seconds=seconds end
 return reason
end




function M.requestTrackLimits(t,seconds,now)
 if t.disqualified or now-t.lastAt<K.sanPlayerQueueGap then return nil end
 t.requestId=t.requestId%K.counterMax+1; t.reason='limits'; t.kind='slow'; t.seconds=seconds; t.lastAt=now; t.dirty=true
 return t.requestId
end


function M.requestContact(t,seconds,now)
 if now-t.lastAt<K.sanPlayerQueueGap or t.disqualified then return nil end
 t.requestId=t.requestId%K.counterMax+1; t.reason='contact'; t.kind='slow'; t.seconds=seconds; t.lastAt=now; t.dirty=true
 return t.requestId
end


local function deadline(regimeAt,now) return max(regimeAt+K.passGiveBack,now+K.giveBackMin) end



function M.update(t,frame,p,profile,inc,now,_,d)
 local i=frame.player
 t.race=profile=='C'



 local regime=inc.playerNoPass or inc.neutral or inc.red or inc.playerRestart==true

 if i>0 and inc.cars and inc.cars[i] and inc.cars[i].scFree then regime=false end


 if regime and inc.formation and not inc.red and not inc.playerNoPass and now-(inc.neutralSince or now)<K.formationGrace then regime=false end


 if inc.formation and not inc.red then regime=false end
 if not regime then t.passMade=false; if t.retake[i] then clear(t.retake[i]) end end

 local redEnded=t.redBefore and not inc.red and not inc.redCancelled; t.redBefore=inc.red
 t.giveBack=0; t.giveBackUntil=0
 if i==0 or frame.length<=0 then clear(t.waiting); t.passedUnder=false; return nil end
 local a=frame.cars[i]
 if redEnded and a.valid and not a.pit and not a.finished and profile=='C' then t.redPending=true end

 if not a.valid or a.pit or not a.splineValid then clear(t.ahead); clear(t.waiting); t.passedUnder=t.passMade; return nil end
 if not p.playerPenalties or C.solo(profile) then t.redPending=false; t.stopPending=false; t.jumpPending=false; t.jumpMult=nil end
 local ready=p.playerPenalties and not C.solo(profile) and not t.disqualified and now-t.lastAt>=K.penaltyCooldown

 if ready and t.redPending then t.redPending=false; return decide(t,'red',p.penaltySeconds,now,p) end
 if ready and t.stopPending then t.stopPending=false; return decide(t,'stop',p.penaltySeconds,now,p) end


 if ready and t.jumpPending and t.jumpMult then local mult=t.jumpMult; t.jumpPending=false; t.jumpMult=nil; return decide(t,'jump',p.penaltySeconds*mult,now,p) end
 if ready and t.jumpPending then t.jumpPending=false; return decide(t,'jump',p.penaltySeconds,now,p) end

 if ready and d and d.infraction and not (inc.formation and not inc.red) then
  t.deltaKind=d.infractionKind; t.deltaValue=d.infractionValue; Delta.penalized(d)
  return decide(t,'delta',p.penaltySeconds,now,p)
 end


 local starting=regime and not t.regime; t.regime=regime
 if starting then t.regimeAt=now end
 local result=nil
 for j=1,frame.count do
  local b=frame.cars[j]
  if j~=i then


   local retake=entitled(t,i,j)

   local restore=Incidents.restoring(inc,i,j)
   if restore then local r=P.relative(a,b,frame.length,t.rel); if r.same then Incidents.restored(inc,frame,i,j,r.long,(a.length+b.length)*0.5) end end
   local owed=(t.ai.waiting[j] and t.ai.waiting[j][i] or 0)>now or retake or restore
   if retake then local r=P.relative(a,b,frame.length,t.rel); if r.same and r.long<-(a.length+b.length)*0.5 then t.retake[i][j]=nil end end
   if passable(b,inc.cars[j],p,now) or serving(t,j,now,i) or owed then t.ahead[j]=nil; t.waiting[j]=nil
   else
    local r=P.relative(a,b,frame.length,t.rel)
    if not r.same or abs(r.long)>K.passWatch then t.ahead[j]=nil
    else
     local half=(a.length+b.length)*0.5
     if starting and abs(r.long)<=half then t.ahead[j]=nil



     elseif r.long>half then
      if t.ahead[j]==false and regime and not t.waiting[j] and now-t.regimeAt>=K.passGiveBack and not entitled(t,j,i) and not Incidents.restoring(inc,j,i) and not serving(t,i,now,i) and not passable(a,inc.cars[i],p,now) then grant(t,i,j) end
      t.ahead[j]=true; t.waiting[j]=nil
     elseif r.long<-half then
      if t.ahead[j] and regime then
       if now-t.regimeAt<K.passGiveBack then t.waiting[j]=deadline(t.regimeAt,now)
       else t.passMade=true; grant(t,j,i); if ready and not result then t.passed=j; result=decide(t,'pass',p.penaltySeconds,now,p) end end
      end
      t.ahead[j]=false
     end
    end
   end
   local due=t.waiting[j]
   if due then
    if now>=due then
     t.waiting[j]=nil; t.passMade=true; grant(t,j,i)
     if ready and not result then t.passed=j; result=decide(t,'pass',p.penaltySeconds,now,p) end
    elseif t.giveBack==0 or due<t.giveBackUntil then t.giveBack=j; t.giveBackUntil=due end
   end
  end
 end

 t.passedUnder=t.passMade or next(t.waiting)~=nil
 return result
end



function M.giveBackLimit(fromKmh,at,now,otherKmh,decel) return max(max(K.trafficMinSpeed,otherKmh-K.giveBackDrop),fromKmh-decel*3.6*(now-at)) end





local function owe(s,i,j,now)
 if s.owe[i] or s.dq[i] then return end
 s.owe[i]=j; s.oweUntil[i]=now+K.aiGiveBackMax; s.notes[#s.notes+1]={kind='owe',i=i,j=j}
end
local function sanction(t,s,i,j,a,p,now,events,neutral)
 s.lastAt[i]=now; s.count[i]=(s.count[i] or 0)+1; s.passed[i]=j
 if s.count[i]>p.penaltyDisqualify then s.dq[i]=true
 else s.slowUntil[i]=now+p.penaltySeconds; s.slowKmh[i]=math.max(K.trafficMinSpeed,a.kmh*K.aiPenaltyFactor); s.slowFrom[i]=a.kmh; s.slowAt[i]=now
  if neutral then owe(s,i,j,now) end
 end
 events=events or {}; events[#events+1]=i; t.dirty=true
 return events
end




function M.scPassed(t,i,j,a,p,profile,now)
 if not p.aiPenalties or C.solo(profile) then return false end
 local s=t.ai
 if s.dq[i] or now-(s.lastAt[i] or -math.huge)<K.penaltyCooldown then return false end
 sanction(t,s,i,j,a,p,now,nil,false)
 return true
end





function M.ai(t,frame,p,profile,inc,states,rows,now)
 if not p.aiPenalties or C.solo(profile) then clear(t.ai.giveBack); return nil end

 if inc.formation and not inc.red then clear(t.ai.giveBack); t.whole=false; return nil end
 local s=t.ai; local events=nil
 local whole=inc.neutral or inc.red
 if whole and not t.whole then t.wholeAt=now end
 t.whole=whole
 local transition=whole and now-t.wholeAt<K.passGiveBack
 for i=1,frame.count do
  local a=frame.cars[i]
  local ahead=s.ahead[i]; if not ahead then ahead={}; s.ahead[i]=ahead end
  local waiting=s.waiting[i]; if not waiting then waiting={}; s.waiting[i]=waiting end
  s.giveBack[i]=0
  if a.valid and a.control and not a.player and not a.pit and not a.safetyCar and not s.dq[i] then




   local relaunch=inc.cars[i].restart==true and inc.standing~='grid' and inc.standing~='lights'
   local regime=states[i].yellow or whole or relaunch or a.offtrack and s.regime[i]==true

   if inc.cars[i] and inc.cars[i].scFree then regime=false end

   local neutral=inc.neutral and not inc.red or relaunch



   local owed=s.owe[i]
   if owed then
    local b=frame.cars[owed]
    local why=(not b.valid or b.finished) and 'hors course' or b.pit and 'aux stands' or (inc.cars[owed] and inc.cars[owed].incident) and 'accidentee'
     or s.dq[owed] and 'disqualifiee' or now>=(s.oweUntil[i] or 0) and 'delai depasse'
    local back=P.relative(a,b,frame.length,t.rel)
    if not why and back.same and back.long>(a.length+b.length)*0.5 then
     s.notes[#s.notes+1]={kind='given',i=i,j=owed}; s.owe[i]=nil; s.oweUntil[i]=nil; s.oweLate[i]=nil
    elseif why then
     s.notes[#s.notes+1]={kind='dropped',i=i,j=owed,why=why}; s.owe[i]=nil; s.oweUntil[i]=nil

     if s.oweLate[i] and why=='delai depasse' then events=sanction(t,s,i,owed,a,p,now,events,false) end
     s.oweLate[i]=nil
    else s.giveBack[i]=owed end
   end
   local was=s.regime[i]; s.regime[i]=regime
   if not regime and t.retake[i] then clear(t.retake[i]) end


   if regime or was or next(waiting)~=nil then

    if regime and not was then clear(ahead) end



    local spare=not (whole and not inc.red)
    for j in pairs(ahead) do if passable(frame.cars[j],inc.cars[j],p,now) or spare and serving(t,j,now,frame.player) then ahead[j]=nil end end
    for j in pairs(waiting) do if passable(frame.cars[j],inc.cars[j],p,now) or spare and serving(t,j,now,frame.player) then waiting[j]=nil end end
    local row=rows[i]
    for k=1,row.count do
     local r=row.neighbors[k]; local j=r.index; local b=frame.cars[j]

     local retake=entitled(t,i,j)

     local restore=Incidents.restoring(inc,i,j)
     if restore and r.same then Incidents.restored(inc,frame,i,j,r.long,(a.length+b.length)*0.5) end
     local owed=(s.waiting[j] and s.waiting[j][i] or 0)>now or j==frame.player and (t.waiting[i] or 0)>now or retake or restore
     if retake then local fresh=P.relative(a,b,frame.length,t.rel); if fresh.same and fresh.long<-(a.length+b.length)*0.5 then t.retake[i][j]=nil end end
     if passable(b,inc.cars[j],p,now) or owed or not r.same or abs(r.long)>K.passWatch then ahead[j]=nil
     else
      local half=(a.length+b.length)*0.5

      if r.long>half then ahead[j]=true; waiting[j]=nil
      elseif r.long<-half then
       if ahead[j] and regime then





        local lenient=not transition and not inc.red and (neutral or (states[i].flW or 0)>0 or states[j]~=nil and states[j].state=='AVOID' or (b.kmh or 0)<(a.kmh or 0)*K.passLenientRatio)
        if transition then waiting[j]=deadline(t.wholeAt,now)
        elseif lenient and neutral then grant(t,j,i); if not s.owe[i] then owe(s,i,j,now); s.oweLate[i]=true end
        elseif lenient then waiting[j]=deadline(now,now)


        else grant(t,j,i); if now-(s.lastAt[i] or -math.huge)>=K.penaltyCooldown then events=sanction(t,s,i,j,a,p,now,events,neutral) elseif neutral then owe(s,i,j,now) end end
       end
       ahead[j]=false
      end
     end
    end
    local earliest=math.huge
    for j,due in pairs(waiting) do
     if now>=due then
      waiting[j]=nil; grant(t,j,i)
      if now-(s.lastAt[i] or -math.huge)>=K.penaltyCooldown then events=sanction(t,s,i,j,a,p,now,events,neutral) elseif neutral then owe(s,i,j,now) end
     elseif due<earliest then earliest=due; s.giveBack[i]=j end
    end
   end

  elseif a.pit then clear(ahead); clear(waiting)
   if s.owe[i] then s.notes[#s.notes+1]={kind='dropped',i=i,j=s.owe[i],why='aux stands'}; s.owe[i]=nil; s.oweUntil[i]=nil; s.oweLate[i]=nil end
  end
 end
 return events
end


function M.serialize(t,frame,session)
 local rows={tostring(session),string.format('P,%d,%d',t.count,t.disqualified and 1 or 0)}
 for i=1,frame.count do
  local n=t.ai.count[i]; local a=frame.cars[i]; local identity=a.identity or a.id
  if n and n>0 and type(identity)=='string' and identity:match('^[%w_%-]+$') then rows[#rows+1]=string.format('%d,%d,%d,%s',i,n,t.ai.dq[i] and 1 or 0,identity) end
 end
 return table.concat(rows,'\n')
end


function M.restore(t,text,session)
 t.pending=nil
 if type(text)~='string' or #text>K.maxZoneBytes then return end
 local pending={session=session,rows={}}; local first=true
 for line in text:gmatch('[^\n]+') do
  if first then first=false; if line~=tostring(session) then return end
  else
   local count,dq=line:match('^P,(%d+),([01])$')
   if count then pending.count=math.min(tonumber(count),K.counterMax); pending.dq=dq=='1'
   else
    local index,n,d,identity=line:match('^(%d+),(%d+),([01]),([%w_%-]+)$')
    if index and tonumber(index)>=1 and tonumber(index)<=K.maxCars then
     pending.rows[#pending.rows+1]={index=tonumber(index),count=math.min(tonumber(n),K.counterMax),dq=d=='1',identity=identity}
    end
   end
  end
 end
 if not first then t.pending=pending end
end

function M.resume(t,frame)
 local pending=t.pending
 if not pending or frame.count==0 then return end
 t.pending=nil
 if frame.session~=pending.session then return end

 if pending.count then t.count=pending.count; t.disqualified=pending.dq; if pending.dq then t.kind='dq'; t.requestId=t.requestId%K.counterMax+1 end end
 for _,row in ipairs(pending.rows) do
  local a=frame.cars[row.index]
  if a and a.valid and (a.identity or a.id)==row.identity then t.ai.count[row.index]=row.count; if row.dq then t.ai.dq[row.index]=true end end
 end
end
return M

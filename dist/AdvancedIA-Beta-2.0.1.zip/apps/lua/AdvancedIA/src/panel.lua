





local U=require('src/util')
local C=require('src/config')
local L=require('src/lang')
local P=require('src/perception')
local Classes=require('src/classes')
local Nuance=require('src/nuance')
local K=C.K



local WK={whiteTimeLeft=180,whiteShow=8}
local M={}
M.WK=WK
function M.new() return {kind='none',key='',title='',detail='',raw='',noPass=false,passed=false,drsBlocked=false,drsUsed=false,short='',passOk='',passBad='',infractions=-1,infractionMax=-1,notice='',noticeUntil=-math.huge,at=-math.huge,
 changedAt=-math.huge,double=false,explain='',finish=false,lapCode='',info=nil,drsText='',drsLaps=-1,drsLapsText='',redPit=false,blueGap=nil,giveBackDue=false,warnPending=false,warnUntil=-math.huge,updateUntil=-math.huge,updateVersion='',rel={index=0,long=0,lat=0,gap=0,sa=0,ttc=math.huge,same=false,alongside=false}} end



local function blue(rel,frame,p,profile,held)
 if profile~='C' or not p.blueFlagEnabled or frame.player==0 or frame.length<=0 then return nil end
 local a=frame.cars[frame.player]
 if not a.valid or a.pit or not a.splineValid then return nil end
 local best=nil
 for j=1,frame.count do
  local b=frame.cars[j]
  if j~=frame.player and b.valid and not b.pit and b.splineValid then
   local r=P.relative(a,b,frame.length,rel)

   if r.same and r.long<0 and r.gap>=0 and r.gap<=p.blueFlagRange and (r.sa>=K.lapSpeed or held and r.sa>-K.lapSpeed) and Classes.laps(a,b,r,frame.length)>0 then
    local gap=r.gap/math.max(1,b.speed)
    if not best or gap<best then best=gap end
   end
  end
 end
 return best
end
M.blue=blue
local function fasterClass(p,a,b) return p.multiClass and a.classified and b.classified and a.class<b.class end
function M.nuanceBlue(panel,e,frame,p,profile,now)
 local gap,advise,class=Nuance.playerBlue(e.nuance,e,frame,p,profile,now,panel.kind=='blue',fasterClass)
 return gap,gap and (class==2 and 2 or advise==1 and 1) or 0
end


local function native(panel,frame,now)


 local f=frame.flagOwned and K.flagNone or frame.flag

 if f~=K.flagStart then panel.startSeen=nil elseif not panel.startSeen then panel.startSeen=now end
 local a=frame.player>0 and frame.cars[frame.player] or nil
 local penalty=a and a.penaltyType or 0; local n=a and a.penaltyParam or 0
 if f==K.flagStop or penalty==K.penaltyBlackFlag then return 'black',0 end
 if penalty==K.penaltyMandatoryPits and n>0 then return 'penaltyDrive',n end
 if penalty==K.penaltyTeleportToPits and n>0 then return 'penaltyTeleport',n end
 if penalty==K.penaltySlowDown and n>0 then return 'penaltySlow',n end
 if penalty>0 or f==K.flagReturnToPits then return 'penalty',0 end
 if f==K.flagFinished then return panel.info and panel.info.finished and 'finish' or 'checkered',0 end
 if f==K.flagCaution then return 'native',0 end
 if f==K.flagFasterCar then return 'nativeBlue',0 end
 if f==K.flagOneLapLeft then


  local laps=(frame.sessionLaps or 0)>0 and not frame.timedRace and frame.sessionLaps or 0
  local left=frame.left or 0

  local ok=frame.started==true and (laps>0 and (frame.leaderLaps or 0)+1>=laps or frame.timedRace==true and left<=WK.whiteTimeLeft or laps==0 and frame.timedRace~=true)
  local wkey=tostring(frame.session)..(ok and '+' or '-')
  if panel.whiteSession~=wkey then
   panel.whiteSession=wkey
   panel.whiteMsg=string.format('drapeau natif dernier tour: %s (tours %d, tour du leader %d, temps restant %.0f s)',ok and 'retenu' or 'ignore',laps,frame.leaderLaps or 0,left)
  end
  if ok then return 'white',0 end
 end
 if f==K.flagStart and now-panel.startSeen<K.greenShow then return 'start',0 end
 return nil,0
end

local shownKinds={scCall='sc',penaltyDrive='penalty',penaltyTeleport='penalty',penaltySlow='penalty',nativeBlue='blue',start='green',finish='checkered',giveBack='warning',
 rollingIn='rolling',rollingGreen='rolling',standingLap='standing',standingPit='standing',
 formationLap='standing',formationRoll='rolling',formationCall='rolling',formationOff='rolling'}
shownKinds.scUnlap='sc'; shownKinds.scFinish='sc' -- Beta 1.64, lot 5 : dédoublement du joueur, arrivée neutralisée



local function joinOr(list,word)
 local n=#list
 if n==0 then return '' elseif n==1 then return list[1] end
 return table.concat(list,', ',1,n-1)..word..list[n]
end

local function seWhy(t)
 local mode=t.seStrategyMode or ''
 if mode=='' or not L.seStrategy[mode] then return nil end
 local who=t.seStrategyTarget or ''
 return who~='' and string.format(L.seStrategy[mode],who) or L.seStrategy.alone[mode]
end
local function pitTexts(panel,t,extra,value,plain)
 local others=t.playerTyreOthers or {}
 local tyre=t.playerTyre or ''
 local sig=extra..'|'..value..'|'..tyre..'|'..#others..'|'..(t.playerPitFrom or '')..'|'..(t.playerPitTo or '')..'|'..(t.playerPlan or '')..'|'..(t.playerPlanned or '')..'|'..(t.seStrategyMode or '')..'|'..(t.seStrategyTarget or '')
 if sig==panel.pitSig then return end
 panel.pitSig=sig
 local H=L.pitHint; local short,detail
 local fitted=tyre~='' and tyre or '?'
 local planSame=string.format(H.planSame,fitted)
 local planSameDetail=#others>0 and string.format(H.planSameDetail,fitted,joinOr(others,H.orWord)) or string.format(H.planSameDetailAny,fitted)
 if extra==1 then short=L.flagShort.pitCompound; detail=string.format(L.flagDetails.pitCompound,value)
 elseif extra==2 then
  if t.playerPlan=='same' then short=planSame; detail=planSameDetail
  elseif t.playerPlan=='ok' and (t.playerPlanned or '')~='' then short=string.format(H.planOk,t.playerPlanned); detail=short
  elseif tyre~='' and #others>0 then short=string.format(H.change,tyre,joinOr(others,H.orWord)); detail=short
  else short=H.generic; detail=short end
 elseif extra==3 then short=string.format(H.same,t.playerPitFrom or '?',t.playerPitTo or '?'); detail=string.format(H.sameDetail,t.playerPitFrom or '?',t.playerPitTo or '?')
 elseif extra==4 then short=string.format(H.counted,t.playerPitFrom or '?',t.playerPitTo or '?'); detail=short
 elseif extra==6 then short=string.format(H.planFixed,(t.playerPlanned or '')~='' and t.playerPlanned or '?'); detail=short
 else short=planSame; detail=planSameDetail end


 local why=not plain and (extra==1 or extra==2) and seWhy(t)
 if why then detail=string.format(L.seStrategy.join,detail,why) end
 panel.pitShort=short; panel.pitDetail=detail; panel.pitExplain=extra==4 and '' or L.flagExplain.pitCompound
end

local announceExtra={pitCompound=2,pitPlanSame=5,pitNotCounted=3,pitValidated=4,pitPlanOk=6}
function M.pitAnnounce(t,kind)
 local extra=announceExtra[kind]
 if not extra then return nil end
 local scratch={}
 local saved=t.playerPlan
 if kind=='pitCompound' then t.playerPlan='' end
 pitTexts(scratch,t,extra,t.playerPitDue or 0,true)
 t.playerPlan=saved
 return scratch.pitDetail or ''
end
local function show(panel,kind,value,double,gap,now,profile,extra)
 extra=extra or 0
 local shown=shownKinds[kind] or kind
 if shown~=panel.kind then panel.changedAt=now end
 panel.decided=kind; panel.kind=shown; panel.double=double; panel.blueGap=gap; panel.redPit=kind=='red' and value==1; panel.finish=kind=='finish'

 panel.lit=kind=='lights' and value or 0

 local info=panel.info
 if kind=='lap' and info then value=info.lapSerial elseif kind=='finish' and info then value=info.recapSerial end
 local session=profile=='P' or profile=='Q'

 local ours=kind=='black' and panel.infractionMax>=0 and panel.infractions>panel.infractionMax
 local key=kind..'|'..value..'|'..extra..'|'..(double and 1 or 0)..(session and '|s' or '')..(ours and '|'..panel.infractions or '')
 if kind=='pit' and extra>0 then key=key..'|'..(panel.pitSig or '') end
 if kind=='pit' and extra==0 and panel.pitWhy then key=key..'|'..panel.pitWhy end
 if key~=panel.key then
  panel.key=key

  if kind=='standing' and value>0 then panel.slotText='P'..value; panel.slotDistance=extra else panel.slotText=nil; panel.slotDistance=nil end
  if kind=='lap' and info then
   panel.title=info.lapTitle; panel.raw=info.lapDetail; panel.detail=info.lapDetail; panel.short=info.lapDetail; panel.explain=''; panel.lapCode=info.lapCode; panel.lapRecord=info.lapRecord==true
  elseif kind=='finish' and info then
   panel.title=L.flagTitles.finish; panel.raw=info.recap[1] or ''; panel.detail=panel.raw; panel.short=panel.raw; panel.explain=''
  elseif kind~='none' then

   panel.title=kind=='yellow' and double and L.flagTitles.yellow2 or kind=='start' and L.flagTitles.start or kind=='countdown' and tostring(value) or L.flagTitles[panel.kind]
   local detail
   if kind=='drs' then detail=L.flagDetails.drs
   elseif kind=='yellow' then detail=string.format(double and L.flagDetails.yellow2 or L.flagDetails.yellow,value)
   elseif kind=='red' then detail=value==1 and (session and L.flagDetails.redSessionPit or L.flagDetails.redPit) or (session and L.flagDetails.redSession or L.flagDetails.red)
   elseif kind=='green' and session then detail=L.flagDetails.greenSession
   else detail=string.format(L.flagDetails[kind],value,extra) end
   panel.raw=detail; panel.detail=U.wrapText(detail,K.panelWrap)

   local short=kind=='red' and (value==1 and (session and 'redSessionPit' or 'redPit') or (session and 'redSession' or 'red'))
    or kind=='green' and session and 'greenSession' or kind=='yellow' and double and 'yellow2'

    or kind=='start' and profile~=nil and profile~='C' and 'startSession' or kind=='lights' and value>=K.gridLights and 'lightsAll'

    or kind=='blue' and extra==1 and L.flagShort.blueAdvise and 'blueAdvise' or kind=='blue' and extra==2 and L.flagShort.blueClass and 'blueClass'
    or kind=='black' and ours and 'blackCount' or kind
   panel.short=string.format(L.flagShort[short],short=='blackCount' and panel.infractions or value,extra)

   local explain=kind=='yellow' and double and 'yellow2' or kind=='red' and (session and 'redSession' or 'red') or kind
   panel.explain=L.flagExplain[explain] or ''
   if kind=='pit' and extra>0 and panel.pitShort then panel.raw=panel.pitDetail; panel.detail=U.wrapText(panel.pitDetail,K.panelWrap); panel.short=panel.pitShort; panel.explain=panel.pitExplain end

   if kind=='pit' and extra==0 and panel.pitWhy then panel.raw=string.format(L.seStrategy.join,detail,panel.pitWhy); panel.detail=U.wrapText(panel.raw,K.panelWrap) end
  else panel.explain='' end
 end
end



function M.native(panel,frame,now,p,profile)
 if now<panel.at then return end
 panel.at=now+K.panelPeriod
 local kind,value=native(panel,frame,now)
 local a=frame.player>0 and frame.cars[frame.player] or nil
 if a and a.drsActive then panel.drsUsed=true elseif not (a and a.drsAvailable) then panel.drsUsed=false end
 if not kind and panel.info and panel.info.finished then kind='finish' end



 if not panel.ownOnly then
  if not kind and panel.info and now<panel.info.lapUntil then kind='lap' end
  if not kind and (not p or p.drsAssist~=false) and a and a.valid and a.drsPresent and a.drsAvailable and not a.drsActive and not panel.drsUsed then kind='drs'; value=1 end
  if not kind and now<panel.updateUntil then kind='update'; value=panel.updateVersion end
 end
 show(panel,kind or 'none',value,false,nil,now,profile)
 panel.noPass=false; panel.drsBlocked=false; panel.warnPending=false
end

local infoKinds={green=true,drs=true,white=true,checkered=true,slippery=true,lap=true,update=true}

function M.visible(panel,g,now)
 if panel.kind=='none' then return false end
 local hold=g and g.panelInfoTime or 0
 if panel.kind=='white' and (hold<=0 or hold>WK.whiteShow) then hold=WK.whiteShow end
 return not (infoKinds[panel.kind] and not panel.finish and hold>0 and now-panel.changedAt>=hold)
end

function M.infractions(panel,count,max)
 if count==panel.infractions and max==panel.infractionMax then return end
 panel.infractions=count; panel.infractionMax=max
 local suffix=count>0 and string.format(L.infractionCount,count,max) or ''
 panel.passOk=L.noPassing..suffix; panel.passBad=L.passMade..suffix
end


function M.warn(panel) panel.warnPending=true end

function M.notice(panel,reason,seconds,now) panel.notice=string.format(L.penaltyNotice[reason],seconds); panel.noticeUntil=now+K.noticeTime end

local function initials(name)
 if type(name)~='string' then return '' end
 local first,rest=name:match('^%s*(%S+)%s+(.-)%s*$')
 if not first or rest=='' then return name end
 return (first:match('^[%z\1-\127\194-\244][\128-\191]*') or '')..'. '..rest
end



local function restartInfo(panel,t,frame,kind)
 local r=t.restartRank or 0
 local key=r>0 and (t.restartState..'|'..r..'|'..t.restartAhead..'|'..t.restartTarget..'|'..tostring(panel.key)) or ''
 if key==panel.restartKey then return end
 if panel.restartShort then panel.restartShort=false; panel.key=nil; panel.restartKey=nil; return end
 panel.restartKey=key; panel.restartPill=nil; panel.restartRetake=false; panel.restartBox=nil
 if r==0 then return end
 local R=L.restart; local st=t.restartState
 local ahead=t.restartAhead>0 and frame.cars[t.restartAhead] or nil
 local name=ahead and ahead.name or ''
 local first=t.safety>0 and R.behindSc or R.leading
 if st=='pit' and panel.redPit or st=='wait' or st=='go' then panel.restartBox='P'..r end
 local short
 if st=='pit' and kind=='red' and panel.redPit then short=r>1 and string.format(R.pit,r,name) or string.format(R.pitFirst,first)
 elseif st=='wait' then short=ahead and string.format(R.wait,name) or string.format(R.waitFirst,first)
 elseif st=='go' then short=r>1 and string.format(R.go,r,name) or string.format(R.goFirst,first)
 elseif st=='retake' then local b=frame.cars[t.restartTarget]; panel.restartRetake=true; panel.restartPill=string.format(R.retake,r,initials(b and b.name or ''))
 elseif st=='ok' then panel.restartPill=r>1 and string.format(R.pill,r,initials(name)) or string.format(R.pillFirst,first) end
 if short then panel.short=short; panel.restartShort=true end
 if kind=='red' then panel.explain=string.format(t.safety>0 and R.explainSc or R.explain,r); panel.restartShort=true end
end



local COUNT={lead=3,go=1}
M.COUNT=COUNT
local function greenAt(t)
 if not t.neutral or t.relaunch or t.formation or t.formationAborted then return nil end
 if t.neutralMode=='vsc' then return t.ending and t.endingUntil or nil end
 if t.neutralMode=='fcy' then return t.neutralUntil end
 return nil
end
M.greenAt=greenAt

function M.update(panel,t,frame,p,profile,now,lights,e)
 if not p.flagPanel or panel.ownOnly then return M.native(panel,frame,now,p,profile) end



 if panel.goUntil and panel.goUntil-now>COUNT.lead+COUNT.go+1 then panel.goUntil=nil end
 local target=profile=='C' and greenAt(t) or nil
 local counting=target~=nil and target-now<=COUNT.lead+K.panelPeriod or now<(panel.goUntil or -math.huge)
 if now<panel.at and not counting then return end
 panel.at=now+K.panelPeriod
 local kind,value,double='none',0,false
 local a=frame.player>0 and frame.cars[frame.player] or nil
 local reason=t.drsReason or ''
 local present=p.drsAssist and a and a.valid and a.drsPresent or false


 if a and a.drsActive then panel.drsUsed=true elseif not (a and a.drsAvailable) then panel.drsUsed=false end
 local drs=present and reason=='' and a.drsAvailable and not a.drsActive and not panel.drsUsed or false
 local gap=nil
 local nk,nv=native(panel,frame,now)
 if panel.whiteMsg and e and e.note then e.note('INFO',panel.whiteMsg,-1) end
 panel.whiteMsg=nil
 local extra=0

 local nGap,nExtra=nil,0
 if p.classNuance and e then nGap,nExtra=M.nuanceBlue(panel,e,frame,p,profile,now) end
 if t.red then kind='red'; value=a and a.pit and 1 or 0

 elseif nk=='black' or nk=='penalty' or nk=='penaltyDrive' or nk=='penaltyTeleport' or nk=='penaltySlow' then kind=nk; value=nv



 elseif t.neutral and t.formation then kind=t.formationKind=='formation' and 'formationLap' or t.rollCall and 'formationCall' or 'formationRoll'; value=math.floor((t.formationShowKmh or t.formationKmh or 0)+0.5)
 elseif t.neutral and t.formationAborted then kind='formationOff'
 elseif t.neutral and t.relaunch and profile=='C' then
  if p.redRestart=='standing' and t.gridReady then kind='standingLap'
  else kind=t.safetyPhase~='in' and 'rolling' or p.restartOvertake=='scIn' and 'rollingGreen' or 'rollingIn' end

  if kind=='standingLap' and t.startAbortRoll then kind='rolling' end

  if kind=='standingLap' and t.redObstacle==true and t.onTrack>0 then kind='rolling' end
 elseif t.neutral then
  if t.neutralMode=='sc' then
   local merging=t.safetyPhase=='call' or t.safetyPhase=='exit' or t.safetyPhase=='place' or t.safetyPhase=='out' and t.safety>0 and frame.cars[t.safety].pit
   kind=t.safetyPhase=='in' and 'scIn' or merging and 'scCall' or 'sc'

   if t.scFinal then kind=panel.info and panel.info.finished and 'finish' or 'scFinish' elseif frame.player>0 and t.cars and t.cars[frame.player] and t.cars[frame.player].scFree then kind='scUnlap' end
  elseif t.neutralMode=='vsc' then kind=t.ending and 'vscEnd' or 'vsc'; value=p.vscDeltaPct
  else kind='fcy'; value=p.fcyDeltaPct end

  if target and profile=='C' then
   local left=target-now
   if left<=0 then kind='resumeGo'; value=0; panel.goUntil=target+COUNT.go
   elseif left<=COUNT.lead then kind='countdown'; value=math.ceil(left); panel.goUntil=target+COUNT.go end
  elseif t.neutralMode~='vsc' and t.neutralMode~='fcy' or not t.ending and t.neutralMode=='vsc' then panel.goUntil=nil end

 elseif now<(panel.goUntil or -math.huge) and profile=='C' then kind='resumeGo'

 elseif t.standing=='grid' then
  if t.gridPit then kind='standingPit' else kind='standing'; value=t.gridSlot or 0; extra=t.gridGap or 0 end
 elseif t.standing=='lights' then kind='lights'; value=t.gridLit or 0
 elseif t.standing=='go' then kind='go'
 elseif now<(t.jumpUntil or -math.huge) then kind='jump'
 elseif t.playerZone then

  double=t.playerZoneDouble==true
  if t.playerInside then kind=double and 'zone' or 'zone1' else kind='yellow'; value=math.floor((t.playerToZone or 0)/10+0.5)*10 end



 elseif t.playerWarn then kind='slowWarn'; value=math.floor((t.playerWarnDistance or 0)/10+0.5)*10
 elseif nk=='native' then kind='native'

 elseif t.playerRestart then kind='restart'

 elseif panel.info and panel.info.finished and profile=='C' then kind='finish'
 elseif nk=='checkered' or nk=='finish' then kind='checkered'

 elseif lights and lights.slowSlot>0 then kind='slow'; value=math.floor(lights.slowGap/10+0.5)*10


 elseif panel.giveBackDue then kind='giveBack'
 elseif panel.warnPending or now<panel.warnUntil then
  kind='warning'; if panel.warnPending then panel.warnPending=false; panel.warnUntil=now+K.warningShow end
 elseif now<(t.slipperyUntil or -math.huge) then kind='slippery'
 else


  if p.classNuance and e then gap,extra=nGap,nExtra
  else gap=blue(panel.rel,frame,p,profile,panel.kind=='blue') end
  if gap then kind='blue'
  elseif nk=='nativeBlue' then kind='nativeBlue'

  elseif lights and now<lights.meatballUntil then kind='meatball'

  elseif panel.info and now<panel.info.lapUntil then kind='lap'
  elseif drs then kind='drs'; value=1
  elseif nk=='white' then kind='white'
  elseif now<t.greenUntil then kind='green'
  elseif nk=='start' then kind='start'



  elseif t.playerPitNotice~=nil and t.playerPitNotice~='' then kind='pit'; value=t.playerPitDue or 0; extra=t.playerPitNotice=='same' and 3 or 4
  elseif t.playerPlanNotice then kind='pit'; value=t.playerPitDue or 0; extra=5
  elseif t.playerPitHint then kind='pit'; value=t.playerPitDue or 0; extra=2

  elseif t.playerPitShowRemind then kind='pit'; value=t.playerPitDue or 0; extra=t.playerPitCompound and 1 or 0

  elseif now<panel.updateUntil then kind='update'; value=panel.updateVersion end
 end
 if kind=='pit' and extra>0 then pitTexts(panel,t,extra,value) end
 panel.pitWhy=kind=='pit' and extra==0 and seWhy(t) or nil
 show(panel,kind,value,double,gap,now,profile,extra)
 restartInfo(panel,t,frame,kind)

 panel.slotPlaced=kind=='standing' and t.gridPlaced==true; panel.slotPassed=kind=='standing' and t.gridPassed==true

 local calm=kind=='none' or kind=='green' or kind=='blue' or kind=='pit' or kind=='slippery' or kind=='nativeBlue' or kind=='white' or kind=='start' or kind=='checkered' or kind=='finish' or kind=='lap'
  or kind=='slow' or kind=='slowWarn' or kind=='giveBack' or kind=='warning' or kind=='meatball' or kind=='update' or kind=='go'

 panel.drsBlocked=kind~='none' and kind~='drs' and (reason~='' and present and (reason~='flag' or not calm) or reason=='' and drs and not calm)
 if reason=='wet' then panel.drsText=L.drsWet
 elseif reason=='laps' then
  if t.drsLapsLeft~=panel.drsLaps then panel.drsLaps=t.drsLapsLeft; panel.drsLapsText=string.format(L.drsLapsLeft,t.drsLapsLeft) end
  panel.drsText=panel.drsLapsText
 else panel.drsText=L.drsBlocked end


 panel.noPass=not calm and kind~='drs' and kind~='native' and panel.kind~='black' and panel.kind~='penalty' and (kind~='yellow' or t.playerNoPass==true)

 if kind=='scUnlap' or kind=='finish' and t.scFinal then panel.noPass=false end
end
return M









local U=require('src/util')
local K=require('src/config').K
local abs,max,min=math.abs,math.max,math.min
local M={}

local function car() return {wasPit=false,pitFor=0,holding=false,released=false,holdFor=0,boxSeen=false,boxSpline=0,exitAt=-math.huge} end
function M.new()
 local t={spline=-1,samples=0,outliers=0,holds=0,cars={}}
 for i=1,K.maxCars do t.cars[i]=car() end
 return t
end

function M.rebase(t,amount) for i=1,K.maxCars do local c=t.cars[i]; if c.exitAt>-math.huge then c.exitAt=c.exitAt-amount end end end
function M.reset(t)
 t.spline=-1; t.samples=0; t.outliers=0; t.holds=0
 for i=1,K.maxCars do t.cars[i]=car() end
end

function M.before(t,spline,length) return U.spline(t.spline-spline)*length end


local function learn(t,spline,length,log,now)
 if t.spline<0 then t.spline=spline; t.samples=1; t.outliers=0
 else
  local offset=U.spline(spline-t.spline)
  if abs(offset)*length>K.mergeOutlier then
   t.outliers=t.outliers+1
   if t.outliers<K.mergeOutlierCount then return end
   t.spline=spline; t.samples=1; t.outliers=0
  else t.spline=(t.spline+offset*K.mergeAlpha)%1; t.samples=t.samples+1; t.outliers=0 end
 end
 if t.samples==1 then U.log(log,now,'INFO',string.format('jonction des stands: relevee a %.0f m',t.spline*length),-1) end
end




local function arriving(t,frame,i,window,now,push)
 local length=frame.length; local best,soonest=0,math.huge
 for j=1,frame.count do
  local b=frame.cars[j]
  if j~=i and b.valid and not b.pit and b.splineValid and b.kmh>=K.mergeTrafficKmh and now-t.cars[j].exitAt>=K.mergeExitGrace and (not push or push[j]) then
   local d=M.before(t,b.spline,length)
   local time=d>0 and d/max(b.speed,1) or 0
   if d>=-K.mergeClear and time<=window and time<soonest then best=j; soonest=time end
  end
 end
 return best,soonest
end







function M.update(t,frame,commands,now,dt,log,red,profile,canStop,push)
 local length=frame.length
 local holds=(profile=='J' or push~=nil and (profile=='P' or profile=='Q')) and canStop==true
 for i=1,frame.count do
  local a=frame.cars[i]; local c=t.cars[i]; local cmd=commands[i]
  if c.wasPit and not a.pit and a.valid and a.splineValid and not a.teleport and c.pitFor>=K.mergeLearnPit and a.kmh<=K.mergeLearnKmh and length>0 then
   learn(t,a.spline,length,log,now)
  end
  if a.pit and not a.inPitBox then c.pitFor=c.pitFor+dt else c.pitFor=0 end
  if c.wasPit and not a.pit and not a.teleport then c.exitAt=now end
  c.wasPit=a.pit==true
  if a.inPitBox and a.splineValid then c.boxSeen=true; c.boxSpline=a.spline elseif not a.pit then c.boxSeen=false end
  local d=t.spline>=0 and length>0 and a.valid and a.pit and not a.inPitBox and a.splineValid and M.before(t,a.spline,length) or nil

  local zone=d~=nil and holds and a.control and not a.player and not a.safetyCar and not red and not c.released and d>=K.mergeHoldMin and d<=K.mergeHoldZone
   and (c.holding or c.boxSeen and d<=M.before(t,c.boxSpline,length)-K.mergeBoxClear and a.kmh>=K.mergeHoldStartKmh)
  if zone then
   local window=min(K.mergeWindowMax,K.mergeWindow+d/max(a.speed,K.mergeCrawl))
   local j,time=arriving(t,frame,i,window,now,profile~='J' and push or nil)
   if j>0 and c.holdFor<K.mergeHoldMax then
    if not c.holding then
     c.holding=true; t.holds=t.holds+1; if profile~='J' then t.qualiHolds=(t.qualiHolds or 0)+1 end
     U.log(log,now,'INFO',string.format('jonction des stands: %s attend %s%s (a la jonction dans %.1f s, %.0f m avant elle)',a.name,frame.cars[j].name,profile~='J' and ' en tour lance' or '',time,d),i)
    end
    c.holdFor=c.holdFor+dt
   elseif c.holding then
    c.holding=false; c.released=true
    U.log(log,now,'INFO',string.format('jonction des stands: %s repart apres %.1f s (%s)',a.name,c.holdFor,j>0 and 'attente maximale' or 'piste libre'),i)
   end
  elseif c.holding then
   c.holding=false; c.released=true
   U.log(log,now,'INFO',string.format('jonction des stands: %s repart apres %.1f s (%s)',a.name,c.holdFor,red and 'drapeau rouge' or not holds and 'retenue coupee' or 'hors de la zone d attente'),i)
  end

  if not a.pit or a.inPitBox then c.released=false; c.holding=false; c.holdFor=0 end
  cmd.mergeHold=c.holding



  a.merging=d~=nil and d<=K.mergeBefore and d>=-K.mergeAfter and not c.holding
   and (a.kmh>=K.mergeSeenKmh or abs(d)<=K.mergeSeenNear and a.kmh>=K.mergeSeenCrawl)
 end
end


function M.idle(t,commands)
 for i=1,K.maxCars do commands[i].mergeHold=false; local c=t.cars[i]; c.wasPit=false; c.pitFor=0 end
end
return M

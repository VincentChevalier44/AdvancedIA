







local U=require('src/util')
local K=require('src/config').K
local Delta=require('src/delta')
local Panel=require('src/panel')
local M={}

M.rank={[0]=0,[1]=1,[12]=2,[3]=3,[6]=4,[2]=5,[5]=6}

M.names={[0]='aucun',[1]='vert',[2]='jaune',[3]='piste glissante',[5]='rouge',[6]='vehicule lent',[12]='bleu'}
local neutralNames={sc='voiture de securite',vsc='VSC',fcy='FCY'}
function M.new()
 return {at=-math.huge,last=-math.huge,value=0,reason='',slowFor={},slowSlot=0,slowGap=0,slowKmh=0,greenSeen=-math.huge,greenFrom=-math.huge,greenSpan=0,
  damaged=false,dSuspension=false,dEngine=false,dGearbox=false,dBody=false,dTyre=false,meatballUntil=-math.huge,
  rel={index=0,long=0,lat=0,gap=0,sa=0,ttc=math.huge,same=false,alongside=false}}
end
function M.reset(l)
 for j in pairs(l.slowFor) do l.slowFor[j]=0 end
 l.slowSlot=0; l.slowGap=0; l.slowKmh=0; l.value=0; l.reason=''; l.last=-math.huge; l.at=-math.huge
 l.greenSeen=-math.huge; l.greenFrom=-math.huge; l.greenSpan=0
 l.damaged=false; l.dSuspension=false; l.dEngine=false; l.dGearbox=false; l.dBody=false; l.dTyre=false; l.meatballUntil=-math.huge
end
function M.rebase(l,amount)
 if U.finite(l.at) then l.at=l.at-amount end
 if U.finite(l.last) then l.last=l.last-amount end
 if U.finite(l.meatballUntil) then l.meatballUntil=l.meatballUntil-amount end
 if U.finite(l.greenSeen) then l.greenSeen=l.greenSeen-amount end
 if U.finite(l.greenFrom) then l.greenFrom=l.greenFrom-amount end
end



local function slow(l,inc,frame,p,d,states,multi,dt,now)
 local i=frame.player; local a=i>0 and frame.cars[i] or nil


 if inc.neutral or inc.red or (inc.standing or 'none')~='none' or inc.restart or now<(inc.greenUntil or -math.huge)+K.slowGrace then
  for j in pairs(l.slowFor) do l.slowFor[j]=0 end
  l.slowSlot=0; l.slowGap=0; l.slowKmh=0
  return
 end
 local track=a~=nil and p.yellowEnabled==true and a.valid and not a.pit and a.splineValid and frame.length>0 and frame.started
 local best,gap=0,math.huge
 for j=1,frame.count do
  local b=frame.cars[j]; local c=inc.cars[j]; local s=states[j]
  local candidate=track and j~=i and b.valid and not b.pit and not b.finished and b.splineValid and not b.safetyCar
   and c.moved and not c.incident and now>=(s.pitCautionUntil or 0)
  if candidate then
   local pace=Delta.pace(d,states,j,Delta.bin(b.spline,d.bins),multi)
   candidate=pace>0 and b.speed<pace*K.slowVehicleRatio or pace<=0 and b.kmh<p.obstacleSpeedKmh
  end
  local held=candidate and (l.slowFor[j] or 0)+dt or 0
  l.slowFor[j]=held
  if held>=K.slowVehicleTime then
   local ahead=U.spline(b.spline-a.spline)*frame.length


   local nearest=j==l.slowSlot and -K.slowVehicleBehind or K.slowVehicleAhead
   if ahead>=nearest and ahead<=K.slowVehicleRange and ahead<gap then best=j; gap=ahead end
  end
 end
 l.slowSlot=best; l.slowGap=best>0 and math.max(0,gap) or 0; l.slowKmh=best>0 and frame.cars[best].kmh or 0
end



local function damage(l,frame,now)
 local i=frame.player; local a=i>0 and frame.cars[i] or nil
 local known=a~=nil and a.valid and frame.playerDamageSlot==i and (frame.damageRate or 0)>0
 local s=known and (frame.playerSuspension or 0)>=K.meatballSuspension
 local m=known and (frame.playerEngine or K.engineLifeNew)<=K.meatballEngine
 local b=known and (frame.playerGearbox or 0)>=K.meatballGearbox
 local c=known and (frame.playerBody or 0)>=K.meatballBody
 local t=known and frame.playerBlown==true
 local fresh=s and not l.dSuspension or m and not l.dEngine or b and not l.dGearbox or c and not l.dBody or t and not l.dTyre
 l.dSuspension=s; l.dEngine=m; l.dGearbox=b; l.dBody=c; l.dTyre=t
 l.damaged=s or m or b or c or t
 if fresh and not a.pit then l.meatballUntil=now+K.meatballShow; return true end
 return false
end


local function green(l,inc,p,now)
 local untilAt=inc.greenUntil or -math.huge
 if untilAt~=l.greenSeen then
  l.greenSeen=untilAt
  if untilAt>now then l.greenFrom=now; l.greenSpan=untilAt-now end
 end
 local seconds=p.lightsGreenTime or K.greenShow
 if p.lightsGreen==false or seconds<=0 then return false end
 if seconds==K.greenShow then return now<untilAt end
 return now<l.greenFrom+l.greenSpan*seconds/K.greenShow
end




function M.decide(l,inc,frame,p,profile,now)
 local i=frame.player
 if i==0 then return K.flagNone,'' end
 local a=frame.cars[i]

 if not a.valid or a.finished or frame.finished then return K.flagNone,'arrivee' end

 if l.playerDisqualified then return K.flagNone,'disqualification' end
 if inc.red then return p.lightsRed==false and K.flagCaution or K.flagStop,'drapeau rouge' end


 if inc.playerYellow and inc.neutral then return K.flagCaution,neutralNames[inc.neutralMode] or 'neutralisation' end

 if l.playerPenalty then return K.flagNone,'penalite' end
 if inc.playerYellow then return K.flagCaution,'drapeau jaune' end

 if inc.focusYellow then return K.flagCaution,'drapeau jaune, voiture suivie' end

 if inc.playerWarn then return K.flagCaution,'voiture lente au bord' end


 if inc.standing=='grid' or inc.standing=='lights' then return K.flagCaution,'depart arrete' end
 local greenOn=p.lightsGreen~=false and (p.lightsGreenTime or K.greenShow)>0
 if inc.standing=='go' and greenOn then return K.flagStart,'depart' end

 if profile=='C' and frame.sessionLaps>0 and not frame.timedRace and a.lap+1>=frame.sessionLaps then return K.flagNone,'dernier tour' end
 if l.slowSlot>0 and p.lightsWhite~=false then return K.flagSlowVehicle,'vehicule lent' end
 if now<(inc.slipperyUntil or -math.huge) and p.lightsOrange~=false then return K.flagSlippery,'piste glissante' end
 if p.lightsBlue~=false and Panel.blue(l.rel,frame,p,profile,l.value==K.flagFasterCar) then return K.flagFasterCar,'drapeau bleu' end
 if green(l,inc,p,now) then return K.flagStart,'drapeau vert' end
 return K.flagNone,''
end

function M.update(l,inc,frame,p,profile,d,states,multi,now)
 if now<l.at then return false end
 local dt=U.finite(l.last) and U.clamp(now-l.last,0,1) or 0
 l.last=now; l.at=now+K.panelPeriod
 slow(l,inc,frame,p,d,states,multi,dt,now)
 local fresh=damage(l,frame,now)
 l.value,l.reason=M.decide(l,inc,frame,p,profile,now)
 return fresh
end




function M.output(l,inc,on)
 if on then return l.value,l.reason end
 return inc.playerFlag and K.flagCaution or K.flagNone,''
end


function M.scan(text,out)
 out=out or {defs={},uses={},includes={}}
 if type(text)~='string' then return out end
 local section,name,input,active,used='',nil,nil,true,nil
 local function close()
  if section:find('^CONDITION') then
   if name and input=='FLAG_TYPE' then out.defs[name]=true end
  elseif used and active then
   for token in used:gmatch('[%w_]+') do out.uses[token]=true end
  end
  name=nil; input=nil; active=true; used=nil
 end
 for line in (text..'\n'):gmatch('([^\n]*)\n') do
  line=line:gsub(';.*$',''):gsub('\r','')
  if not line:find('^%s*//') then
   local header=line:match('^%s*%[([^%]]+)%]')
   if header then
    close(); section=header:upper()
    local include=header:match('^%s*[Ii][Nn][Cc][Ll][Uu][Dd][Ee]%s*:%s*(.-)%s*$')
    if include and include~='' then out.includes[#out.includes+1]=include end
   else
    local key,value=line:match('^%s*([%w_]+)%s*=%s*(.-)%s*$')
    if key then
     key=key:upper()
     if key=='NAME' then name=value:upper()
     elseif key=='INPUT' then input=value:upper()
     elseif key=='ACTIVE' then active=value~='0'
     elseif key=='CONDITION' then used=value:upper()
     elseif key=='INCLUDE' then for item in value:gmatch('[^,]+') do local f=item:match('^%s*(.-)%s*$'); if f~='' then out.includes[#out.includes+1]=f end end end
    end
   end
  end
 end
 close()
 return out
end

function M.equipped(out)
 for token in pairs(out.uses) do if out.defs[token] then return true end end
 return false
end
return M












local L={}
L.version=2
L.helloKey='ACAdvancedIA.Bridge.Hello'
L.dataKey='ACAdvancedIA.Bridge.Data.v2'
L.maxCars=61

L.hello={
 {'bridgeVersion','int'},{'release','string',24},{'heartbeat','uint'},{'closed','bool'},
}
L.fields={

 {'serial','uint'},{'enabled','bool'},{'ready','bool'},{'panic','bool'},{'online','bool'},{'replay','bool'},
 {'paused','bool'},{'guard','string',16},{'profile','string',4},{'language','string',4},{'session','int'},
 {'sessionType','int'},{'clock','double'},{'player','int'},{'carCount','int'},

 {'flagOwned','bool'},{'lightsValue','int'},{'lightsReason','string',16},{'nativeFlag','int'},

 {'panelDecided','string',16},{'panelKind','string',16},{'panelSerial','uint'},{'panelTitle','string',64},
 {'panelShort','string',128},{'panelDouble','bool'},{'panelBlueGap','float'},{'panelNoPass','bool'},
 {'panelLit','int'},{'panelInfractions','int'},{'panelInfractionMax','int'},{'warnLeft','float'},

 {'neutral','bool'},{'neutralMode','string',8},{'neutralFor','float'},{'escalated','bool'},{'relaunch','bool'},
 {'ending','bool'},{'endingLeft','float'},{'safetyPhase','string',12},{'safetyFailed','bool'},{'safetyCar','int'},
 {'red','bool'},{'reds','int'},{'greenLeft','float'},{'restart','bool'},{'playerRestart','bool'},
 {'standing','string',8},{'gridLit','int'},{'gridSlot','int'},{'gridGap','float'},{'gridPlaced','bool'},
 {'gridPassed','bool'},{'jumpLeft','float'},{'pitsClosed','bool'},{'slipperyLeft','float'},
 {'zone','bool'},{'zoneInside','bool'},{'zoneDouble','bool'},{'zoneCar','int'},{'zoneDistance','float'},
 {'incidentDistance','float'},{'noPass','bool'},{'yellow','bool'},{'zoneCount','int'},
 {'drsReason','string',8},{'drsLapsLeft','int'},{'pitDue','int'},{'pitRemind','bool'},
 {'slowCar','int'},{'slowGap','float'},{'meatballLeft','float'},{'damaged','bool'},

 {'messageId','uint'},{'messageKind','string',16},{'messageValue','float'},{'messageExtra','float'},
 {'messageTitle','string',64},{'messageText','string',160},

 {'deltaOn','bool'},{'deltaValue','float'},{'deltaKind','string',8},{'deltaInfraction','uint'},
 {'deltaInfractionKind','string',12},{'deltaInfractionValue','float'},{'deltaBeep','uint'},

 {'penaltyId','uint'},{'penaltyReason','string',8},{'penaltyCount','int'},{'penaltySeconds','float'},
 {'penaltyKind','string',4},{'disqualified','bool'},{'penaltyPassed','int'},{'giveBack','int'},
 {'giveBackLeft','float'},{'redPending','bool'},{'stopPending','bool'},{'jumpPending','bool'},
 {'penaltyLimit','int'},{'nativePenalty','int'},{'nativePenaltyParam','int'},

 {'drsBeep','uint'},{'playerDrs','int'},{'drsBlocked','bool'},{'flashId','uint'},{'flashHeard','int'},

 {'pitState','string',8},{'pitClosedSerial','uint'},{'pitCsp','bool'},{'pitPosition','double'},{'pitOpen','double'},
 {'pitClose','double'},{'pitDone','int'},{'pitTotal','int'},{'mandatoryStops','int'},{'maxStintMin','float'},
 {'minPitTime','float'},{'playerStops','int'},{'playerStintFor','float'},{'pitWaived','bool'},

 {'raceProgress','float'},{'raceLapsLeft','float'},{'raceKnown','bool'},{'wet','bool'},{'wetSerial','uint'},
 {'finished','bool'},{'dnf','bool'},{'dq','bool'},{'finalPosition','int'},{'gridPosition','int'},
 {'correctedPosition','int'},

 {'aiSerial','uint'},{'aiCode','string',8},{'aiTitle','string',48},{'aiShort','string',128},{'aiBlack','bool'},



 {'trackWarnings','int'},{'serveLaps','int'},
}

L.car={
 {'valid','bool'},{'safety','bool'},{'pit','bool'},
 {'incident','bool'},{'onTrack','bool'},{'still','float'},{'halt','bool'},{'spin','bool'},{'wrong','bool'},
 {'strikes','int'},{'sanctions','int'},{'timeAdded','float'},{'pending','int'},{'pendingLaps','int'},
 {'cutLeft','float'},{'sanctionDq','bool'},{'owedTo','int'},{'flagOffences','int'},{'flagDq','bool'},
 {'planned','bool'},{'plannedStops','int'},{'nextStopLap','int'},{'stopCause','int'},{'stopLimit','int'},
 {'failure','int'},{'critical','bool'},{'called','bool'},
 {'stops','int'},{'boxed','bool'},{'stintFor','float'},
 {'mistakeId','uint'},{'mistakeKind','int'},{'overtake','bool'},


 {'retired','bool'},


 {'lastReason','int'},
}

L.pending={[0]='',[1]='drive',[2]='stopgo'}
L.causes={[0]='',[1]='tyres',[2]='fuel',[3]='undercut',[4]='overcut',[5]='weather',[6]='failure',[7]='cover',[8]='neutral'}
L.limits={[0]='',[1]='tyres',[2]='fuel'}
L.failures={[0]='',[1]='leak',[2]='battery',[3]='overheat',[4]='puncture'}
L.mistakes={[0]='',[1]='brake',[2]='traction'}

L.reasons={[0]='',[1]='trackWarning',[2]='trackLimits',[3]='cut',[4]='blueFlags',[5]='contact',[6]='jumpStart',[7]='pitSpeed',
 [8]='pitExit',[9]='giveBack',[10]='flag',[11]='ignored',[12]='repeated',[13]='wrongWay'}
L.reasonOther=99

function L.code(list,name)
 if name==nil or name=='' then return 0 end
 for k=1,#list do if list[k]==name then return k end end
 return 0
end
return L
